const express = require('express');
const cors = require('cors');

const mongoose = require('mongoose');

const app = express();

// Behind a reverse proxy (Render, Nginx, ...) set TRUST_PROXY=1 so req.ip is the real client IP
// (login throttling depends on it). Leave unset when the API is exposed directly.
app.set('trust proxy', Number(process.env.TRUST_PROXY) || 0);
app.disable('x-powered-by');

// ---------- Security headers ----------
app.use((req, res, next) => {
  res.set({
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'Referrer-Policy': 'no-referrer',
    'Cross-Origin-Resource-Policy': 'same-site',
    'Content-Security-Policy': "default-src 'none'; frame-ancestors 'none'",
    // Member / payment data must never be kept in a shared front-desk browser cache.
    'Cache-Control': 'no-store'
  });
  if (process.env.NODE_ENV === 'production') res.set('Strict-Transport-Security', 'max-age=15552000; includeSubDomains');
  next();
});

// ---------- CORS ----------
// Auth uses a Bearer header (no cookies), so CORS is not a CSRF defence here, but it should still be
// limited to the real frontend. CORS_ORIGIN = comma-separated list of allowed origins (required in production).
const allowedOrigins = (process.env.CORS_ORIGIN || '').split(',').map((o) => o.trim().replace(/\/$/, '')).filter(Boolean);
app.use(cors({
  origin: allowedOrigins.length ? allowedOrigins : true,
  methods: ['GET', 'POST', 'PUT', 'DELETE'],
  allowedHeaders: ['Content-Type', 'Authorization'],
  maxAge: 600
}));
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true }));

// ---------- Base route (server health check) ----------
app.get('/', (req, res) => {
  res.status(200).json({
    success: true,
    message: 'HRK Gym OS API is running',
    data: { service: 'hrk-gym-os-api', status: 'ok' }
  });
});

// ---------- Health check (for uptime monitors / the host) — 503 when the database is not connected ----------
app.get('/health', (req, res) => {
  const dbUp = mongoose.connection.readyState === 1;
  res.status(dbUp ? 200 : 503).json({ success: dbUp, message: dbUp ? 'ok' : 'database not connected', data: {} });
});

// ---------- Feature routes ----------
app.use('/api/auth', require('./routes/authRoutes'));
app.use('/api/me', require('./routes/portalRoutes'));
app.use('/api', require('./routes/adminRoutes'));

// ---------- 404 handler for undefined routes ----------
app.use((req, res) => {
  res.status(404).json({
    success: false,
    message: 'Route not found'
  });
});

// Centralized error handling — must stay last.
app.use(require('./middleware/errorMiddleware'));

module.exports = app;
