const mongoose = require('mongoose');
const crypto = require('crypto');
const { GENDERS } = require('../config/constants');

const memberSchema = new mongoose.Schema(
  {
    gymId: { type: mongoose.Schema.Types.ObjectId, ref: 'Gym', required: true, index: true },
    // Human-friendly unique identifier within the gym, e.g. M0007.
    memberCode: { type: String, required: true },
    name: { type: String, required: [true, 'Name is required'], trim: true, maxlength: 120 },
    email: { type: String, trim: true, lowercase: true, maxlength: 254 },
    phone: { type: String, trim: true, maxlength: 20 },
    gender: { type: String, enum: GENDERS },
    dateOfBirth: { type: String }, // 'YYYY-MM-DD'
    joinedDate: { type: String, required: true }, // 'YYYY-MM-DD' (IST)
    // Account status set by the gym. Inactive members cannot check in.
    // (Membership status — active/expiring/expired — is derived from dates.)
    status: { type: String, enum: ['active', 'inactive'], default: 'active' },
    // Opaque random token encoded in the member's QR. Contains no personal data.
    qrToken: { type: String, required: true, unique: true },
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }, // portal login, if any
    // Time of the last recorded check-in. Used as an atomic claim so concurrent scans can't double-record.
    lastCheckInAt: { type: Date }
  },
  {
    timestamps: true,
    toJSON: { transform: (doc, ret) => { delete ret.__v; delete ret.qrToken; delete ret.lastCheckInAt; delete ret.emailKey; delete ret.phoneKey; return ret; } }
  }
);

memberSchema.index({ gymId: 1, memberCode: 1 }, { unique: true });
// One member per email / phone inside a gym, enforced by the database (the app-level pre-checks alone are
// not race-safe). Plain unique indexes on derived keys: "<gymId>:<email>" when there is an email, or a
// per-member placeholder when there is none, so members without an email/phone never collide with each
// other. This needs no partial/sparse index support, so it behaves the same on every MongoDB version.
memberSchema.add({
  emailKey: { type: String, required: true, unique: true },
  phoneKey: { type: String, required: true, unique: true }
});
memberSchema.pre('validate', function setUniquenessKeys(next) {
  this.emailKey = this.email ? `${this.gymId}:${this.email}` : `none:${this._id}`;
  this.phoneKey = this.phone ? `${this.gymId}:${this.phone}` : `none:${this._id}`;
  next();
});

memberSchema.statics.newQrToken = () => crypto.randomBytes(18).toString('base64url');

module.exports = mongoose.model('Member', memberSchema);
