const mongoose = require('mongoose');

const gymSchema = new mongoose.Schema(
  {
    name: { type: String, required: [true, 'Gym name is required'], trim: true, maxlength: 120 },
    phone: { type: String, trim: true, maxlength: 20 },
    address: { type: String, trim: true, maxlength: 300 },
    city: { type: String, trim: true, maxlength: 80 },
    // Atomic counter used to hand out member codes (M0001, M0002, ...) per gym.
    memberSeq: { type: Number, default: 0 }
  },
  { timestamps: true, toJSON: { transform: (doc, ret) => { delete ret.__v; delete ret.memberSeq; return ret; } } }
);

module.exports = mongoose.model('Gym', gymSchema);
