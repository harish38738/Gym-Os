const mongoose = require('mongoose');

const attendanceSchema = new mongoose.Schema(
  {
    gymId: { type: mongoose.Schema.Types.ObjectId, ref: 'Gym', required: true, index: true },
    memberId: { type: mongoose.Schema.Types.ObjectId, ref: 'Member', required: true, index: true },
    checkedInAt: { type: Date, required: true },
    date: { type: String, required: true }, // 'YYYY-MM-DD' IST day of the check-in
    type: { type: String, enum: ['qr'], default: 'qr' },
    // Membership state at the moment of check-in (always active or expiring).
    // "<memberId>:<5-minute bucket>". The UNIQUE index on this is the database-level guarantee that two
    // simultaneous scans can never both be recorded (it holds on every engine, unlike read-then-write checks).
    // The sliding 5-minute rule is applied first in the controller; since it forces consecutive records to be
    // >= 5 minutes apart they always fall in different buckets, so this key never blocks a legitimate check-in.
    windowKey: { type: String, required: true, unique: true },
    membershipStatus: { type: String, enum: ['active', 'expiring'], required: true }
  },
  { timestamps: true, toJSON: { transform: (doc, ret) => { delete ret.__v; delete ret.windowKey; return ret; } } }
);

attendanceSchema.index({ gymId: 1, date: -1 });
attendanceSchema.index({ memberId: 1, checkedInAt: -1 });

module.exports = mongoose.model('Attendance', attendanceSchema);
