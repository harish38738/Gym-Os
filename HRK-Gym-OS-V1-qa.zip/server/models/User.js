const mongoose = require('mongoose');

// A login account. role 'admin' = gym owner/front desk; role 'member' = a gym
// member using the portal (linked to a Member record via memberId).
const userSchema = new mongoose.Schema(
  {
    name: { type: String, required: [true, 'Name is required'], trim: true },
    email: {
      type: String,
      required: [true, 'Email is required'],
      unique: true,
      trim: true,
      lowercase: true,
      match: [/^[^\s@]+@[^\s@]+\.[^\s@]+$/, 'Please provide a valid email address']
    },
    password: {
      type: String,
      required: [true, 'Password is required'],
      select: false // never returned by default
    },
    role: { type: String, enum: ['admin', 'member'], default: 'admin', required: true },
    gymId: { type: mongoose.Schema.Types.ObjectId, ref: 'Gym', required: true, index: true },
    memberId: { type: mongoose.Schema.Types.ObjectId, ref: 'Member' },
    // Tokens issued before this moment are rejected (set when a password is reset).
    passwordChangedAt: { type: Date }
  },
  {
    timestamps: true,
    toJSON: { transform: (doc, ret) => { delete ret.password; delete ret.passwordChangedAt; delete ret.__v; return ret; } }
  }
);

module.exports = mongoose.model('User', userSchema);
