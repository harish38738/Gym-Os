const mongoose = require('mongoose');
const { PAYMENT_METHODS } = require('../config/constants');

const paymentSchema = new mongoose.Schema(
  {
    gymId: { type: mongoose.Schema.Types.ObjectId, ref: 'Gym', required: true, index: true },
    memberId: { type: mongoose.Schema.Types.ObjectId, ref: 'Member', required: true, index: true },
    membershipId: { type: mongoose.Schema.Types.ObjectId, ref: 'Membership' },
    // Kept so the payment stays readable if the member record is deleted later.
    memberName: { type: String, required: true },
    amount: { type: Number, required: [true, 'Amount is required'], min: [0.01, 'Amount must be greater than 0'] },
    method: { type: String, enum: PAYMENT_METHODS, required: true, default: 'cash' },
    paidOn: { type: String, required: true }, // 'YYYY-MM-DD' IST (business date)
    note: { type: String, trim: true, maxlength: 200 },
    // Idempotency: the app sends one random id per payment form. Re-sending the same id (flaky-network retry,
    // double tap) can never record the payment twice: "<gymId>:<id>" is unique; payments without an id get a
    // per-document placeholder so they never collide.
    requestKey: { type: String, required: true, unique: true }
  },
  { timestamps: true, toJSON: { transform: (doc, ret) => { delete ret.__v; delete ret.requestKey; delete ret.clientRequestId; return ret; } } }
);

paymentSchema.index({ gymId: 1, paidOn: -1 });
paymentSchema.add({ clientRequestId: { type: String, maxlength: 64 } });
paymentSchema.pre('validate', function setRequestKey(next) {
  this.requestKey = this.clientRequestId ? `${this.gymId}:${this.clientRequestId}` : `none:${this._id}`;
  next();
});

module.exports = mongoose.model('Payment', paymentSchema);
