const mongoose = require('mongoose');

const planSchema = new mongoose.Schema(
  {
    gymId: { type: mongoose.Schema.Types.ObjectId, ref: 'Gym', required: true, index: true },
    name: { type: String, required: [true, 'Plan name is required'], trim: true, maxlength: 80 },
    durationValue: { type: Number, required: [true, 'Duration is required'], min: [1, 'Duration must be at least 1'], max: [3650, 'Duration is too long'] },
    durationUnit: { type: String, enum: ['days', 'months'], required: true, default: 'months' },
    price: { type: Number, required: [true, 'Price is required'], min: [0, 'Price cannot be negative'] },
    isActive: { type: Boolean, default: true }
  },
  { timestamps: true, toJSON: { transform: (doc, ret) => { delete ret.__v; return ret; } } }
);

module.exports = mongoose.model('MembershipPlan', planSchema);
