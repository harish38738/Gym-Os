const mongoose = require('mongoose');

// One row per membership period. Renewals add rows; nothing is overwritten,
// so a member's full history is preserved. There is intentionally NO stored
// status field: status is derived from startDate/endDate (see membershipService).
const membershipSchema = new mongoose.Schema(
  {
    gymId: { type: mongoose.Schema.Types.ObjectId, ref: 'Gym', required: true, index: true },
    memberId: { type: mongoose.Schema.Types.ObjectId, ref: 'Member', required: true, index: true },
    planId: { type: mongoose.Schema.Types.ObjectId, ref: 'MembershipPlan' },
    // Snapshot of the plan at purchase time, so later plan edits don't rewrite history.
    planName: { type: String, required: true },
    price: { type: Number, required: true, min: 0 },
    startDate: { type: String, required: true }, // 'YYYY-MM-DD' IST
    endDate: { type: String, required: true } // 'YYYY-MM-DD' IST, inclusive
  },
  { timestamps: true, toJSON: { transform: (doc, ret) => { delete ret.__v; return ret; } } }
);

// Two periods for one member can never start on the same day. This is what stops a double-click /
// retried request from creating the same renewal twice (the overlap check alone is not race-safe).
membershipSchema.index({ memberId: 1, startDate: 1 }, { unique: true });

module.exports = mongoose.model('Membership', membershipSchema);
