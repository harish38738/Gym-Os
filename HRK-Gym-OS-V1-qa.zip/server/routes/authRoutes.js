const express = require('express');
const { register, login, getProfile } = require('../controllers/authController');
const { protect } = require('../middleware/authMiddleware');
const { perIp } = require('../utils/rateLimit');
const { LOGIN_WINDOW_MS, AUTH_IP_MAX_REQUESTS, REGISTER_MAX_PER_HOUR } = require('../config/constants');

const router = express.Router();

const authIpLimit = perIp({ windowMs: LOGIN_WINDOW_MS, max: AUTH_IP_MAX_REQUESTS, message: 'Too many requests. Please wait a few minutes and try again.' });
const registerIpLimit = perIp({ windowMs: 60 * 60 * 1000, max: REGISTER_MAX_PER_HOUR, message: 'Too many registrations from this network. Please try again later.' });

router.post('/register', registerIpLimit, register);
router.post('/login', authIpLimit, login);
router.get('/profile', protect, getProfile);

module.exports = router;
