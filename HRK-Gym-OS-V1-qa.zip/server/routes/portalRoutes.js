// Member portal: a logged-in MEMBER can only read their own data.
const express = require('express');
const { protect, requireRole } = require('../middleware/authMiddleware');
const portal = require('../controllers/portalController');

const router = express.Router();
router.use(protect, requireRole('member'));

router.get('/', portal.getOverview);
router.get('/attendance', portal.getMyAttendance);
router.get('/payments', portal.getMyPayments);

module.exports = router;
