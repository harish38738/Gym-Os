// All gym-management routes. Every route requires a logged-in ADMIN, and every
// controller scopes its queries by req.user.gymId.
const express = require('express');
const { protect, requireRole } = require('../middleware/authMiddleware');
const gym = require('../controllers/gymController');
const plans = require('../controllers/planController');
const members = require('../controllers/memberController');
const memberships = require('../controllers/membershipController');
const payments = require('../controllers/paymentController');
const attendance = require('../controllers/attendanceController');
const dashboard = require('../controllers/dashboardController');

const router = express.Router();
router.use(protect, requireRole('admin'));

router.get('/gym', gym.getGym);
router.put('/gym', gym.updateGym);

router.get('/dashboard', dashboard.getDashboard);

router.get('/plans', plans.listPlans);
router.post('/plans', plans.createPlan);
router.put('/plans/:id', plans.updatePlan);
router.delete('/plans/:id', plans.deletePlan);

router.get('/members', members.listMembers);
router.post('/members', members.createMember);
router.post('/members/import', members.importMembers);
router.get('/members/:id', members.getMember);
router.put('/members/:id', members.updateMember);
router.delete('/members/:id', members.deleteMember);
router.post('/members/:id/renew', members.renewMember);
router.post('/members/:id/regenerate-qr', members.regenerateQr);

router.post('/memberships', memberships.assignMembership);

router.get('/payments', payments.listPayments);
router.post('/payments', payments.recordPayment);
router.delete('/payments/:id', payments.deletePayment);

router.get('/attendance', attendance.listAttendance);
router.post('/attendance/check-in', attendance.checkIn);

module.exports = router;
