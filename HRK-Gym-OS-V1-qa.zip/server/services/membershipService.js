const Membership = require('../models/Membership');
const Payment = require('../models/Payment');
const AppError = require('../utils/AppError');
const { EXPIRING_DAYS } = require('../config/constants');
const { todayIST, addDays, diffDays, computeEndDate } = require('../utils/dates');

/**
 * Derives a member's membership state from their membership periods.
 * Pure function — no stored status, so it can never drift out of date.
 *
 *  active    – covered today, more than EXPIRING_DAYS left
 *  expiring  – covered today, EXPIRING_DAYS or fewer left (0 = last day)
 *  expired   – had memberships, none cover today and none start later
 *  upcoming  – not covered today but a future membership is booked
 *  none      – never had a membership
 *
 * "Covered through" follows back-to-back renewals, so renewing early clears
 * the "expiring" flag.
 */
const deriveStatus = (memberships, today) => {
  if (!memberships.length) {
    return { status: 'none', currentMembership: null, coverageEnd: null, daysLeft: null, lastEndDate: null, nextStartDate: null };
  }

  const lastEndDate = memberships.reduce((max, m) => (m.endDate > max ? m.endDate : max), memberships[0].endDate);
  const covering = memberships.filter((m) => m.startDate <= today && m.endDate >= today);

  if (covering.length) {
    let coverageEnd = covering.reduce((max, m) => (m.endDate > max ? m.endDate : max), covering[0].endDate);
    let extended = true;
    while (extended) {
      extended = false;
      for (const m of memberships) {
        if (m.startDate <= addDays(coverageEnd, 1) && m.endDate > coverageEnd) {
          coverageEnd = m.endDate;
          extended = true;
        }
      }
    }
    const currentMembership = covering.reduce((best, m) => (m.endDate > best.endDate ? m : best), covering[0]);
    const daysLeft = diffDays(today, coverageEnd);
    return {
      status: daysLeft <= EXPIRING_DAYS ? 'expiring' : 'active',
      currentMembership,
      coverageEnd,
      daysLeft,
      lastEndDate,
      nextStartDate: null
    };
  }

  const future = memberships.filter((m) => m.startDate > today).sort((a, b) => (a.startDate < b.startDate ? -1 : 1));
  if (future.length) {
    return { status: 'upcoming', currentMembership: null, coverageEnd: null, daysLeft: null, lastEndDate, nextStartDate: future[0].startDate };
  }
  return { status: 'expired', currentMembership: null, coverageEnd: null, daysLeft: diffDays(today, lastEndDate), lastEndDate, nextStartDate: null };
};

/** Status for every member of a gym that has memberships: Map<memberIdString, derived>. */
const getStatusMap = async (gymId, today = todayIST()) => {
  const rows = await Membership.find({ gymId }).select('memberId startDate endDate planName').lean();
  const byMember = new Map();
  for (const row of rows) {
    const key = row.memberId.toString();
    if (!byMember.has(key)) byMember.set(key, []);
    byMember.get(key).push(row);
  }
  const result = new Map();
  for (const [key, list] of byMember) result.set(key, deriveStatus(list, today));
  return result;
};

const statusFor = (map, memberId) =>
  map.get(memberId.toString()) || deriveStatus([], todayIST());

/** Status for a single member from the database. */
const getMemberStatus = async (gymId, memberId, today = todayIST()) => {
  const rows = await Membership.find({ gymId, memberId }).select('startDate endDate planName').lean();
  return deriveStatus(rows, today);
};

/**
 * Creates a membership period for a member (used for both first assignment and
 * renewal) and optionally records its payment. Previous periods are never touched.
 *
 * startDate defaults to: the day after the member's latest end date if that is
 * today or later (early renewal), otherwise today.
 * Overlapping an existing period is rejected so history stays unambiguous.
 */
const createMembership = async ({ gymId, member, plan, startDate, payment }) => {
  const today = todayIST();
  const existing = await Membership.find({ gymId, memberId: member._id }).select('startDate endDate').lean();

  let start = startDate;
  if (!start) {
    const latestEnd = existing.reduce((max, m) => (m.endDate > max ? m.endDate : max), '');
    start = latestEnd && latestEnd >= today ? addDays(latestEnd, 1) : today;
  }
  const end = computeEndDate(start, plan.durationValue, plan.durationUnit);

  const clash = existing.find((m) => m.startDate <= end && m.endDate >= start);
  if (clash) {
    throw new AppError(
      `This period overlaps an existing membership (${clash.startDate} to ${clash.endDate}). Choose a start date after ${clash.endDate}.`,
      409
    );
  }

  let membership;
  try {
    membership = await Membership.create({
      gymId,
      memberId: member._id,
      planId: plan._id,
      planName: plan.name,
      price: plan.price,
      startDate: start,
      endDate: end
    });
  } catch (err) {
    if (err && err.code === 11000) {
      throw new AppError('A membership starting on this date was just added for this member. Refresh the page to see it.', 409);
    }
    throw err;
  }

  let createdPayment = null;
  if (payment) {
    try {
      createdPayment = await Payment.create({
        gymId,
        memberId: member._id,
        membershipId: membership._id,
        memberName: member.name,
        amount: payment.amount,
        method: payment.method,
        paidOn: payment.paidOn || today,
        note: payment.note
      });
    } catch (err) {
      // No multi-document transactions on a standalone MongoDB: compensate by
      // removing the membership so we never keep a half-finished renewal.
      await Membership.deleteOne({ _id: membership._id });
      throw err;
    }
  }

  return { membership, payment: createdPayment };
};

module.exports = { deriveStatus, getStatusMap, statusFor, getMemberStatus, createMembership };
