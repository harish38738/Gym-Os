const bcrypt = require('bcryptjs');

const SALT_ROUNDS = 10;

/**
 * Hashes a plain-text password for storage.
 */
const hashPassword = async (plainPassword) => {
  const salt = await bcrypt.genSalt(SALT_ROUNDS);
  return bcrypt.hash(plainPassword, salt);
};

/**
 * Compares a plain-text password against a stored hash.
 */
const comparePassword = async (plainPassword, hashedPassword) => {
  return bcrypt.compare(plainPassword, hashedPassword);
};

// Used when the email doesn't exist, so "unknown email" costs the same bcrypt time as "wrong password"
// and response time can't be used to discover which emails have accounts.
let dummyHash;
const compareAgainstDummy = async (plainPassword) => {
  if (!dummyHash) dummyHash = await hashPassword('hrk-gym-os-dummy-password');
  await bcrypt.compare(plainPassword, dummyHash);
  return false;
};

module.exports = { hashPassword, comparePassword, compareAgainstDummy };
