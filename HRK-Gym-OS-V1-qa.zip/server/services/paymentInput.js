const v = require('../utils/validate');
const { PAYMENT_METHODS, MAX_MONEY } = require('../config/constants');
const AppError = require('../utils/AppError');
const { todayIST } = require('../utils/dates');

/** Validates a payment object ({amount, method, paidOn, note}). */
const readPayment = (input) => {
  if (input === undefined || input === null) return null;
  // A payment that is present but malformed (a string, an array, ...) must be rejected, not silently dropped.
  if (typeof input !== 'object' || Array.isArray(input)) throw new AppError('Payment must be an object with an amount', 400);
  const paidOn = v.date(input.paidOn, 'Payment date') || todayIST();
  if (paidOn > todayIST()) throw new AppError('Payment date cannot be in the future', 400);
  return {
    amount: v.money(input.amount, 'Payment amount', { required: true, min: 0.01, max: MAX_MONEY }),
    method: v.oneOf(input.method || 'cash', 'Payment method', PAYMENT_METHODS, { required: true }),
    paidOn,
    note: v.str(input.note, 'Note', { max: 200 })
  };
};

module.exports = { readPayment };
