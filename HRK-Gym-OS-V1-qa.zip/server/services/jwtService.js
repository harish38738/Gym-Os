const jwt = require('jsonwebtoken');

// The algorithm is pinned on both sign and verify, so a token can never be accepted under a different
// (e.g. "none") algorithm. Lifetime is configurable; default 7 days.
const ALGORITHM = 'HS256';
const expiresIn = () => process.env.JWT_EXPIRES_IN || '7d';

/** Signs a JWT for the given payload (typically { id: user._id }). */
const generateToken = (payload) => jwt.sign(payload, process.env.JWT_SECRET, { algorithm: ALGORITHM, expiresIn: expiresIn() });

/** Verifies a JWT and returns its payload. Throws if invalid or expired. */
const verifyToken = (token) => jwt.verify(token, process.env.JWT_SECRET, { algorithms: [ALGORITHM] });

module.exports = { generateToken, verifyToken };
