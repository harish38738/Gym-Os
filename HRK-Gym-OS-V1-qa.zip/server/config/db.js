const mongoose = require('mongoose');

/**
 * Connects to MongoDB (local or Atlas, mongodb:// or mongodb+srv://) using MONGO_URI, then makes sure every
 * index exists before the API starts serving — the unique indexes are what protect against duplicate
 * members / check-ins under concurrent requests. Exits if the connection or an index build fails.
 */
const connectDB = async () => {
  const mongoUri = process.env.MONGO_URI;

  if (!mongoUri) {
    console.error('MONGO_URI is not defined in environment variables.');
    process.exit(1);
  }

  try {
    const conn = await mongoose.connect(mongoUri, {
      serverSelectionTimeoutMS: 10000, // fail fast with a clear error instead of hanging for 30s
      maxPoolSize: 10
    });
    console.log(`MongoDB connected: ${conn.connection.host}/${conn.connection.name}`);
    await Promise.all(Object.values(mongoose.models).map((model) => model.init()));
  } catch (error) {
    console.error(`MongoDB connection/index error: ${error.message}`);
    process.exit(1);
  }

  // Handle connection-level errors that occur after the initial connect
  mongoose.connection.on('error', (error) => {
    console.error(`MongoDB runtime error: ${error.message}`);
  });

  mongoose.connection.on('disconnected', () => {
    console.warn('MongoDB disconnected.');
  });
};

module.exports = connectDB;
