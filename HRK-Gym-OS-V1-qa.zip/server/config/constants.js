// Business constants for HRK Gym OS V1.
module.exports = {
  // All gym "calendar days" are interpreted in Indian Standard Time.
  TIMEZONE: 'Asia/Kolkata',
  // A membership with this many days (or fewer) left is "expiring".
  EXPIRING_DAYS: 7,
  // Re-scanning the same member inside this window does not create a new record.
  DUPLICATE_CHECKIN_MINUTES: 5,
  PAYMENT_METHODS: ['cash', 'upi', 'card', 'other'],
  GENDERS: ['male', 'female', 'other'],
  // Accepted calendar-date range for any user-entered date (guards against 0001-01-01 / 9999-12-31 overflow bugs).
  MIN_DATE: '2000-01-01',
  MAX_DATE: '2100-12-31',
  // Plan duration caps keep every computed end date inside the valid range.
  MAX_PLAN_MONTHS: 120,
  MAX_PLAN_DAYS: 3650,
  MAX_MONEY: 10000000,
  // Auth throttling (in-memory, per server process).
  LOGIN_WINDOW_MS: 15 * 60 * 1000,
  LOGIN_MAX_FAILURES: 8,        // failed attempts per IP+email per window
  AUTH_IP_MAX_REQUESTS: 120,    // login+register requests per IP per window (a whole gym's members can share one Wi-Fi IP)
  REGISTER_MAX_PER_HOUR: 10     // new gyms per IP per hour
};
