// Small in-memory throttling for the auth endpoints (no extra dependency).
// Limits are per server process: fine for a single-instance pilot deployment; if the API is ever
// scaled to several instances, move this to a shared store (e.g. Redis). Documented in the README.
const AppError = require('./AppError');

class Counter {
  constructor(windowMs) {
    this.windowMs = windowMs;
    this.map = new Map(); // key -> { count, resetAt }
    const timer = setInterval(() => this.sweep(), Math.min(windowMs, 60000));
    if (timer.unref) timer.unref(); // never keeps the process alive
  }
  sweep(now = Date.now()) {
    for (const [k, v] of this.map) if (v.resetAt <= now) this.map.delete(k);
  }
  /** Returns the live entry or undefined. */
  peek(key, now = Date.now()) {
    const e = this.map.get(key);
    if (!e) return undefined;
    if (e.resetAt <= now) { this.map.delete(key); return undefined; }
    return e;
  }
  hit(key, now = Date.now()) {
    let e = this.peek(key, now);
    if (!e) { e = { count: 0, resetAt: now + this.windowMs }; this.map.set(key, e); }
    e.count += 1;
    return e;
  }
  clear(key) { this.map.delete(key); }
}

const tooMany = (resetAt, message) => {
  const err = new AppError(message, 429);
  err.retryAfter = Math.max(1, Math.ceil((resetAt - Date.now()) / 1000));
  return err;
};

/** Middleware: at most `max` requests per IP per window. */
const perIp = ({ windowMs, max, message }) => {
  const counter = new Counter(windowMs);
  return (req, res, next) => {
    const e = counter.hit(req.ip || 'unknown');
    if (e.count > max) return next(tooMany(e.resetAt, message));
    next();
  };
};

/** Failure lockout keyed by any string (we use ip + email). */
const failureLock = ({ windowMs, maxFailures, message }) => {
  const counter = new Counter(windowMs);
  return {
    /** Throws a 429 AppError if the key is locked. */
    check(key) {
      const e = counter.peek(key);
      if (e && e.count >= maxFailures) throw tooMany(e.resetAt, message);
    },
    fail(key) { counter.hit(key); },
    succeed(key) { counter.clear(key); }
  };
};

module.exports = { perIp, failureLock, Counter };
