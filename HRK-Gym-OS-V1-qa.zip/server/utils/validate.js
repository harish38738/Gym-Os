const AppError = require('./AppError');
const { isValidDateStr } = require('./dates');
const { MIN_DATE, MAX_DATE } = require('../config/constants');

const fail = (message) => new AppError(message, 400);

/** Trimmed string or undefined. Throws if required & empty, or too long. */
const str = (value, field, { required = false, max = 120 } = {}) => {
  if (value === undefined || value === null || String(value).trim() === '') {
    if (required) throw fail(`${field} is required`);
    return undefined;
  }
  if (typeof value !== 'string') throw fail(`${field} must be text`);
  const v = value.trim();
  if (v.length > max) throw fail(`${field} must be at most ${max} characters`);
  return v;
};

const email = (value, field = 'Email', opts = {}) => {
  const v = str(value, field, { ...opts, max: 254 });
  if (v === undefined) return v;
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)) throw fail(`${field} is not a valid email address`);
  return v.toLowerCase();
};

/** Indian-style phone: keeps digits (and leading +), 7–15 digits. */
const phone = (value, field = 'Phone') => {
  const v = str(value, field, { max: 20 });
  if (v === undefined) return v;
  const cleaned = v.replace(/[\s\-()]/g, '');
  if (!/^\+?\d{7,15}$/.test(cleaned)) throw fail(`${field} is not a valid phone number`);
  // Indian numbers are stored as the plain 10 digits so +91 98765 43210, 098765 43210 and
  // 9876543210 are recognised as the same number (duplicate detection).
  const m = /^(?:\+?91|0)(\d{10})$/.exec(cleaned);
  return m ? m[1] : cleaned;
};

const date = (value, field, { required = false } = {}) => {
  if (value === undefined || value === null || value === '') {
    if (required) throw fail(`${field} is required`);
    return undefined;
  }
  if (!isValidDateStr(value)) throw fail(`${field} must be a valid date in YYYY-MM-DD format`);
  if (value < MIN_DATE || value > MAX_DATE) throw fail(`${field} must be between ${MIN_DATE} and ${MAX_DATE}`);
  return value;
};

const number = (value, field, { required = false, min, max, integer = false } = {}) => {
  if (value === undefined || value === null || value === '') {
    if (required) throw fail(`${field} is required`);
    return undefined;
  }
  // Only real numbers or numeric strings: JSON `true`, arrays, objects etc. must not coerce to 1 / 0.
  if (typeof value !== 'number' && !(typeof value === 'string' && /^\s*-?\d+(\.\d+)?\s*$/.test(value))) throw fail(`${field} must be a number`);
  const n = Number(value);
  if (!Number.isFinite(n)) throw fail(`${field} must be a number`);
  if (integer && !Number.isInteger(n)) throw fail(`${field} must be a whole number`);
  if (min !== undefined && n < min) throw fail(`${field} must be at least ${min}`);
  if (max !== undefined && n > max) throw fail(`${field} must be at most ${max}`);
  return n;
};

const oneOf = (value, field, allowed, { required = false } = {}) => {
  if (value === undefined || value === null || value === '') {
    if (required) throw fail(`${field} is required`);
    return undefined;
  }
  const v = String(value).toLowerCase();
  if (!allowed.includes(v)) throw fail(`${field} must be one of: ${allowed.join(', ')}`);
  return v;
};

const password = (value, field = 'Password', { required = true } = {}) => {
  if (value === undefined || value === null || value === '') {
    if (required) throw fail(`${field} is required`);
    return undefined;
  }
  if (typeof value !== 'string' || value.length < 8) throw fail(`${field} must be at least 8 characters long`);
  // bcrypt only uses the first 72 bytes, so longer passwords would be silently truncated.
  if (Buffer.byteLength(value, 'utf8') > 72) throw fail(`${field} must be at most 72 bytes (about 72 characters)`);
  return value;
};

/** Escapes regex metacharacters so search text is always literal. */
const escapeRegex = (text) => text.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

const objectId = (value, field = 'id') => {
  if (typeof value !== 'string' || !/^[a-f\d]{24}$/i.test(value)) throw fail(`Invalid ${field}`);
  return value;
};

/** Money with at most 2 decimals. Returns a number rounded to paise. */
const money = (value, field, { required = false, min = 0, max } = {}) => {
  const n = number(value, field, { required, min, max });
  if (n === undefined) return n;
  if (Math.abs(n * 100 - Math.round(n * 100)) > 1e-6) throw fail(`${field} can have at most 2 decimal places`);
  return Math.round(n * 100) / 100;
};

/** Free-text search term: must be a plain string, trimmed, max 100 chars. Returns '' when absent. */
const searchText = (value) => {
  if (value === undefined || value === null || value === '') return '';
  if (typeof value !== 'string') throw fail('Search must be text');
  return value.trim().slice(0, 100);
};

const round2 = (n) => Math.round((Number(n) || 0) * 100) / 100;

module.exports = { round2, money, searchText, str, email, phone, date, number, oneOf, password, escapeRegex, objectId };
