// Date strategy: gym "calendar dates" (membership start/end, payment date,
// attendance day) are stored as plain 'YYYY-MM-DD' strings in IST. They never
// pass through a Date-with-timezone round trip, so there are no off-by-one-day
// bugs, and they compare correctly as strings. Exact moments (check-in time)
// are stored as real Date values.
const { TIMEZONE } = require('../config/constants');

const dayFormatter = new Intl.DateTimeFormat('en-CA', {
  timeZone: TIMEZONE,
  year: 'numeric',
  month: '2-digit',
  day: '2-digit'
});

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

const toUtcMs = (str) => {
  const [y, m, d] = str.split('-').map(Number);
  return Date.UTC(y, m - 1, d);
};

const fromUtcMs = (ms) => new Date(ms).toISOString().slice(0, 10);

/** Today's date in IST as 'YYYY-MM-DD'. */
const todayIST = (now = new Date()) => dayFormatter.format(now);

/** The IST calendar date of an exact moment. */
const dateOfInstantIST = (instant) => dayFormatter.format(new Date(instant));

const isValidDateStr = (str) => {
  if (typeof str !== 'string' || !DATE_RE.test(str)) return false;
  return fromUtcMs(toUtcMs(str)) === str; // rejects 2026-02-31 etc.
};

const addDays = (str, n) => fromUtcMs(toUtcMs(str) + n * 86400000);

/** Adds calendar months, clamping to the last day of a shorter month. */
const addMonths = (str, n) => {
  const [y, m, d] = str.split('-').map(Number);
  const total = (y * 12 + (m - 1)) + n;
  const ny = Math.floor(total / 12);
  const nm = total % 12;
  const lastDay = new Date(Date.UTC(ny, nm + 1, 0)).getUTCDate();
  return fromUtcMs(Date.UTC(ny, nm, Math.min(d, lastDay)));
};

/** Whole days from a to b (b - a). */
const diffDays = (a, b) => Math.round((toUtcMs(b) - toUtcMs(a)) / 86400000);

/**
 * Inclusive end date: a 1-month plan starting 2026-01-01 ends 2026-01-31.
 */
const computeEndDate = (start, value, unit) => {
  if (unit === 'days') return addDays(start, value - 1);
  return addDays(addMonths(start, value), -1);
};

module.exports = {
  todayIST,
  dateOfInstantIST,
  isValidDateStr,
  addDays,
  addMonths,
  diffDays,
  computeEndDate
};
