// Error with an HTTP status. The centralized errorMiddleware already reads
// err.statusCode, so throwing / next()-ing one of these yields a clean response.
class AppError extends Error {
  constructor(message, statusCode = 400, data) {
    super(message);
    this.name = 'AppError';
    this.statusCode = statusCode;
    this.data = data;
  }
}
module.exports = AppError;
