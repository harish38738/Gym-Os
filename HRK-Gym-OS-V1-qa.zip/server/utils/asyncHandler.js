// Wraps an async controller so rejected promises reach errorMiddleware.
module.exports = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
