const REQUIRED_ENV_VARS = ['MONGO_URI', 'JWT_SECRET'];

/**
 * Fails fast with a clear message if a required environment variable is
 * missing (or JWT_SECRET is the unsafe placeholder in production).
 */
const validateEnv = () => {
  const missing = REQUIRED_ENV_VARS.filter((key) => !process.env[key]);
  if (missing.length > 0) {
    console.error(`Missing required environment variable(s): ${missing.join(', ')}`);
    console.error('Copy .env.example to .env and fill in real values.');
    process.exit(1);
  }
  if (process.env.NODE_ENV === 'production' && (process.env.JWT_SECRET.length < 24 || process.env.JWT_SECRET === 'your_secret_key')) {
    console.error('JWT_SECRET is too weak for production. Use a random string of at least 24 characters.');
    process.exit(1);
  }
  if (process.env.NODE_ENV === 'production' && !process.env.CORS_ORIGIN) {
    console.error('CORS_ORIGIN must be set in production (the URL of your frontend, e.g. https://gym.example.com).');
    process.exit(1);
  }
};

module.exports = validateEnv;
