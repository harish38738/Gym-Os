// Endpoint-by-endpoint matrix: for EVERY route, the failure cases must fail with the right 4xx — never 2xx, never 5xx.
//   MONGO_URI=mongodb://127.0.0.1:27017/hrk-test-matrix node tests/api-matrix.js
process.env.JWT_SECRET = process.env.JWT_SECRET || 'test-secret-for-matrix-suite-1234567890';
process.env.TRUST_PROXY = '1'; // lets the test present a different client IP per request (registration is throttled per IP)
process.env.MONGO_URI = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/hrk-test-matrix-' + Date.now();
const mongoose = require('mongoose');
const { assertSafeTestDb, resetDb } = require('./helpers');
const app = require('../app');

let base; let passed = 0; const failures = []; const rows = [];
const check = (name, cond, extra) => { if (cond) passed += 1; else { failures.push(name); console.log('  ✗', name, extra !== undefined ? String(typeof extra === 'string' ? extra : JSON.stringify(extra)).slice(0, 240) : ''); } };
let ipSeq = 0;
const call = async (method, path, { token, body, raw } = {}) => {
  const res = await fetch(base + path, { method, headers: { 'Content-Type': 'application/json', 'X-Forwarded-For': `10.1.${Math.floor(ipSeq / 250)}.${(ipSeq++ % 250) + 1}`, ...(token ? { Authorization: `Bearer ${token}` } : {}) }, body: raw !== undefined ? raw : body !== undefined ? JSON.stringify(body) : undefined });
  const json = await res.json().catch(() => null);
  return { status: res.status, body: json, data: json && json.data };
};
const NOT_FOUND_ID = '0123456789abcdef01234567';

(async () => {
  assertSafeTestDb(process.env.MONGO_URI);
  await mongoose.connect(process.env.MONGO_URI); await resetDb();
  const server = app.listen(0); base = `http://127.0.0.1:${server.address().port}`;
  const reg = async (g, e) => (await call('POST', '/api/auth/register', { body: { gymName: g, name: 'Owner', email: e, password: 'secret1234' } })).data;
  const A = (await reg('Gym A', 'a@mx.test')).token; const B = (await reg('Gym B', 'b@mx.test')).token;
  const planA = (await call('POST', '/api/plans', { token: A, body: { name: 'Monthly', durationValue: 1, durationUnit: 'months', price: 100 } })).data.plan._id;
  const memA = (await call('POST', '/api/members', { token: A, body: { name: 'Mem A', phone: '9000000001', email: 'mem@mx.test', password: 'mempass123' } })).data.member._id;
  await call('POST', '/api/memberships', { token: A, body: { memberId: memA, planId: planA, payment: { amount: 100, method: 'cash' } } });
  const payA = (await call('POST', '/api/payments', { token: A, body: { memberId: memA, amount: 10, method: 'cash' } })).data.payment._id;
  const M = (await call('POST', '/api/auth/login', { body: { email: 'mem@mx.test', password: 'mempass123' } })).data.token;
  const id = { plan: planA, member: memA, payment: payA };
  const sub = (p) => p.replace(':planId', id.plan).replace(':memberId', id.member).replace(':paymentId', id.payment);

  // ---------- route table: [method, path, kind, validBody?, badBodies] ----------
  const ADMIN = [
    ['GET', '/api/gym'], ['PUT', '/api/gym', { name: 'X' }, [{}, { name: '' }, { name: 'x'.repeat(121) }, { name: 5 }, { name: 'ok', phone: 'abc' }]],
    ['GET', '/api/dashboard'],
    ['GET', '/api/plans'], ['POST', '/api/plans', { name: 'P', durationValue: 1, price: 1 }, [{}, { name: 'P' }, { name: 'P', durationValue: 0, price: 1 }, { name: 'P', durationValue: 1, price: -1 }, { name: 'P', durationValue: 'x', price: 1 }, { name: 'P', durationValue: 1, price: 1e12 }, { name: 'x'.repeat(81), durationValue: 1, price: 1 }, { name: 'P', durationValue: 1, price: 1, durationUnit: 'years' }]],
    ['PUT', '/api/plans/:planId', { name: 'P', durationValue: 1, price: 1 }, [{}, { name: 'P', durationValue: -2, price: 1 }], 'id'], ['DELETE', '/api/plans/:planId', undefined, undefined, 'id-delete'],
    ['GET', '/api/members'], ['POST', '/api/members', { name: 'N', phone: '9111111111' }, [{}, { name: 'N' }, { phone: '9111111112' }, { name: 'N', phone: 'abc' }, { name: 'N', email: 'bad' }, { name: 'x'.repeat(121), phone: '9111111113' }, { name: 'N', phone: '9111111114', gender: 'robot' }, { name: 'N', phone: '9111111115', dateOfBirth: '2999-01-01' }, { name: 'N', phone: '9111111116', joinedDate: 'yesterday' }, { name: ['N'], phone: '9111111117' }]],
    ['POST', '/api/members/import', { rows: [{ name: 'I', phone: '9222222222' }] }, [{}, { rows: [] }, { rows: 'x' }, { rows: Array.from({ length: 501 }, (_, i) => ({ name: 'n' + i, phone: '93' + (10000000 + i) })) }]],
    ['GET', '/api/members/:memberId', undefined, undefined, 'id'], ['PUT', '/api/members/:memberId', { name: 'Renamed' }, [{ name: '' }, { email: 'bad' }, { phone: 'abc' }, { status: 'banned' }, { password: 'short' }], 'id'], ['DELETE', '/api/members/:memberId', undefined, undefined, 'id-delete'],
    ['POST', '/api/members/:memberId/renew', { planId: planA }, [{ planId: 'nope' }, { planId: NOT_FOUND_ID }, { planId: planA, startDate: 'x' }, { planId: planA, startDate: '9999-12-31' }, { planId: planA, payment: { amount: -1 } }, { planId: planA, payment: { amount: 5, method: 'bitcoin' } }], 'id'],
    ['POST', '/api/members/:memberId/regenerate-qr', undefined, undefined, 'id'],
    ['POST', '/api/memberships', { memberId: ':memberId', planId: ':planId', startDate: '2031-01-01' }, [{}, { memberId: 'x', planId: ':planId' }, { memberId: ':memberId' }, { memberId: ':memberId', planId: ':planId', startDate: '2026-02-30' }, { memberId: ':memberId', planId: ':planId', payment: 'x' }]],
    ['GET', '/api/payments'], ['POST', '/api/payments', { memberId: ':memberId', amount: 5, method: 'cash' }, [{}, { memberId: ':memberId' }, { memberId: ':memberId', amount: 0 }, { memberId: ':memberId', amount: -5 }, { memberId: ':memberId', amount: 1e12 }, { memberId: ':memberId', amount: 'abc' }, { memberId: ':memberId', amount: 5, method: 'x' }, { memberId: 'bad', amount: 5 }, { memberId: NOT_FOUND_ID, amount: 5 }]],
    ['DELETE', '/api/payments/:paymentId', undefined, undefined, 'id-delete'],
    ['GET', '/api/attendance'], ['POST', '/api/attendance/check-in', { qrToken: 'hrk:unknownunknownunknown12' }, [{}, { qrToken: '' }, { qrToken: 5 }, { qrToken: 'x'.repeat(200) }]]
  ];
  const resolve = (o) => JSON.parse(JSON.stringify(o).replace(/":memberId"/g, JSON.stringify(id.member)).replace(/":planId"/g, JSON.stringify(id.plan)));

  for (const [method, rawPath, validBody, badBodies, kind] of ADMIN) {
    const path = sub(rawPath); const label = `${method} ${rawPath}`; const rec = { endpoint: label, noAuth: '', badToken: '', member: '', wrongGym: '', badId: '', missing: '', badBody: '' };
    const body = validBody ? resolve(validBody) : undefined;
    let r = await call(method, path, { body }); check(`${label}: no token → 401`, r.status === 401, r.status); rec.noAuth = r.status;
    r = await call(method, path, { body, token: 'garbage.token.value' }); check(`${label}: bad token → 401`, r.status === 401, r.status); rec.badToken = r.status;
    r = await call(method, path, { body, token: M }); check(`${label}: member token → 403`, r.status === 403, r.status); rec.member = r.status;
    if (kind && kind.startsWith('id')) {
      const bad = rawPath.replace(':planId', 'not-an-id').replace(':memberId', 'not-an-id').replace(':paymentId', 'not-an-id');
      r = await call(method, bad, { token: A, body }); check(`${label}: malformed id → 400`, r.status === 400, r.status); rec.badId = r.status;
      const missing = rawPath.replace(':planId', NOT_FOUND_ID).replace(':memberId', NOT_FOUND_ID).replace(':paymentId', NOT_FOUND_ID);
      r = await call(method, missing, { token: A, body }); check(`${label}: nonexistent id → 404`, r.status === 404, r.status); rec.missing = r.status;
      r = await call(method, path, { token: B, body }); check(`${label}: other gym's id → 404`, r.status === 404, r.status); rec.wrongGym = r.status;
    }
    if (badBodies) {
      let worst = 400;
      for (const bb of badBodies) { const x = await call(method, path, { token: A, body: resolve(bb) }); const ok = x.status >= 400 && x.status < 500; if (!ok) worst = x.status; check(`${label}: invalid body ${JSON.stringify(bb).slice(0, 60)} → 4xx (never 2xx/5xx)`, ok, x.status); }
      const x = await call(method, path, { token: A, raw: '{"broken":' }); check(`${label}: malformed JSON → 400`, x.status === 400, x.status);
      rec.badBody = worst === 400 ? `${badBodies.length + 1}×4xx` : `FAIL ${worst}`;
    }
    rows.push(rec);
  }

  // ---------- member portal ----------
  for (const p of ['/api/me', '/api/me/attendance', '/api/me/payments']) {
    check(`GET ${p}: no token → 401`, (await call('GET', p)).status === 401);
    check(`GET ${p}: admin token → 403`, (await call('GET', p, { token: A })).status === 403);
    const r = await call('GET', p, { token: M }); check(`GET ${p}: member token → 200`, r.status === 200, r.status);
    check(`GET ${p}: hostile query params are ignored, not trusted`, (await call('GET', p + '?memberId=' + NOT_FOUND_ID + '&gymId=' + NOT_FOUND_ID, { token: M })).status === 200);
    rows.push({ endpoint: `GET ${p}`, noAuth: 401, badToken: '-', member: 'n/a (member-only)', wrongGym: 'own data only', badId: '-', missing: '-', badBody: '-' });
  }
  check('GET /api/auth/profile: no token → 401', (await call('GET', '/api/auth/profile')).status === 401);
  check('GET /api/auth/profile: admin and member both → 200', (await call('GET', '/api/auth/profile', { token: A })).status === 200 && (await call('GET', '/api/auth/profile', { token: M })).status === 200);

  // ---------- public endpoints ----------
  const regBad = [[{}, 'empty'], [{ gymName: 'G', name: 'N', email: 'bad', password: 'secret1234' }, 'bad email'], [{ gymName: 'G', name: 'N', email: 'x@y.co', password: 'short' }, 'weak password'], [{ gymName: '', name: 'N', email: 'x@y.co', password: 'secret1234' }, 'no gym name'], [{ gymName: 'G', name: '', email: 'x@y.co', password: 'secret1234' }, 'no name'], [{ gymName: 'G', name: 'N', email: 'a@mx.test', password: 'secret1234' }, 'duplicate email'], [{ gymName: ['G'], name: 'N', email: 'x@y.co', password: 'secret1234' }, 'array gym name'], [{ gymName: 'G'.repeat(121), name: 'N', email: 'x@y.co', password: 'secret1234' }, 'overlong gym name']];
  for (const [b, why] of regBad) { const r = await call('POST', '/api/auth/register', { body: b }); check(`POST /api/auth/register: ${why} → 4xx`, r.status >= 400 && r.status < 500, r.status); }
  check('POST /api/auth/register: duplicate email specifically → 409', (await call('POST', '/api/auth/register', { body: { gymName: 'G', name: 'N', email: 'a@mx.test', password: 'secret1234' } })).status === 409);
  check('POST /api/auth/register: two gyms may share a name (intended: names are not identifiers)', (await call('POST', '/api/auth/register', { body: { gymName: 'Gym A', name: 'N', email: 'dupname@mx.test', password: 'secret1234' } })).status === 201);
  check('POST /api/auth/register: malformed JSON → 400', (await call('POST', '/api/auth/register', { raw: '{' })).status === 400);
  for (const [b, why, code] of [[{}, 'empty', 400], [{ email: 'a@mx.test' }, 'no password', 400], [{ password: 'x' }, 'no email', 400], [{ email: 'a@mx.test', password: 'wrongwrong' }, 'wrong password', 401], [{ email: 'nobody@mx.test', password: 'secret1234' }, 'unknown account', 401], [{ email: ['a@mx.test'], password: 'x' }, 'array email', 400], [{ email: { $gt: '' }, password: { $gt: '' } }, 'operator objects', 400], [{ email: 'a@mx.test', password: 12345 }, 'numeric password', 400]]) {
    const r = await call('POST', '/api/auth/login', { body: b }); check(`POST /api/auth/login: ${why} → ${code}`, r.status === code, r.status);
  }
  check('POST /api/auth/login: malformed JSON → 400', (await call('POST', '/api/auth/login', { raw: 'nope' })).status === 400);
  check('GET / → 200', (await call('GET', '/')).status === 200);
  check('GET /health → 200 (DB connected)', (await call('GET', '/health')).status === 200);
  check('unknown route → 404 JSON (with token)', (await call('GET', '/api/nope', { token: A })).status === 404);
  check('wrong HTTP method on a real route (PATCH /api/members) → 4xx', (await call('PATCH', '/api/members', { token: A, body: {} })).status >= 400);

  // ---------- duplicate-request behaviour ----------
  check('duplicate member (same phone) → 409', (await call('POST', '/api/members', { token: A, body: { name: 'Dup', phone: '9000000001' } })).status === 409);
  check('duplicate member (same email) → 409', (await call('POST', '/api/members', { token: A, body: { name: 'Dup', phone: '9555555555', email: 'MEM@mx.test' } })).status === 409);
  check('duplicate plan name is allowed (a gym may sell two "Monthly" plans at different prices) → 201', (await call('POST', '/api/plans', { token: A, body: { name: 'Monthly', durationValue: 1, price: 100 } })).status === 201);
  check('a future-dated period can be booked → 201', (await call('POST', '/api/memberships', { token: A, body: { memberId: memA, planId: planA, startDate: '2031-01-01' } })).status === 201);
  check('the same period assigned a second time → 409', (await call('POST', '/api/memberships', { token: A, body: { memberId: memA, planId: planA, startDate: '2031-01-01' } })).status === 409);
  check('inactive plan cannot be assigned → 400', await (async () => { const p = (await call('POST', '/api/plans', { token: A, body: { name: 'Old', durationValue: 1, price: 1, isActive: false } })).data.plan._id; return (await call('POST', '/api/memberships', { token: A, body: { memberId: memA, planId: p, startDate: '2040-01-01' } })).status === 400; })());
  check('zero-price plan is accepted (free trial plans are legitimate) → 201', (await call('POST', '/api/plans', { token: A, body: { name: 'Free trial', durationValue: 7, durationUnit: 'days', price: 0 } })).status === 201);

  // ---------- extreme values & pagination ----------
  check('limit=999999 is clamped, not an error or a dump', await (async () => { const r = await call('GET', '/api/members?limit=999999', { token: A }); return r.status === 200 && r.data.pagination.limit === 100; })());
  check('page=-3&limit=0 → safe defaults', (await call('GET', '/api/payments?page=-3&limit=0', { token: A })).status === 200);
  check('page far beyond the data → 200 with empty list', await (async () => { const r = await call('GET', '/api/members?page=9999', { token: A }); return r.status === 200 && r.data.members.length === 0; })());
  check('date filter with garbage → 400', (await call('GET', '/api/attendance?date=garbage', { token: A })).status === 400);
  check('50 KB name → 400 (not stored, not a crash)', (await call('POST', '/api/members', { token: A, body: { name: 'x'.repeat(50000), phone: '9666666666' } })).status === 400);
  check('1.2 MB body → 413', (await call('POST', '/api/members/import', { token: A, raw: JSON.stringify({ rows: [{ name: 'x'.repeat(1300000) }] }) })).status === 413);

  console.log('\nEndpoint matrix (HTTP status per case; all must be the expected 4xx):');
  console.log('  ' + 'endpoint'.padEnd(40) + 'no-token  bad-token  member  other-gym  bad-id  missing  bad-body');
  for (const r of rows) console.log('  ' + r.endpoint.padEnd(40) + String(r.noAuth).padEnd(10) + String(r.badToken).padEnd(11) + String(r.member).padEnd(8) + String(r.wrongGym).padEnd(11) + String(r.badId).padEnd(8) + String(r.missing).padEnd(9) + r.badBody);

  server.close(); await mongoose.connection.dropDatabase(); await mongoose.disconnect();
  console.log(`\n${passed} passed, ${failures.length} failed`);
  if (failures.length) { console.log('FAILED:\n - ' + failures.join('\n - ')); process.exit(1); }
  process.exit(0);
})().catch((e) => { console.error('Matrix suite crashed:', e); process.exit(2); });
