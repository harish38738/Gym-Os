// Database-outage behaviour. Needs commands to stop/start the test database:
//   MONGO_URI=mongodb://127.0.0.1:27018/hrk-test-down DB_STOP_CMD="..." DB_START_CMD="..." node tests/db-down.js
process.env.JWT_SECRET = process.env.JWT_SECRET || 'test-secret-for-dbdown-suite-1234567890';
if (!process.env.DB_STOP_CMD || !process.env.DB_START_CMD || !process.env.MONGO_URI) { console.log('SKIPPED: set MONGO_URI, DB_STOP_CMD and DB_START_CMD (this test stops your test database).'); process.exit(0); }
const { execSync } = require('child_process');
const mongoose = require('mongoose');
const { assertSafeTestDb, resetDb } = require('./helpers');
const app = require('../app');
let base; let passed = 0; const failures = [];
const check = (name, cond, extra) => { if (cond) { passed += 1; console.log('  ✓', name); } else { failures.push(name); console.log('  ✗', name, extra !== undefined ? JSON.stringify(extra).slice(0, 300) : ''); } };
const call = async (method, path, { token, body } = {}) => {
  const t0 = Date.now();
  const res = await fetch(base + path, { method, headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) }, body: body ? JSON.stringify(body) : undefined });
  const text = await res.text(); let json = null; try { json = JSON.parse(text); } catch (e) { /* not json */ }
  return { status: res.status, body: json, text, ms: Date.now() - t0 };
};
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
(async () => {
  assertSafeTestDb(process.env.MONGO_URI);
  await mongoose.connect(process.env.MONGO_URI, { serverSelectionTimeoutMS: 4000 }); await resetDb();
  const server = app.listen(0); base = `http://127.0.0.1:${server.address().port}`;
  let r = await call('POST', '/api/auth/register', { body: { gymName: 'Down Gym', name: 'O', email: 'o@down.test', password: 'secret1234' } });
  const T = r.body.data.token;
  r = await call('POST', '/api/members', { token: T, body: { name: 'Before Outage', phone: '9000000001' } }); check('member created while the database is up', r.status === 201);
  check('/health → 200 while up', (await call('GET', '/health')).status === 200);

  console.log('\n--- database stopped ---');
  execSync(process.env.DB_STOP_CMD, { stdio: 'ignore' }); await sleep(2500);
  for (const [label, m, p, o] of [['list members', 'GET', '/api/members', { token: T }], ['dashboard', 'GET', '/api/dashboard', { token: T }], ['create member', 'POST', '/api/members', { token: T, body: { name: 'During Outage', phone: '9000000002' } }], ['login', 'POST', '/api/auth/login', { body: { email: 'o@down.test', password: 'secret1234' } }], ['check-in', 'POST', '/api/attendance/check-in', { token: T, body: { qrToken: 'hrk:somethingsomething123456' } }]]) {
    const x = await call(m, p, o);
    check(`${label}: 503 "temporarily unavailable" JSON error, no stack trace / driver internals / hostnames (${x.status}, ${x.ms} ms)`, x.status === 503 && /temporarily unavailable/.test(x.body && x.body.message) && x.body && x.body.success === false && !/at \w|node_modules|mongo|ECONNREFUSED|127\.0\.0\.1|MongooseError|\.js:\d+/i.test(x.text), x.text.slice(0, 200));
    check(`${label}: fails fast, does not hang (< 15 s)`, x.ms < 15000, x.ms);
  }
  const h = await call('GET', '/health'); check('/health → 503 while the database is down', h.status === 503 && h.body.success === false, h);
  check('API process is still alive and serving non-database routes (GET / → 200)', (await call('GET', '/')).status === 200);
  check('requests without a valid token are still refused with 401, not 500', (await call('GET', '/api/members')).status === 401);

  console.log('\n--- database restarted ---');
  execSync(process.env.DB_START_CMD, { stdio: 'ignore' });
  let recovered = false; for (let i = 0; i < 40 && !recovered; i += 1) { await sleep(1000); recovered = (await call('GET', '/health')).status === 200; }
  check('/health returns to 200 by itself after the database is back (no API restart)', recovered);
  r = await call('GET', '/api/members', { token: T }); check('list members works again, earlier data intact', r.status === 200 && r.body.data.members.some((m) => m.name === 'Before Outage') && !r.body.data.members.some((m) => m.name === 'During Outage'), r.text.slice(0, 200));
  r = await call('POST', '/api/members', { token: T, body: { name: 'After Outage', phone: '9000000003' } }); check('writes work again', r.status === 201);

  server.close(); await mongoose.connection.dropDatabase(); await mongoose.disconnect();
  console.log(`\n${passed} passed, ${failures.length} failed`);
  if (failures.length) { console.log('FAILED:\n - ' + failures.join('\n - ')); process.exit(1); }
  process.exit(0);
})().catch((e) => { console.error('db-down suite crashed:', e); process.exit(2); });
