// End-to-end IST midnight test with a controllable clock: the whole stack (API + database) runs while "now" is moved
// across 00:00 IST (18:30 UTC). Verifies status, check-in, attendance dates, revenue and dashboard flip at exactly the right second.
//   MONGO_URI=mongodb://127.0.0.1:27017/hrk-test-midnight node tests/midnight.js
process.env.JWT_SECRET = process.env.JWT_SECRET || 'test-secret-for-midnight-suite-1234567890';
process.env.MONGO_URI = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/hrk-test-midnight-' + Date.now();

const mongoose = require('mongoose');
const { assertSafeTestDb, resetDb } = require('./helpers');
const app = require('../app'); // load every model first, THEN install the fake clock

// A Proxy (not a subclass) keeps every Date a genuine Date, so Mongoose/BSON/JWT behave exactly as in production.
const RealDate = Date; let fakeNow = null;
global.Date = new Proxy(RealDate, {
  construct(target, args) { return args.length === 0 && fakeNow !== null ? new target(fakeNow) : new target(...args); },
  get(target, prop, receiver) { if (prop === 'now') return () => (fakeNow !== null ? fakeNow : target.now()); return Reflect.get(target, prop, receiver); }
});
const at = (iso) => { fakeNow = new RealDate(iso).getTime(); };

let base; let passed = 0; const failures = [];
const check = (name, cond, extra) => { if (cond) { passed += 1; console.log('  ✓', name); } else { failures.push(name); console.log('  ✗', name, extra !== undefined ? JSON.stringify(extra).slice(0, 260) : ''); } };
const call = async (method, path, { token, body } = {}) => {
  const res = await fetch(base + path, { method, headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) }, body: body ? JSON.stringify(body) : undefined });
  const json = await res.json().catch(() => null); return { status: res.status, body: json, data: json && json.data };
};

(async () => {
  assertSafeTestDb(process.env.MONGO_URI);
  at('2026-06-30T17:00:00Z'); // 22:30 IST on 30 June
  await mongoose.connect(process.env.MONGO_URI); await resetDb();
  const server = app.listen(0); base = `http://127.0.0.1:${server.address().port}`;
  let T = (await call('POST', '/api/auth/register', { body: { gymName: 'Midnight Gym', name: 'O', email: 'o@mid.test', password: 'secret1234' } })).data.token;
  const plan = (await call('POST', '/api/plans', { token: T, body: { name: 'Monthly', durationValue: 1, durationUnit: 'months', price: 1000 } })).data.plan._id;
  const mk = async (name, phone, start, extra = {}) => { const id = (await call('POST', '/api/members', { token: T, body: { name, phone, ...extra } })).data.member._id; if (start) await call('POST', '/api/memberships', { token: T, body: { memberId: id, planId: plan, startDate: start } }); return id; };
  const lastDay = await mk('Last Day Lata', '9000000001', '2026-06-01', { email: 'lata@mid.test', password: 'latapass123' });
  const startsJuly1 = await mk('July First Jaya', '9000000002', '2026-07-01');
  const wasExpired = await mk('Expired Esha', '9000000003', '2026-05-01');
  const longActive = await mk('Active Arun', '9000000004', '2026-06-24');
  const qr = async (id) => (await call('GET', `/api/members/${id}`, { token: T })).data.qrPayload;
  const scan = async (id) => call('POST', '/api/attendance/check-in', { token: T, body: { qrToken: await qr(id) } });
  const status = async (id) => (await call('GET', `/api/members/${id}`, { token: T })).data.membership;
  const dash = async () => (await call('GET', '/api/dashboard', { token: T })).data;

  console.log('\n22:30 IST, 30 June — the last day of Lata\'s membership');
  let s = await status(lastDay); check('Lata: membership ends today → expiring, 0 days left', s.status === 'expiring' && s.daysLeft === 0 && s.coverageEnd === '2026-06-30', s);
  check("Jaya: starts tomorrow → 'upcoming'", (await status(startsJuly1)).status === 'upcoming');
  check('Esha: ended in May → expired', (await status(wasExpired)).status === 'expired');
  check('Arun: active', (await status(longActive)).status === 'active');
  let r = await scan(lastDay); check('Lata can still check in on her last day (attendance dated 30 June)', r.status === 201 && r.data.attendance.date === '2026-06-30', r.body);
  check('Jaya cannot check in yet ("starts on 2026-07-01")', (r = await scan(startsJuly1)).status === 403 && /2026-07-01/.test(r.body.message), r.body);
  r = await call('POST', '/api/payments', { token: T, body: { memberId: lastDay, amount: 1000, method: 'upi' } }); check('payment recorded at 22:30 IST is dated 30 June', r.data.payment.paidOn === '2026-06-30', r.body);
  let d = (await dash()).totals; check("dashboard 22:30 IST: 1 check-in, ₹1,000 revenue, 3 active (Lata, Arun… not Jaya/Esha)", d.todayCheckIns === 1 && d.todayRevenue === 1000 && d.activeMemberships === 2, d);

  console.log('\n23:59:59 IST — one second before midnight');
  at('2026-06-30T18:29:59Z');
  r = await scan(longActive); check('Arun checks in at 23:59:59 IST → dated 30 June', r.status === 201 && r.data.attendance.date === '2026-06-30', r.body);
  r = await call('POST', '/api/payments', { token: T, body: { memberId: longActive, amount: 1, method: 'cash', paidOn: '2026-07-01' } }); check("a payment dated tomorrow (1 July) is still refused at 23:59:59 IST", r.status === 400, r.body);
  check('Lata still expiring (not yet expired)', (await status(lastDay)).status === 'expiring');

  console.log('\n00:00:01 IST, 1 July — one second after midnight');
  at('2026-06-30T18:30:01Z');
  s = await status(lastDay); check('Lata: now EXPIRED (membership ended yesterday)', s.status === 'expired' && s.lastEndDate === '2026-06-30', s);
  check("Jaya: now ACTIVE (starts today)", (await status(startsJuly1)).status === 'expiring' || (await status(startsJuly1)).status === 'active');
  r = await scan(lastDay); check('Lata is now refused at the desk: "expired on 2026-06-30"', r.status === 403 && r.body.data.reason === 'expired', r.body);
  r = await scan(startsJuly1); check('Jaya now checks in; attendance dated 1 July', r.status === 201 && r.data.attendance.date === '2026-07-01', r.body);
  r = await scan(longActive); check('Arun re-scans 31 seconds after his 23:59:59 scan → duplicate (same visit across midnight; no new record)', r.status === 200 && r.data.result === 'duplicate', r.body);
  d = (await dash()).totals; check("dashboard after midnight: today's check-ins = 1 (only Jaya), today's revenue = ₹0 (yesterday's payment no longer counts)", d.todayCheckIns === 1 && d.todayRevenue === 0, d);
  r = await call('GET', '/api/attendance?date=2026-06-30', { token: T }); check('yesterday still lists its 2 check-ins (Lata, Arun)', r.data.attendance.length === 2, r.data.attendance.length);
  r = await call('GET', '/api/attendance?date=2026-07-01', { token: T }); check('today lists exactly 1 (Jaya)', r.data.attendance.length === 1);
  r = await call('POST', '/api/payments', { token: T, body: { memberId: startsJuly1, amount: 1000, method: 'cash' } }); check('payment recorded now is dated 1 July', r.data.payment.paidOn === '2026-07-01');
  r = await call('POST', '/api/payments', { token: T, body: { memberId: lastDay, amount: 5, method: 'cash', paidOn: '2026-06-30' } }); check('a back-dated payment for 30 June is accepted but does not count in today\'s revenue', r.status === 201 && (await dash()).totals.todayRevenue === 1000, (await dash()).totals);
  const lata = await call('POST', '/api/auth/login', { body: { email: 'lata@mid.test', password: 'latapass123' } });
  r = await call('GET', '/api/me', { token: lata.data.token }); check("Lata's portal now shows EXPIRED with her last day 30 June", r.data.membership.status === 'expired' && r.data.membership.lastEndDate === '2026-06-30', r.data.membership);
  r = await call('POST', `/api/members/${lastDay}/renew`, { token: T, body: { planId: plan } }); check('renewing Lata after expiry starts TODAY (1 July) → ends 31 July', r.data.membership.startDate === '2026-07-01' && r.data.membership.endDate === '2026-07-31', r.body);
  r = await scan(lastDay); check('Lata checks in again right after renewing', r.status === 201);

  console.log('\n5 minutes later, 00:06 IST');
  at('2026-06-30T18:36:30Z');
  r = await scan(longActive); check('Arun scans after the 5-minute window → a new check-in dated 1 July', r.status === 201 && !!r.data && !!r.data.attendance && r.data.attendance.date === '2026-07-01', r.body);

  console.log('\nMonth / year ends (login tokens last 7 days, so the owner logs in again after each big jump)');
  const relog = async () => { T = (await call('POST', '/api/auth/login', { body: { email: 'o@mid.test', password: 'secret1234' } })).data.token; };
  at('2026-12-31T18:29:59Z'); await relog(); check('23:59:59 IST on 31 Dec is still 31 Dec', (await dash()).date === '2026-12-31');
  at('2026-12-31T18:30:00Z'); check('00:00:00 IST on 1 Jan is 1 Jan next year', (await dash()).date === '2027-01-01');
  at('2028-02-28T18:30:00Z'); await relog(); check('leap year: 00:00 IST 29 Feb 2028 is 29 Feb', (await dash()).date === '2028-02-29');

  server.close(); fakeNow = null; await mongoose.connection.dropDatabase(); await mongoose.disconnect();
  console.log(`\n${passed} passed, ${failures.length} failed`);
  if (failures.length) { console.log('FAILED:\n - ' + failures.join('\n - ')); process.exit(1); }
  process.exit(0);
})().catch((e) => { console.error('Midnight suite crashed:', e); process.exit(2); });
