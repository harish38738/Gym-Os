// End-to-end API test. Needs a running MongoDB-compatible database.
//   MONGO_URI=mongodb://127.0.0.1:27017/hrk-test JWT_SECRET=test node tests/e2e.js
// It starts the real Express app on a random port and drives it over HTTP.
process.env.JWT_SECRET = process.env.JWT_SECRET || 'test-secret-for-e2e-only-1234567890';
process.env.MONGO_URI = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/hrk-e2e-' + Date.now();

const mongoose = require('mongoose');
const { assertSafeTestDb, resetDb } = require('./helpers');
const app = require('../app');
const { todayIST, addDays, computeEndDate, dateOfInstantIST } = require('../utils/dates');
const { deriveStatus } = require('../services/membershipService');

let base;
let passed = 0;
const failures = [];

const check = (name, cond, extra) => {
  if (cond) { passed += 1; console.log('  ✓', name); }
  else { failures.push(name); console.log('  ✗', name, extra !== undefined ? JSON.stringify(extra) : ''); }
};

const call = async (method, path, { token, body } = {}) => {
  const res = await fetch(base + path, {
    method,
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    body: body ? JSON.stringify(body) : undefined
  });
  const json = await res.json().catch(() => null);
  return { status: res.status, body: json, data: json && json.data };
};

(async () => {
  assertSafeTestDb(process.env.MONGO_URI);
  await mongoose.connect(process.env.MONGO_URI);
  await resetDb();
  const server = app.listen(0);
  base = `http://127.0.0.1:${server.address().port}`;
  const today = todayIST();

  console.log('\nDates (unit)');
  check('1-month plan from 2026-01-01 ends 2026-01-31', computeEndDate('2026-01-01', 1, 'months') === '2026-01-31');
  check('3-month plan from 2026-01-01 ends 2026-03-31', computeEndDate('2026-01-01', 3, 'months') === '2026-03-31');
  check('1-month plan from 2026-01-31 clamps (ends 2026-02-27)', computeEndDate('2026-01-31', 1, 'months') === '2026-02-27');
  check('30-day plan from 2026-02-01 ends 2026-03-02', computeEndDate('2026-02-01', 30, 'days') === '2026-03-02');
  check('leap year: 1 month from 2028-01-31 → 2028-02-28', computeEndDate('2028-01-31', 1, 'months') === '2028-02-28');

  console.log('\nStatus boundaries & timezone (unit)');
  const ms = (startDate, endDate) => [{ startDate, endDate, planName: 'P' }];
  check('7 days left → expiring', deriveStatus(ms('2026-01-01', '2026-03-08'), '2026-03-01').status === 'expiring');
  check('8 days left → active', deriveStatus(ms('2026-01-01', '2026-03-09'), '2026-03-01').status === 'active');
  check('last day (ends today) → expiring, 0 days left', (() => { const d = deriveStatus(ms('2026-01-01', '2026-03-01'), '2026-03-01'); return d.status === 'expiring' && d.daysLeft === 0; })());
  check('day after end → expired', deriveStatus(ms('2026-01-01', '2026-03-01'), '2026-03-02').status === 'expired');
  check('starts tomorrow → upcoming', deriveStatus(ms('2026-03-02', '2026-04-01'), '2026-03-01').status === 'upcoming');
  check('back-to-back renewal extends coverage (not expiring)', deriveStatus([{ startDate: '2026-01-01', endDate: '2026-03-03', planName: 'P' }, { startDate: '2026-03-04', endDate: '2026-06-03', planName: 'P' }], '2026-03-01').status === 'active');
  check('gap between periods is not bridged', deriveStatus([{ startDate: '2026-01-01', endDate: '2026-03-03', planName: 'P' }, { startDate: '2026-03-10', endDate: '2026-06-03', planName: 'P' }], '2026-03-01').status === 'expiring');
  check('IST day rolls over at 18:30 UTC (18:29 UTC = 23:59 IST)', dateOfInstantIST('2026-10-02T18:29:00Z') === '2026-10-02' && dateOfInstantIST('2026-10-02T18:30:00Z') === '2026-10-03');

  console.log('\nAuth');
  let r = await call('POST', '/api/auth/register', { body: { gymName: 'Iron Works', name: 'Owner A', email: 'a@gym.test', password: 'secret123' } });
  check('register gym A → 201 + token', r.status === 201 && r.data.token, r.body);
  const A = r.data.token;
  const gymA = r.data.gym._id;
  r = await call('POST', '/api/auth/register', { body: { gymName: 'Iron Works', name: 'Dup', email: 'a@gym.test', password: 'secret123' } });
  check('duplicate email → 409', r.status === 409);
  r = await call('POST', '/api/auth/register', { body: { gymName: 'X', name: 'Y', email: 'bad', password: '123' } });
  check('invalid registration → 400', r.status === 400, r.body);
  r = await call('POST', '/api/auth/login', { body: { email: 'a@gym.test', password: 'wrong' } });
  check('wrong password → 401', r.status === 401);
  r = await call('POST', '/api/auth/login', { body: { email: 'a@gym.test', password: 'secret123' } });
  check('login → 200 + admin role', r.status === 200 && r.data.user.role === 'admin' && !('password' in r.data.user));
  r = await call('GET', '/api/auth/profile', { token: A });
  check('profile returns user + gym', r.status === 200 && r.data.gym.name === 'Iron Works');
  r = await call('GET', '/api/members');
  check('no token → 401', r.status === 401);
  r = await call('GET', '/api/members', { token: 'garbage' });
  check('bad token → 401', r.status === 401);

  r = await call('POST', '/api/auth/register', { body: { gymName: 'Other Gym', name: 'Owner B', email: 'b@gym.test', password: 'secret123' } });
  const B = r.data.token;

  console.log('\nGym profile');
  r = await call('PUT', '/api/gym', { token: A, body: { name: 'Iron Works Fitness', phone: '+91 98765 43210', city: 'Chennai', address: '12 Main Rd' } });
  check('update gym profile', r.status === 200 && r.data.gym.name === 'Iron Works Fitness' && r.data.gym.phone === '9876543210', r.body);
  r = await call('PUT', '/api/gym', { token: A, body: { name: '' } });
  check('empty gym name → 400', r.status === 400);

  console.log('\nPlans');
  r = await call('POST', '/api/plans', { token: A, body: { name: 'Monthly', durationValue: 1, durationUnit: 'months', price: 1000 } });
  check('create Monthly plan', r.status === 201, r.body);
  const monthly = r.data.plan._id;
  r = await call('POST', '/api/plans', { token: A, body: { name: 'Quarterly', durationValue: 3, durationUnit: 'months', price: 2700 } });
  const quarterly = r.data.plan._id;
  r = await call('POST', '/api/plans', { token: A, body: { name: '10-day pass', durationValue: 10, durationUnit: 'days', price: 300 } });
  const tenDay = r.data.plan._id;
  r = await call('POST', '/api/plans', { token: A, body: { name: 'Bad', durationValue: 0, price: -5 } });
  check('invalid plan → 400', r.status === 400);
  r = await call('PUT', `/api/plans/${tenDay}`, { token: A, body: { name: '10-day pass', durationValue: 10, durationUnit: 'days', price: 300, isActive: false } });
  check('deactivate plan', r.status === 200 && r.data.plan.isActive === false);
  r = await call('GET', '/api/plans?active=true', { token: A });
  check('active=true hides inactive plan', r.data.plans.length === 2);

  console.log('\nMembers');
  r = await call('POST', '/api/members', { token: A, body: { name: 'Arun Kumar', email: 'arun@mail.test', phone: '9876500001', gender: 'male', password: 'arunpass1' } });
  check('create member Arun (with portal login)', r.status === 201 && r.data.member.memberCode === 'M0001' && r.data.member.hasPortalLogin, r.body);
  check('member JSON never exposes qrToken', !('qrToken' in r.data.member));
  const arun = r.data.member._id;
  r = await call('POST', '/api/members', { token: A, body: { name: 'Bala', phone: '9876500002' } });
  check('create member Bala (phone only)', r.status === 201 && r.data.member.memberCode === 'M0002');
  const bala = r.data.member._id;
  r = await call('POST', '/api/members', { token: A, body: { name: 'Charu', email: 'charu@mail.test' } });
  const charu = r.data.member._id;
  r = await call('POST', '/api/members', { token: A, body: { name: 'Divya', phone: '9876500004' } });
  const divya = r.data.member._id;
  r = await call('POST', '/api/members', { token: A, body: { name: 'NoContact' } });
  check('member without email/phone → 400', r.status === 400);
  r = await call('POST', '/api/members', { token: A, body: { name: 'Arun Two', email: 'arun@mail.test' } });
  check('duplicate member email → 409', r.status === 409);
  r = await call('POST', '/api/members', { token: A, body: { name: 'X', phone: 'abc' } });
  check('invalid phone → 400', r.status === 400);
  r = await call('POST', '/api/members', { token: A, body: { name: 'X', phone: '9876500009', dateOfBirth: '2026-02-31' } });
  check('impossible date → 400', r.status === 400);

  r = await call('GET', '/api/members?search=arun', { token: A });
  check('search by name', r.data.members.length === 1 && r.data.members[0].name === 'Arun Kumar');
  r = await call('GET', '/api/members?search=M0002', { token: A });
  check('search by member code', r.data.members.length === 1 && r.data.members[0].name === 'Bala');
  r = await call('GET', '/api/members?search=.*', { token: A });
  check('regex characters are treated literally', r.status === 200 && r.data.members.length === 0);
  r = await call('PUT', `/api/members/${bala}`, { token: A, body: { name: 'Bala Murugan', phone: '9876500002', gender: 'male' } });
  check('edit member', r.status === 200 && r.data.member.name === 'Bala Murugan' && r.data.member.gender === 'male', r.body);
  r = await call('GET', '/api/members?status=none', { token: A });
  check('filter status=none lists members without membership', r.data.members.length === 4);

  console.log('\nMembership assignment & derived status');
  const longAgo = addDays(today, -100);
  r = await call('POST', '/api/memberships', { token: A, body: { memberId: arun, planId: monthly, payment: { amount: 1000, method: 'upi' } } });
  check('assign Monthly to Arun (start defaults to today) + payment', r.status === 201 && r.data.membership.startDate === today && r.data.payment.amount === 1000, r.body);
  check('Arun end date = start + 1 month - 1 day', r.data.membership.endDate === computeEndDate(today, 1, 'months'));
  const arunMs1 = r.data.membership._id;
  r = await call('POST', '/api/memberships', { token: A, body: { memberId: arun, planId: monthly, startDate: today } });
  check('overlapping membership rejected → 409', r.status === 409, r.body);
  r = await call('POST', '/api/memberships', { token: A, body: { memberId: arun, planId: tenDay } });
  check('inactive plan rejected → 400', r.status === 400 || r.status === 409, r.body);

  // Bala: a 10-day pass that ends in 3 days → expiring. (Insert via monthly with explicit past start.)
  r = await call('POST', '/api/memberships', { token: A, body: { memberId: bala, planId: monthly, startDate: addDays(today, -27) } });
  const balaEnd = r.data.membership.endDate;
  const balaDaysLeft = Math.round((new Date(balaEnd) - new Date(today)) / 86400000);
  check('Bala membership ends within 7 days', balaDaysLeft >= 0 && balaDaysLeft <= 7, { balaEnd, balaDaysLeft });
  // Charu: ended long ago → expired.
  r = await call('POST', '/api/memberships', { token: A, body: { memberId: charu, planId: monthly, startDate: longAgo } });
  check('past-dated membership accepted', r.status === 201, r.body);
  // Divya: stays with no membership.

  r = await call('GET', '/api/members', { token: A });
  const st = Object.fromEntries(r.data.members.map((m) => [m.name, m.membership.status]));
  check('Arun = active', st['Arun Kumar'] === 'active', st);
  check('Bala = expiring', st['Bala Murugan'] === 'expiring', st);
  check('Charu = expired', st['Charu'] === 'expired', st);
  check('Divya = none', st['Divya'] === 'none', st);
  r = await call('GET', '/api/members?status=expiring', { token: A });
  check('filter status=expiring', r.data.members.length === 1 && r.data.members[0].name === 'Bala Murugan');
  r = await call('GET', '/api/members?status=expired', { token: A });
  check('filter status=expired', r.data.members.length === 1 && r.data.members[0].name === 'Charu');
  r = await call('GET', '/api/members?status=bogus', { token: A });
  check('invalid status filter → 400', r.status === 400);

  console.log('\nRenewal keeps history');
  r = await call('POST', `/api/members/${arun}/renew`, { token: A, body: { payment: { amount: 1000, method: 'cash' } } });
  check('renew Arun (defaults to previous plan)', r.status === 201, r.body);
  const arunMs1End = computeEndDate(today, 1, 'months');
  check('renewal starts the day after current end (no gap, no overlap)', r.data.membership.startDate === addDays(arunMs1End, 1), r.data.membership);
  r = await call('GET', `/api/members/${arun}`, { token: A });
  check('Arun now has 2 membership records', r.data.memberships.length === 2);
  check('original membership still present, unchanged', r.data.memberships.some((m) => m._id === arunMs1 && m.startDate === today && m.endDate === arunMs1End));
  check('each period shows what was paid', r.data.memberships.every((m) => m.amountPaid === 1000));
  check('Arun payment history has 2 payments', r.data.payments.length === 2);
  // Renew an expired member: starts today.
  r = await call('POST', `/api/members/${charu}/renew`, { token: A, body: { planId: quarterly, payment: { amount: 2700, method: 'card' } } });
  check('renew expired member starts today', r.status === 201 && r.data.membership.startDate === today, r.body);
  r = await call('GET', `/api/members/${charu}`, { token: A });
  check('Charu history: 2 records, now active', r.data.memberships.length === 2 && r.data.membership.status === 'active', r.data.membership);
  // Early renewal clears "expiring".
  r = await call('POST', `/api/members/${bala}/renew`, { token: A, body: {} });
  check('early renewal for Bala (no payment yet)', r.status === 201, r.body);
  r = await call('GET', `/api/members/${bala}`, { token: A });
  check('Bala is no longer "expiring" after early renewal', r.data.membership.status === 'active', r.data.membership);
  const balaMs2 = r.data.memberships.find((m) => m.period === 'upcoming' || m.period === 'current' && m.startDate > addDays(today, -27));
  r = await call('POST', `/api/members/${divya}/renew`, { token: A, body: {} });
  check('renew with no history and no plan → 400', r.status === 400);

  console.log('\nPayments');
  r = await call('POST', '/api/payments', { token: A, body: { memberId: divya, amount: 500, method: 'cash', note: 'registration fee' } });
  check('record standalone payment', r.status === 201 && r.data.payment.paidOn === today, r.body);
  const divyaPayment = r.data.payment._id;
  r = await call('POST', '/api/payments', { token: A, body: { memberId: divya, amount: 0, method: 'cash' } });
  check('zero amount → 400', r.status === 400);
  r = await call('POST', '/api/payments', { token: A, body: { memberId: divya, amount: 10, method: 'bitcoin' } });
  check('unknown method → 400', r.status === 400);
  r = await call('POST', '/api/payments', { token: A, body: { memberId: divya, membershipId: arunMs1, amount: 10, method: 'cash' } });
  check("membership of a different member → 404", r.status === 404);
  r = await call('GET', '/api/payments', { token: A });
  check('payment history lists 4 payments (Bala renewal has none) + total 5200', r.status === 200 && r.data.payments.length === 4 && r.data.totalAmount === 1000 + 1000 + 2700 + 500, { n: r.data.payments.length, t: r.data.totalAmount });
  check('payment rows carry member name', r.data.payments.every((p) => p.member && p.member.name));
  r = await call('GET', '/api/payments?search=arun', { token: A });
  check('payments search by member', r.data.payments.length === 2);
  r = await call('GET', '/api/payments?method=upi', { token: A });
  check('payments filter by method', r.data.payments.length === 1);
  r = await call('GET', `/api/payments?from=${addDays(today, 1)}`, { token: A });
  check('payments date filter excludes today', r.data.payments.length === 0);

  console.log('\nQR check-in');
  r = await call('GET', `/api/members/${arun}`, { token: A });
  const arunQr = r.data.qrPayload;
  check('QR payload is opaque (no name/email/phone/id)', arunQr.startsWith('hrk:') && !/arun|9876|mail/i.test(arunQr) && !arunQr.includes(arun), arunQr);
  r = await call('POST', '/api/attendance/check-in', { token: A, body: { qrToken: arunQr } });
  check('valid QR → checked in (201)', r.status === 201 && r.data.result === 'checked_in' && r.data.member.name === 'Arun Kumar', r.body);
  r = await call('POST', '/api/attendance/check-in', { token: A, body: { qrToken: arunQr } });
  check('immediate re-scan → duplicate, no new record', r.status === 200 && r.data.result === 'duplicate');
  r = await call('GET', `/api/attendance?date=${today}`, { token: A });
  check('only ONE attendance record after two scans', r.data.attendance.length === 1 && r.data.attendance[0].member.name === 'Arun Kumar', r.data);

  r = await call('GET', `/api/members/${bala}`, { token: A });
  r = await call('POST', '/api/attendance/check-in', { token: A, body: { qrToken: r.data.qrPayload } });
  check('expiring member can check in', r.status === 201 && r.data.result === 'checked_in');

  // Make Charu "expired" check by creating a fresh member with only an old membership.
  r = await call('POST', '/api/members', { token: A, body: { name: 'Eswar', phone: '9876500005' } });
  const eswar = r.data.member._id;
  await call('POST', '/api/memberships', { token: A, body: { memberId: eswar, planId: monthly, startDate: longAgo } });
  r = await call('GET', `/api/members/${eswar}`, { token: A });
  const eswarQr = r.data.qrPayload;
  r = await call('POST', '/api/attendance/check-in', { token: A, body: { qrToken: eswarQr } });
  check('expired member denied (403) with reason', r.status === 403 && r.body.data.result === 'denied' && r.body.data.reason === 'expired', r.body);
  r = await call('GET', `/api/members/${divya}`, { token: A });
  r = await call('POST', '/api/attendance/check-in', { token: A, body: { qrToken: r.data.qrPayload } });
  check('member with no membership denied', r.status === 403 && r.body.data.reason === 'none');
  r = await call('POST', '/api/attendance/check-in', { token: A, body: { qrToken: 'hrk:doesNotExist123' } });
  check('unknown QR → 404', r.status === 404);
  r = await call('POST', '/api/attendance/check-in', { token: A, body: {} });
  check('empty QR → 400', r.status === 400);
  r = await call('POST', '/api/attendance/check-in', { token: B, body: { qrToken: arunQr } });
  check("gym B cannot check in gym A's member with A's QR (404)", r.status === 404);
  r = await call('PUT', `/api/members/${eswar}`, { token: A, body: { status: 'inactive' } });
  r = await call('POST', '/api/attendance/check-in', { token: A, body: { qrToken: eswarQr } });
  check('inactive member denied', r.status === 403 && r.body.data.reason === 'inactive');
  await call('DELETE', `/api/members/${eswar}`, { token: A });

  r = await call('POST', `/api/members/${arun}/regenerate-qr`, { token: A });
  const newQr = r.data.qrPayload;
  check('regenerate QR gives a different token', newQr !== arunQr);
  r = await call('POST', '/api/attendance/check-in', { token: A, body: { qrToken: arunQr } });
  check('old QR no longer works', r.status === 404);

  console.log('\nAttendance');
  r = await call('GET', `/api/attendance?from=${addDays(today, -30)}&to=${today}`, { token: A });
  check('attendance range filter', r.data.attendance.length === 2);
  r = await call('GET', '/api/attendance?search=bala', { token: A });
  check('attendance search by member name', r.data.attendance.length === 1 && r.data.attendance[0].member.name === 'Bala Murugan');
  r = await call('GET', `/api/attendance?date=${addDays(today, -1)}`, { token: A });
  check('yesterday has no attendance', r.data.attendance.length === 0);

  console.log('\nDashboard');
  r = await call('GET', '/api/dashboard', { token: A });
  const t = r.data.totals;
  // members: Arun(active) Bala(active after renewal) Charu(active after renewal) Divya(none) = 4
  check('totalMembers = 4', t.totalMembers === 4, t);
  check('activeMemberships = 3 (Arun, Bala, Charu)', t.activeMemberships === 3, t);
  check("todayCheckIns = 2", t.todayCheckIns === 2, t);
  check("todayRevenue = 1000+1000+2700+500 = 5200", t.todayRevenue === 5200, t);
  check('unpaid list shows memberships with no payment (Bala renewal)', r.data.attention.unpaid.some((u) => u.name === 'Bala Murugan') && r.data.attention.unpaid.length === r.data.attention.unpaidCount, r.data.attention.unpaid);

  console.log('\nGym isolation');
  r = await call('GET', '/api/members', { token: B });
  check('gym B sees 0 members', r.data.members.length === 0);
  r = await call('GET', `/api/members/${arun}`, { token: B });
  check("gym B cannot read gym A's member (404)", r.status === 404);
  r = await call('PUT', `/api/members/${arun}`, { token: B, body: { name: 'Hacked' } });
  check("gym B cannot edit gym A's member", r.status === 404);
  r = await call('DELETE', `/api/members/${arun}`, { token: B });
  check("gym B cannot delete gym A's member", r.status === 404);
  r = await call('POST', '/api/payments', { token: B, body: { memberId: arun, amount: 5, method: 'cash' } });
  check("gym B cannot record payment for A's member", r.status === 404);
  r = await call('POST', '/api/memberships', { token: B, body: { memberId: arun, planId: monthly } });
  check("gym B cannot assign to A's member / use A's plan", r.status === 404);
  r = await call('GET', '/api/payments', { token: B });
  check('gym B sees 0 payments', r.data.payments.length === 0 && r.data.totalAmount === 0);
  r = await call('GET', '/api/attendance', { token: B });
  check('gym B sees 0 attendance', r.data.attendance.length === 0);
  r = await call('GET', '/api/plans', { token: B });
  check('gym B sees 0 plans', r.data.plans.length === 0);
  r = await call('PUT', `/api/plans/${monthly}`, { token: B, body: { name: 'x', durationValue: 1, price: 1 } });
  check("gym B cannot edit gym A's plan", r.status === 404);
  r = await call('DELETE', `/api/payments/${divyaPayment}`, { token: B });
  check("gym B cannot delete gym A's payment", r.status === 404);
  r = await call('GET', '/api/dashboard', { token: B });
  check('gym B dashboard is all zeros', r.data.totals.totalMembers === 0 && r.data.totals.todayRevenue === 0 && r.data.totals.todayCheckIns === 0, r.data.totals);

  console.log('\nMember portal');
  r = await call('POST', '/api/auth/login', { body: { email: 'arun@mail.test', password: 'arunpass1' } });
  check('member login → role member', r.status === 200 && r.data.user.role === 'member', r.body);
  const M = r.data.token;
  r = await call('GET', '/api/me', { token: M });
  check('portal overview: status + QR + history', r.status === 200 && r.data.membership.status === 'active' && r.data.qrPayload === newQr && r.data.memberships.length === 2, r.body);
  check('portal shows gym name', r.data.gym.name === 'Iron Works Fitness');
  r = await call('GET', '/api/me/attendance', { token: M });
  check('portal attendance (own only)', r.status === 200 && r.data.attendance.length === 1);
  r = await call('GET', '/api/me/payments', { token: M });
  check('portal payments (own only)', r.status === 200 && r.data.payments.length === 2 && r.data.payments.every((p) => p.memberId === arun));
  r = await call('GET', '/api/members', { token: M });
  check('member cannot use admin API (403)', r.status === 403);
  r = await call('GET', '/api/dashboard', { token: M });
  check('member cannot read dashboard (403)', r.status === 403);
  r = await call('POST', '/api/attendance/check-in', { token: M, body: { qrToken: newQr } });
  check('member cannot call check-in (403)', r.status === 403);
  r = await call('GET', '/api/me', { token: A });
  check('admin cannot use member portal API (403)', r.status === 403);

  console.log('\nPortal login management');
  r = await call('PUT', `/api/members/${bala}`, { token: A, body: { email: 'bala@mail.test', password: 'balapass1' } });
  check('admin grants portal login to existing member', r.status === 200 && r.data.member.hasPortalLogin, r.body);
  r = await call('POST', '/api/auth/login', { body: { email: 'bala@mail.test', password: 'balapass1' } });
  check('new member login works', r.status === 200);

  console.log('\nDelete');
  r = await call('DELETE', `/api/payments/${divyaPayment}`, { token: A });
  check('delete mistaken payment', r.status === 200);
  r = await call('DELETE', `/api/members/${arun}`, { token: A });
  check('delete member', r.status === 200);
  r = await call('GET', `/api/members/${arun}`, { token: A });
  check('deleted member is gone (404)', r.status === 404);
  r = await call('POST', '/api/auth/login', { body: { email: 'arun@mail.test', password: 'arunpass1' } });
  check("deleted member's portal login is removed", r.status === 401);
  r = await call('GET', '/api/payments?search=arun', { token: A });
  check("deleted member's payments are kept, labelled by name", r.data.payments.length === 2 && r.data.payments.every((p) => p.member.deleted && p.member.name === 'Arun Kumar'), r.data.payments);
  r = await call('GET', '/api/dashboard', { token: A });
  check('dashboard totals update after delete', r.data.totals.totalMembers === 3 && r.data.totals.todayCheckIns === 1, r.data.totals);

  console.log('\nCSV import');
  const importRows = [
    { name: 'Farah', phone: '98765 00010', gender: 'female', joinedDate: '2026-01-05' },
    { name: 'Gopal', email: 'gopal@mail.test' },
    { name: 'Dup Phone', phone: '9876500010' },
    { name: '', phone: '9876500011' },
    { name: 'No Contact' },
    { name: 'Bad Date', phone: '9876500012', joinedDate: '2026-13-40' },
    { name: 'Gopal Again', email: 'GOPAL@mail.test' }
  ];
  r = await call('POST', '/api/members/import', { token: A, body: { rows: importRows, dryRun: true } });
  check('dry run: 2 valid, 2 duplicates, 3 errors', r.status === 200 && r.data.summary.valid === 2 && r.data.summary.duplicates === 2 && r.data.summary.errors === 3, r.data && r.data.summary);
  r = await call('GET', '/api/members?search=Farah', { token: A });
  check('dry run creates nothing', r.data.members.length === 0);
  r = await call('POST', '/api/members/import', { token: A, body: { rows: importRows } });
  check('import creates only the 2 valid rows', r.data.summary.imported === 2, r.data.summary);
  r = await call('GET', '/api/members?search=Farah', { token: A });
  check('imported member exists with code + normalised phone', r.data.members.length === 1 && r.data.members[0].phone === '9876500010' && /^M\d{4}$/.test(r.data.members[0].memberCode), r.data.members[0]);
  r = await call('POST', '/api/members/import', { token: A, body: { rows: [] } });
  check('empty import → 400', r.status === 400);
  r = await call('POST', '/api/members/import', { token: B, body: { rows: [{ name: 'Farah', phone: '9876500010' }] } });
  check('same phone is allowed in a different gym', r.data.summary.imported === 1);
  r = await call('POST', '/api/auth/login', { body: { email: 'bala@mail.test', password: 'balapass1' } });
  r = await call('POST', '/api/members/import', { token: r.data.token, body: { rows: [{ name: 'x', phone: '9999999999' }] } });
  check('member cannot import (403)', r.status === 403);
  r = await call('GET', '/api/dashboard', { token: A });

  console.log('\nErrors');
  r = await call('GET', '/api/nope', { token: A });
  check('unknown route → 404 JSON', r.status === 404 && r.body.success === false);
  r = await call('GET', '/api/members/not-an-id', { token: A });
  check('malformed id → 400', r.status === 400);
  const raw = await fetch(base + '/api/auth/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{bad json' });
  check('malformed JSON → 400', raw.status === 400);

  server.close();
  await mongoose.connection.dropDatabase();
  await mongoose.disconnect();
  console.log(`\n${passed} passed, ${failures.length} failed`);
  if (failures.length) { console.log('FAILED:\n - ' + failures.join('\n - ')); process.exit(1); }
  process.exit(0);
})().catch((e) => { console.error('Test run crashed:', e); process.exit(2); });
