/* global document */
// UI smoke test: runs the REAL frontend modules (router, pages, services) inside
// jsdom against the REAL API and database, driving them like a user would
// (fill form → submit → read the screen). It is not a visual/layout test —
// responsive layout and camera scanning still need a manual check on a phone.
//   node tests/ui-smoke.js          (needs a MongoDB-compatible DB, like tests/e2e.js)
process.env.JWT_SECRET = process.env.JWT_SECRET || 'test-secret-for-ui-smoke-1234567890';
process.env.MONGO_URI = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/hrk-ui-' + Date.now();

const path = require('path');
const fs = require('fs');
const { pathToFileURL } = require('url');
const mongoose = require('mongoose');
const { assertSafeTestDb, resetDb } = require('./helpers');
const { JSDOM, ResourceLoader } = require('jsdom');
const app = require('../app');

const FRONTEND = path.join(__dirname, '..', '..', 'frontend');
let passed = 0;
const failures = [];
const check = (name, cond, extra) => {
  if (cond) { passed += 1; console.log('  ✓', name); }
  else { failures.push(name); console.log('  ✗', name, extra !== undefined ? String(extra).slice(0, 300) : ''); }
};
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

(async () => {
  assertSafeTestDb(process.env.MONGO_URI);
  await mongoose.connect(process.env.MONGO_URI);
  await resetDb();
  const server = app.listen(0);
  const apiBase = `http://127.0.0.1:${server.address().port}`;

  // Serve the vendored QR libraries (frontend/vendor) so the real QR drawing code runs; block everything else.
  class Loader extends ResourceLoader {
    fetch(url) {
      const m = /\/vendor\/([\w.-]+\.js)$/.exec(url);
      if (m) return Promise.resolve(fs.readFileSync(path.join(FRONTEND, 'vendor', m[1])));
      return Promise.resolve(Buffer.from(''));
    }
  }
  const html = fs.readFileSync(path.join(FRONTEND, 'index.html'), 'utf8')
    .replace(/<script[\s\S]*?<\/script>/g, '').replace(/<link[^>]*>/g, '');
  const dom = new JSDOM(html, { url: 'http://localhost:5173/', runScripts: 'dangerously', resources: new Loader(), pretendToBeVisual: true });
  const { window } = dom;
  window.HRK_CONFIG = { apiBaseUrl: apiBase };
  window.scrollTo = () => {};
  Object.assign(globalThis, { window, document: window.document, localStorage: window.localStorage, requestAnimationFrame: window.requestAnimationFrame.bind(window), cancelAnimationFrame: window.cancelAnimationFrame.bind(window) });

  await import(pathToFileURL(path.join(FRONTEND, 'js', 'app.js')).href);
  document.dispatchEvent(new window.Event('DOMContentLoaded'));

  const $ = (s) => document.querySelector(s);
  const main = () => $('#app-main');
  const text = () => main().textContent.replace(/\s+/g, ' ');
  const waitFor = async (fn, label, ms = 6000) => {
    const t0 = Date.now();
    while (Date.now() - t0 < ms) { try { const v = fn(); if (v) return v; } catch (e) { /* retry */ } await sleep(40); }
    throw new Error('Timed out waiting for: ' + label + ' | screen: ' + text().slice(0, 200));
  };
  const go = async (hash) => { window.location.hash = hash; await sleep(30); };
  const fill = (root, name, value) => { const el = root.querySelector(`[name="${name}"]`); el.value = value; };
  const submit = (form) => form.dispatchEvent(new window.Event('submit', { bubbles: true, cancelable: true }));
  const click = (el) => el.dispatchEvent(new window.MouseEvent('click', { bubbles: true, cancelable: true }));

  console.log('\nLogged-out routing');
  await waitFor(() => window.location.hash === '#/login' && $('#loginForm'), 'redirect to login');
  check('opens on the login page', /Log in/.test(text()) && /HRK Gym OS/.test(text()));
  await go('#/members');
  await waitFor(() => window.location.hash === '#/login', 'guard');
  check('protected route redirects to login', true);

  console.log('\nRegister gym');
  await go('#/register');
  await waitFor(() => $('#registerForm'), 'register form');
  let f = $('#registerForm');
  fill(f, 'gymName', 'Smoke Gym'); fill(f, 'name', 'Owner'); fill(f, 'email', 'owner@smoke.test'); fill(f, 'password', 'secret123');
  submit(f);
  await waitFor(() => window.location.hash === '#/dashboard', 'dashboard after register');
  await waitFor(() => /no members yet/i.test(text()), 'empty dashboard');
  check('registers and lands on dashboard with a helpful empty state', /Your gym has no members yet\./.test(text()));
  check('header shows brand + gym name', /HRK Gym OS/.test($('#app-header').textContent) && /Smoke Gym/.test($('#app-header').textContent), $('#app-header').textContent);
  check('bottom nav present for admin', /Check-in/.test($('#app-bottomnav').textContent) && /More/.test($('#app-bottomnav').textContent));
  check('no old product wording on screen', !/fitzy|college|workout|AI coach|recommendation/i.test(document.body.textContent));

  console.log('\nEmpty states');
  await go('#/members'); await waitFor(() => /Your gym has no members yet/.test(text()), 'members empty');
  check('members empty state', true);
  await go('#/payments'); await waitFor(() => /No payments recorded yet/.test(text()), 'payments empty');
  check('payments empty state', true);
  await go('#/attendance'); await waitFor(() => /No check-ins yet today/.test(text()), 'attendance empty');
  check('attendance empty state', true);
  await go('#/plans'); await waitFor(() => /No membership plans yet/.test(text()), 'plans empty');
  check('plans empty state', true);

  console.log('\nCreate a plan');
  click($('#addPlan'));
  await waitFor(() => $('#planForm'), 'plan modal');
  f = $('#planForm');
  click(f.querySelector('[data-preset="0"]'));
  check('preset fills Monthly / 1 / months', f.elements.name.value === 'Monthly' && f.elements.durationValue.value === '1' && f.elements.durationUnit.value === 'months');
  fill(f, 'price', '1200');
  submit(f);
  await waitFor(() => /Monthly/.test(text()) && /1 month/.test(text()) && !$('#planForm'), 'plan listed');
  check('plan created and listed with price', /₹1,200/.test(text()), text());

  console.log('\nAdd member');
  await go('#/members/new'); await waitFor(() => $('#memberForm'), 'member form');
  f = $('#memberForm');
  submit(f);
  await waitFor(() => /Please enter the member/.test($('#formError').textContent), 'validation');
  check('empty form shows a validation message', true);
  fill(f, 'name', 'Arun Kumar'); fill(f, 'phone', '9876543210'); fill(f, 'email', 'arun@smoke.test'); fill(f, 'password', 'arunpass1');
  submit(f);
  await waitFor(() => /^#\/members\/[a-f0-9]{24}$/.test(window.location.hash), 'redirect to member');
  await waitFor(() => /Arun Kumar/.test(text()) && /No membership assigned yet/.test(text()), 'member detail');
  check('member created; detail shows "no membership"', /M0001/.test(text()));
  const memberId = window.location.hash.split('/')[2];
  check('QR rendered as SVG for the member', await waitFor(() => $('#qr svg'), 'qr svg').then(() => true));

  console.log('\nAssign plan + payment');
  click($('#msBtn'));
  await waitFor(() => $('#msForm'), 'membership modal');
  f = $('#msForm');
  check('plan dropdown lists the plan; amount prefilled', /Monthly/.test(f.elements.planId.textContent) && f.elements.amount.value === '1200');
  submit(f);
  await waitFor(() => /Active/.test(text()) && /Monthly/.test(text()) && !$('#msForm'), 'status active');
  check('member shows Active with plan', /Active/.test(text()));
  check('history + payment history populated', /Paid/.test(text()) && /₹1,200/.test(text()), text());

  console.log('\nRenewal keeps history');
  click($('#msBtn'));
  await waitFor(() => $('#msForm'), 'renew modal');
  check('button says Renew once history exists', /Renew/.test($('#msBtn').textContent));
  submit($('#msForm'));
  await waitFor(() => (text().match(/Monthly/g) || []).length >= 2 && !$('#msForm'), 'two periods');
  check('two membership periods listed after renewal', true);

  console.log('\nMembers list, search, filter');
  await go('#/members'); await waitFor(() => /Arun Kumar/.test(text()), 'list');
  check('member appears in list with Active chip', /Active/.test(text()));
  const search = $('#search'); search.value = 'zzzz'; search.dispatchEvent(new window.Event('input', { bubbles: true }));
  await waitFor(() => /No members match your search/.test(text()), 'no match');
  check('search with no match shows empty message', true);
  search.value = 'arun'; search.dispatchEvent(new window.Event('input', { bubbles: true }));
  await waitFor(() => /Arun Kumar/.test(text()), 'match');
  check('search finds the member', true);
  const sf = $('#statusFilter'); sf.value = 'expired'; sf.dispatchEvent(new window.Event('change', { bubbles: true }));
  await waitFor(() => /No members match/.test(text()), 'filter');
  check('status filter hides non-matching members', true);

  console.log('\nQR check-in screen');
  await go('#/checkin'); await waitFor(() => $('#manualForm'), 'checkin');
  const detail = await (await fetch(`${apiBase}/api/members/${memberId}`, { headers: { Authorization: 'Bearer ' + localStorage.getItem('hrk_token') } })).json();
  $('#manualCode').value = detail.data.qrPayload;
  submit($('#manualForm'));
  await waitFor(() => /Checked in/.test($('#result').textContent), 'checked in');
  check('valid QR → "Checked in" with member + plan', /Arun Kumar/.test($('#result').textContent) && /Monthly/.test($('#result').textContent), $('#result').textContent);
  $('#manualCode').value = detail.data.qrPayload;
  submit($('#manualForm'));
  await waitFor(() => /Already checked in/.test($('#result').textContent), 'duplicate');
  check('re-scan → "Already checked in"', true);
  $('#manualCode').value = 'hrk:bogus';
  submit($('#manualForm'));
  await waitFor(() => /QR not recognised/.test($('#result').textContent), 'unknown');
  check('unknown QR → "QR not recognised"', true);
  check("today's check-ins list shows one entry", await waitFor(() => /Arun Kumar/.test($('#recent').textContent), 'recent').then(() => true));
  check('camera is off by default (no stream started)', !!$('#camPlaceholder') && !$('#camPlaceholder').classList.contains('hidden'));

  console.log('\nDashboard (real numbers)');
  await go('#/dashboard');
  await waitFor(() => /Total members/.test(text()), 'dashboard');
  const metrics = {};
  document.querySelectorAll('main a.flex.flex-col.gap-1, #app-main a[href^="#/"]').forEach((a) => {
    const label = a.querySelector('span')?.textContent.trim();
    const val = a.querySelector('.font-metric-val')?.textContent.trim();
    if (label && val) metrics[label] = val;
  });
  check('Total members = 1', metrics['Total members'] === '1', JSON.stringify(metrics));
  check('Active memberships = 1', metrics['Active memberships'] === '1', JSON.stringify(metrics));
  check("Today's check-ins = 1", metrics["Today's check-ins"] === '1', JSON.stringify(metrics));
  check("Today's revenue = ₹2,400 (assignment + renewal payments of ₹1,200)", metrics["Today's revenue"] === '₹2,400', JSON.stringify(metrics));
  check('Expiring soon = 0', metrics['Expiring soon'] === '0');

  console.log('\nPayments + attendance pages');
  await go('#/payments'); await waitFor(() => /₹2,400/.test(text()), 'payments');
  check('payments page lists payments and total', /Arun Kumar/.test(text()) && /2 payments/.test(text()), text());
  await go('#/attendance'); await waitFor(() => /Arun Kumar/.test(text()), 'attendance');
  check("attendance page shows today's check-in", /1 check-in on today/.test(text()), text());

  console.log('\nCSV import page');
  await go('#/members/import'); await waitFor(() => $('#file'), 'import');
  const { csvToMemberRows } = await import(pathToFileURL(path.join(FRONTEND, 'js', 'utils', 'csv.js')).href);
  const parsed = csvToMemberRows('Name,Mobile,"Email"\n"Smith, John",98765 11111,j@x.test\nMeena,,\n');
  check('CSV parser handles quotes, commas, header aliases', parsed.rows.length === 2 && parsed.rows[0].name === 'Smith, John' && parsed.rows[0].phone === '98765 11111' && parsed.rows[0].email === 'j@x.test', JSON.stringify(parsed));

  console.log('\nGym profile');
  await go('#/gym'); await waitFor(() => $('#gymForm'), 'gym form');
  f = $('#gymForm'); fill(f, 'name', 'Smoke Gym Renamed'); fill(f, 'city', 'Chennai');
  submit(f);
  await waitFor(() => /Smoke Gym Renamed/.test($('#app-header').textContent), 'header updated');
  check('gym profile saved and header updates', true);

  console.log('\nLogout and member portal');
  click($('#logoutBtn'));
  await waitFor(() => window.location.hash === '#/login', 'logout');
  check('logout returns to login and clears the session', !localStorage.getItem('hrk_token'));
  await waitFor(() => $('#loginForm'), 'login form');
  f = $('#loginForm'); fill(f, 'email', 'arun@smoke.test'); fill(f, 'password', 'wrongpass');
  submit(f);
  await waitFor(() => /Invalid email or password/.test($('#formError').textContent), 'bad login');
  check('wrong password shows an error', true);
  fill(f, 'password', 'arunpass1'); submit(f);
  await waitFor(() => window.location.hash === '#/portal', 'portal');
  await waitFor(() => /My membership|Hi, Arun/.test(text()) && $('#qr svg'), 'portal content');
  check('member lands on the portal (not the admin dashboard)', /Hi, Arun/.test(text()));
  check('portal shows membership status and personal QR', /Active/.test(text()) && !!$('#qr svg'));
  check('portal bottom nav has no admin items', !/\bMembers\b|Check-in|Dashboard/.test($('#app-bottomnav').textContent));
  await go('#/members');
  await waitFor(() => window.location.hash === '#/portal', 'member kept out of admin');
  check('member cannot open admin pages (redirected)', true);
  await go('#/portal/attendance'); await waitFor(() => /1 visit/.test(text()), 'portal attendance');
  check('portal attendance history', true);
  await go('#/portal/payments'); await waitFor(() => /₹1,200/.test(text()), 'portal payments');
  check('portal payment history', (text().match(/₹1,200/g) || []).length === 2, text());

  server.close(); await mongoose.connection.dropDatabase(); await mongoose.disconnect();
  console.log(`\n${passed} passed, ${failures.length} failed`);
  if (failures.length) { console.log('FAILED:\n - ' + failures.join('\n - ')); process.exit(1); }
  process.exit(0);
})().catch((e) => { console.error('UI smoke crashed:', e); process.exit(2); });
