// Shared test helpers.
const mongoose = require('mongoose');

// The tests DROP their database. Refuse to run against anything that isn't clearly a throwaway test DB,
// so `MONGO_URI` exported for development (or pointing at Atlas) can never be wiped by accident.
function assertSafeTestDb(uri) {
  const dbName = (uri.split('?')[0].split('/').pop() || '').toLowerCase();
  if (!/^hrk-(test|e2e|ui|probe)/.test(dbName) && process.env.ALLOW_TEST_DB_DROP !== '1') {
    console.error(`Refusing to run: these tests DROP the database, and "${dbName || '(default)'}" does not look like a test database.`);
    console.error('Use a database name starting with "hrk-test" (e.g. mongodb://127.0.0.1:27017/hrk-test), or set ALLOW_TEST_DB_DROP=1 if you are sure.');
    process.exit(3);
  }
}

// dropDatabase also drops indexes, so rebuild them: otherwise unique-index behaviour would go untested.
async function resetDb() {
  await mongoose.connection.dropDatabase();
  await Promise.all(Object.values(mongoose.models).map((m) => m.createIndexes()));
}

module.exports = { assertSafeTestDb, resetDb };
