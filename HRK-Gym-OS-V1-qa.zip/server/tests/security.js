// Security / correctness regression suite (V1 audit). Drives the real Express app over HTTP.
//   MONGO_URI=mongodb://127.0.0.1:27017/hrk-test-sec node tests/security.js
process.env.JWT_SECRET = process.env.JWT_SECRET || 'test-secret-for-security-suite-1234567890';
process.env.MONGO_URI = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/hrk-test-sec-' + Date.now();
process.env.CORS_ORIGIN = 'https://gym.example.com';

const mongoose = require('mongoose');
const jwt = require('jsonwebtoken');
const { assertSafeTestDb, resetDb } = require('./helpers');
const app = require('../app');
const Member = require('../models/Member');
const Attendance = require('../models/Attendance');
const { todayIST, addDays, computeEndDate } = require('../utils/dates');
const { deriveStatus } = require('../services/membershipService');

let base; let passed = 0; const failures = [];
const check = (name, cond, extra) => {
  if (cond) { passed += 1; console.log('  ✓', name); }
  else { failures.push(name); console.log('  ✗', name, extra !== undefined ? String(typeof extra === 'string' ? extra : JSON.stringify(extra)).slice(0, 300) : ''); }
};
const call = async (method, path, { token, body, raw, headers } = {}) => {
  const res = await fetch(base + path, {
    method,
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}), ...(headers || {}) },
    body: raw !== undefined ? raw : body ? JSON.stringify(body) : undefined
  });
  const json = await res.json().catch(() => null);
  return { status: res.status, body: json, data: json && json.data, headers: res.headers };
};

(async () => {
  assertSafeTestDb(process.env.MONGO_URI);
  await mongoose.connect(process.env.MONGO_URI);
  await resetDb();
  const server = app.listen(0);
  base = `http://127.0.0.1:${server.address().port}`;
  const today = todayIST();
  let r;

  // ---------- fixtures: two gyms with real data ----------
  const reg = async (gymName, email) => (await call('POST', '/api/auth/register', { body: { gymName, name: 'Owner ' + gymName, email, password: 'secret123' } }));
  r = await reg('Gym A', 'a@test.dev'); const A = r.data.token; const gymA = r.data.gym._id;
  r = await reg('Gym B', 'b@test.dev'); const B = r.data.token; const gymB = r.data.gym._id;
  const mk = async (tok, name, phone, extra = {}) => (await call('POST', '/api/members', { token: tok, body: { name, phone, ...extra } })).data.member._id;
  const plan = async (tok, name, v, unit, price) => (await call('POST', '/api/plans', { token: tok, body: { name, durationValue: v, durationUnit: unit, price } })).data.plan._id;

  const planA = await plan(A, 'Monthly', 1, 'months', 1000);
  const planB = await plan(B, 'Monthly', 1, 'months', 900);
  const memA = await mk(A, 'Alice A', '9000000001', { email: 'alice@a.test', password: 'alicepass1' });
  const memB = await mk(B, 'Bob B', '9000000002', { email: 'bob@b.test', password: 'bobpass123' });
  r = await call('POST', '/api/memberships', { token: A, body: { memberId: memA, planId: planA, payment: { amount: 1000, method: 'cash' } } });
  const msA = r.data.membership._id; const payA = r.data.payment._id;
  await call('POST', '/api/memberships', { token: B, body: { memberId: memB, planId: planB, payment: { amount: 900, method: 'upi' } } });
  const qrA = (await call('GET', `/api/members/${memA}`, { token: A })).data.qrPayload;
  await call('POST', '/api/attendance/check-in', { token: A, body: { qrToken: qrA } });
  r = await call('POST', '/api/auth/login', { body: { email: 'alice@a.test', password: 'alicepass1' } }); const alice = r.data.token;
  r = await call('POST', '/api/auth/login', { body: { email: 'bob@b.test', password: 'bobpass123' } }); const bob = r.data.token;

  console.log('\n[1] GYM ISOLATION — can Gym B touch Gym A?');
  const snapshot = async () => {
    const m = (await call('GET', `/api/members/${memA}`, { token: A })).data;
    return JSON.stringify({ name: m.member.name, phone: m.member.phone, ms: m.memberships.length, pay: m.payments.length, att: m.attendance.length, qr: m.qrPayload });
  };
  const before = await snapshot();
  const denied = async (label, p) => { const x = await p; check(label, x.status === 404 || x.status === 403, `${x.status} ${JSON.stringify(x.body).slice(0, 100)}`); };
  await denied('B reads A member', call('GET', `/api/members/${memA}`, { token: B }));
  await denied('B edits A member', call('PUT', `/api/members/${memA}`, { token: B, body: { name: 'HACK', status: 'inactive' } }));
  await denied('B deletes A member', call('DELETE', `/api/members/${memA}`, { token: B }));
  await denied('B renews A member', call('POST', `/api/members/${memA}/renew`, { token: B, body: { planId: planB } }));
  await denied('B regenerates A member QR', call('POST', `/api/members/${memA}/regenerate-qr`, { token: B }));
  await denied("B assigns A's member a B plan", call('POST', '/api/memberships', { token: B, body: { memberId: memA, planId: planB } }));
  await denied("B assigns its member A's plan", call('POST', '/api/memberships', { token: B, body: { memberId: memB, planId: planA } }));
  await denied('B records payment for A member', call('POST', '/api/payments', { token: B, body: { memberId: memA, amount: 5, method: 'cash' } }));
  await denied("B links payment to A's membership", call('POST', '/api/payments', { token: B, body: { memberId: memB, membershipId: msA, amount: 5, method: 'cash' } }));
  await denied('B deletes A payment', call('DELETE', `/api/payments/${payA}`, { token: B }));
  await denied('B edits A plan', call('PUT', `/api/plans/${planA}`, { token: B, body: { name: 'x', durationValue: 1, price: 1 } }));
  await denied('B deletes A plan', call('DELETE', `/api/plans/${planA}`, { token: B }));
  r = await call('POST', '/api/attendance/check-in', { token: B, body: { qrToken: qrA } });
  check("B scans A's QR → not recognised (404, no member info leaked)", r.status === 404 && !JSON.stringify(r.body).includes('Alice'), r.body);
  r = await call('GET', `/api/attendance?memberId=${memA}`, { token: B });
  check("B filters attendance by A's memberId → empty", r.status === 200 && r.data.attendance.length === 0);
  r = await call('GET', `/api/payments?memberId=${memA}`, { token: B });
  check("B filters payments by A's memberId → empty", r.status === 200 && r.data.payments.length === 0 && r.data.totalAmount === 0);
  r = await call('GET', '/api/members?search=alice', { token: B });
  check("B searches A's member name → nothing", r.data.members.length === 0);
  r = await call('GET', '/api/members?search=9000000001', { token: B });
  check("B searches A's phone → nothing", r.data.members.length === 0);
  r = await call('POST', '/api/members/import', { token: B, body: { rows: [{ name: 'Same Phone', phone: '9000000001' }] } });
  check("same phone as A's member imports fine into B (no cross-gym duplicate leak)", r.data.summary.imported === 1, r.data.summary);
  r = await call('GET', '/api/dashboard', { token: B });
  check('B dashboard counts only B (2 members, 1 check-in = 0)', r.data.totals.totalMembers === 2 && r.data.totals.todayCheckIns === 0 && r.data.totals.todayRevenue === 900, r.data.totals);
  check("A's data completely unchanged after all of B's attempts", (await snapshot()) === before);
  r = await call('GET', '/api/me', { token: bob });
  check("B's member portal shows only B's data", r.data.member.name === 'Bob B' && r.data.gym.name === 'Gym B');
  r = await call('GET', '/api/me/payments', { token: alice });
  check("A's member sees only own payments", r.data.payments.length === 1 && r.data.payments[0].amount === 1000);
  r = await call('GET', `/api/me?memberId=${memB}`, { token: alice });
  check("member can't select another member via query param (still sees self)", r.data.member.name === 'Alice A');
  r = await call('GET', `/api/me/attendance?memberId=${memB}`, { token: alice });
  check("member attendance ignores memberId param", r.data.attendance.length === 1);

  console.log('\n[2] MASS ASSIGNMENT / PRIVILEGE ESCALATION');
  r = await call('POST', '/api/auth/register', { body: { gymName: 'Evil', name: 'E', email: 'evil@test.dev', password: 'secret123', role: 'member', gymId: gymA, memberId: memA } });
  const evil = r.data.token;
  check('register ignores role / gymId in body (new admin of a NEW gym)', r.data.user.role === 'admin' && r.data.user.gymId !== gymA && r.data.gym.name === 'Evil', r.data.user);
  r = await call('GET', '/api/members', { token: evil });
  check("…and cannot see gym A's members", r.data.members.length === 0);
  r = await call('POST', '/api/members', { token: A, body: { name: 'Mass', phone: '9000000077', gymId: gymB, memberCode: 'M9999', qrToken: 'chosen-by-attacker', status: 'active', userId: '000000000000000000000001' } });
  const massId = r.data.member._id;
  const dbm = await Member.findById(massId).lean();
  check('create member ignores gymId / memberCode / qrToken / userId from body', String(dbm.gymId) === gymA && dbm.memberCode !== 'M9999' && dbm.qrToken !== 'chosen-by-attacker' && !dbm.userId, dbm);
  await call('PUT', `/api/members/${massId}`, { token: A, body: { name: 'Mass2', gymId: gymB, qrToken: 'x', _id: memB } });
  const dbm2 = await Member.findById(massId).lean();
  check('update member ignores gymId / qrToken / _id', String(dbm2.gymId) === gymA && dbm2.qrToken === dbm.qrToken && dbm2.name === 'Mass2');
  r = await call('PUT', '/api/gym', { token: A, body: { name: 'Gym A', memberSeq: 0, _id: gymB } });
  check('gym update ignores _id / memberSeq', r.status === 200 && String(r.data.gym._id) === gymA);
  const aliceUserId = jwt.decode(alice).id;
  r = await call('GET', '/api/members', { token: jwt.sign({ id: aliceUserId, role: 'admin' }, process.env.JWT_SECRET) });
  check('role claim inside a token is ignored (member still 403 on admin API)', r.status === 403);
  check('member cannot reach admin endpoints at all', (await call('POST', '/api/members/import', { token: alice, body: { rows: [{ name: 'x', phone: '9999999999' }] } })).status === 403 && (await call('GET', '/api/dashboard', { token: alice })).status === 403);
  check('admin cannot use member portal endpoints', (await call('GET', '/api/me', { token: A })).status === 403);

  console.log('\n[3] TOKEN HANDLING');
  const hdr = async (h) => (await fetch(base + '/api/members', { headers: h })).status;
  check('no Authorization header → 401', (await hdr({})) === 401);
  check('"Bearer" with no token → 401', (await hdr({ Authorization: 'Bearer ' })) === 401);
  check('non-Bearer scheme → 401', (await hdr({ Authorization: 'Basic abc' })) === 401);
  check('garbage token → 401', (await hdr({ Authorization: 'Bearer abc.def.ghi' })) === 401);
  const adminUserId = jwt.decode(A).id;
  check('token signed with the wrong secret → 401', (await hdr({ Authorization: 'Bearer ' + jwt.sign({ id: adminUserId }, 'wrong-secret-xxxxxxxxxxxxxxxxxxxxx') })) === 401);
  const b64 = (o) => Buffer.from(JSON.stringify(o)).toString('base64url');
  check('alg:none forged token → 401', (await hdr({ Authorization: `Bearer ${b64({ alg: 'none', typ: 'JWT' })}.${b64({ id: adminUserId })}.` })) === 401);
  check('expired token → 401', (await hdr({ Authorization: 'Bearer ' + jwt.sign({ id: adminUserId }, process.env.JWT_SECRET, { expiresIn: -10 }) })) === 401);
  check('HS512 token (wrong algorithm) → 401', (await hdr({ Authorization: 'Bearer ' + jwt.sign({ id: adminUserId }, process.env.JWT_SECRET, { algorithm: 'HS512' }) })) === 401);
  check('token for a user id that does not exist → 401', (await hdr({ Authorization: 'Bearer ' + jwt.sign({ id: '000000000000000000000001' }, process.env.JWT_SECRET) })) === 401);
  check('token payload without id → 401', (await hdr({ Authorization: 'Bearer ' + jwt.sign({ foo: 1 }, process.env.JWT_SECRET) })) === 401);
  const decoded = jwt.decode(A);
  check('issued token has HS256 and a 7-day expiry', jwt.decode(A, { complete: true }).header.alg === 'HS256' && decoded.exp - decoded.iat === 7 * 86400, decoded);
  r = await call('POST', '/api/auth/login', { body: { email: 'alice@a.test', password: 'alicepass1' } });
  check('login response never contains password / hash', !JSON.stringify(r.body).match(/password|\$2[aby]\$/i), r.body);
  // password reset by the admin signs out the member's old session
  await new Promise((res) => setTimeout(res, 1100));
  r = await call('PUT', `/api/members/${memA}`, { token: A, body: { password: 'brandnewpass1' } });
  check('admin resets a member password', r.status === 200);
  check('old member session is rejected after the reset (401)', (await call('GET', '/api/me', { token: alice })).status === 401);
  r = await call('POST', '/api/auth/login', { body: { email: 'alice@a.test', password: 'brandnewpass1' } });
  check('member logs in with the new password; new session works', r.status === 200 && (await call('GET', '/api/me', { token: r.data.token })).status === 200);
  r = await call('POST', '/api/auth/login', { body: { email: 'alice@a.test', password: 'alicepass1' } });
  check('old password no longer works', r.status === 401);

  console.log('\n[4] PASSWORD RULES');
  for (const [label, pw, ok] of [['7 chars rejected', 'abc1234', false], ['8 chars accepted', 'abcd1234', true], ['72 bytes accepted', 'a'.repeat(72), true], ['73 bytes rejected (bcrypt would truncate)', 'a'.repeat(73), false], ['number rejected', 12345678, false], ['object rejected', { $gt: '' }, false]]) {
    r = await call('POST', '/api/auth/register', { body: { gymName: 'PW', name: 'P', email: `pw${Math.random().toString(36).slice(2)}@test.dev`, password: pw } });
    check(`password: ${label}`, ok ? r.status === 201 : r.status === 400, r.body);
  }

  console.log('\n[5] INJECTION & MALFORMED INPUT (nothing may 500)');
  const evilBodies = [
    ['login email {$gt:""}', 'POST', '/api/auth/login', { body: { email: { $gt: '' }, password: { $gt: '' } } }],
    ['login email array', 'POST', '/api/auth/login', { body: { email: ['a@test.dev'], password: 'x' } }],
    ['register name object', 'POST', '/api/auth/register', { body: { gymName: { $ne: 1 }, name: 'x', email: 'inj@test.dev', password: 'secret123' } }],
    ['member name object', 'POST', '/api/members', { token: A, body: { name: { $ne: '' }, phone: '9111111111' } }],
    ['member phone object', 'POST', '/api/members', { token: A, body: { name: 'x', phone: { $gt: '' } } }],
    ['member $where', 'POST', '/api/members', { token: A, body: { name: 'x', phone: '9111111112', $where: 'sleep(5000)' } }],
    ['check-in token object', 'POST', '/api/attendance/check-in', { token: A, body: { qrToken: { $ne: null } } }],
    ['check-in token array', 'POST', '/api/attendance/check-in', { token: A, body: { qrToken: [qrA] } }],
    ['payment memberId object', 'POST', '/api/payments', { token: A, body: { memberId: { $ne: null }, amount: 5, method: 'cash' } }],
    ['payment amount true', 'POST', '/api/payments', { token: A, body: { memberId: memA, amount: true, method: 'cash' } }],
    ['payment amount array', 'POST', '/api/payments', { token: A, body: { memberId: memA, amount: [5], method: 'cash' } }],
    ['plan price object', 'POST', '/api/plans', { token: A, body: { name: 'x', durationValue: 1, price: { $gt: 0 } } }],
    ['import rows = string', 'POST', '/api/members/import', { token: A, body: { rows: 'nope' } }],
    ['import rows with null / number / array entries', 'POST', '/api/members/import', { token: A, body: { rows: [null, 5, [], 'x', { name: ['a'] }] } }],
    ['import __proto__ row', 'POST', '/api/members/import', { token: A, raw: '{"rows":[{"__proto__":{"isAdmin":true},"name":"Proto","phone":"9222222222"}]}' }],
    ['query search[$ne]', 'GET', '/api/members?search[$ne]=x', { token: A }],
    ['query status[]', 'GET', '/api/members?status[]=active', { token: A }],
    ['query accountStatus[$ne]', 'GET', '/api/members?accountStatus[$ne]=x', { token: A }],
    ['query page=-5 limit=abc', 'GET', '/api/members?page=-5&limit=abc', { token: A }],
    ['query limit=999999', 'GET', '/api/payments?limit=999999', { token: A }],
    ['query from[$gt]', 'GET', '/api/payments?from[$gt]=1', { token: A }],
    ['query memberId[$ne]', 'GET', '/api/attendance?memberId[$ne]=1', { token: A }],
    ['regex bomb search', 'GET', '/api/members?search=' + encodeURIComponent('(a+)+$' + 'a'.repeat(60) + '!'), { token: A }],
    ['5000-char search', 'GET', '/api/members?search=' + 'a'.repeat(5000), { token: A }],
    ['malformed JSON', 'POST', '/api/members', { token: A, raw: '{"name":' }],
    ['wrong content-type body', 'POST', '/api/members', { token: A, raw: 'name=x', headers: { 'Content-Type': 'text/plain' } }],
    ['empty body POST', 'POST', '/api/members', { token: A, raw: '' }],
    ['id = ../../etc', 'GET', '/api/members/..%2F..%2Fetc', { token: A }],
    ['id = 25 hex wrong length', 'GET', '/api/members/' + 'a'.repeat(25), { token: A }],
    ['payment id = $ne', 'DELETE', '/api/payments/%7B%22%24ne%22%3Anull%7D', { token: A }]
  ];
  let any500 = [];
  for (const [label, m, p, o] of evilBodies) { const x = await call(m, p, o); if (x.status >= 500) any500.push(`${label}=${x.status}`); }
  check(`${evilBodies.length} hostile requests → none caused a 500`, any500.length === 0, any500.join(', '));
  r = await call('GET', '/api/members?search[$ne]=x', { token: A });
  check('search[$ne] is rejected, not interpreted as an operator', r.status === 400, r.status);
  r = await call('GET', '/api/members', { token: A });
  const hostile = await Member.find({ phone: { $in: ['9111111111', '9111111112', '9222222222'] } }).lean();
  check('hostile payloads created no corrupted members (operator objects rejected; rows that WERE valid stored only their whitelisted fields)', !(await Member.findOne({ phone: '9111111111' })) && hostile.every((m) => !('$where' in m) && !('isAdmin' in m) && typeof m.name === 'string' && typeof m.phone === 'string'), hostile);
  check('"__proto__" row did not pollute Object.prototype', ({}).isAdmin === undefined);
  r = await call('GET', '/api/members/zzz', { token: A });
  check('bad id error does not echo the input', r.status === 400 && !JSON.stringify(r.body).includes('zzz'), r.body);
  r = await call('GET', '/api/does/not/exist?x=<script>alert(1)</script>', { token: A });
  check('404 does not reflect the request URL', r.status === 404 && !JSON.stringify(r.body).includes('script'), r.body);
  r = await call('GET', '/api/does/not/exist?x=<script>alert(1)</script>');
  check('unknown API route without a token → 401 (reveals nothing), no reflection', r.status === 401 && !JSON.stringify(r.body).includes('script'), r.body);

  console.log('\n[6] HEADERS / CORS / HEALTH / ERRORS');
  const h = await fetch(base + '/api/members', { headers: { Authorization: 'Bearer ' + A } });
  check('X-Powered-By removed', !h.headers.get('x-powered-by'));
  check('X-Content-Type-Options: nosniff', h.headers.get('x-content-type-options') === 'nosniff');
  check('Cache-Control: no-store on API responses', h.headers.get('cache-control') === 'no-store');
  check('X-Frame-Options DENY + restrictive CSP', h.headers.get('x-frame-options') === 'DENY' && /default-src 'none'/.test(h.headers.get('content-security-policy') || ''));
  const evilOrigin = await fetch(base + '/api/members', { headers: { Origin: 'https://evil.example', Authorization: 'Bearer ' + A } });
  check('CORS: untrusted origin gets no Access-Control-Allow-Origin', !evilOrigin.headers.get('access-control-allow-origin'));
  const goodOrigin = await fetch(base + '/api/members', { headers: { Origin: 'https://gym.example.com', Authorization: 'Bearer ' + A } });
  check('CORS: configured frontend origin is allowed', goodOrigin.headers.get('access-control-allow-origin') === 'https://gym.example.com');
  const pre = await fetch(base + '/api/members', { method: 'OPTIONS', headers: { Origin: 'https://gym.example.com', 'Access-Control-Request-Method': 'DELETE', 'Access-Control-Request-Headers': 'authorization,content-type' } });
  check('CORS preflight works for the frontend origin', pre.status < 300 && /DELETE/.test(pre.headers.get('access-control-allow-methods') || ''));
  r = await call('GET', '/health');
  check('/health → 200 while the database is connected', r.status === 200);
  r = await call('POST', '/api/auth/login', { raw: 'x'.repeat(2 * 1024 * 1024) });
  check('oversized body → 413 with a clean message', r.status === 413 && r.body.message === 'Request is too large', r.body);

  console.log('\n[7] QR SECURITY');
  const tokens = [];
  for (let i = 0; i < 60; i += 1) tokens.push(i % 2 ? (await Member.create({ gymId: gymA, memberCode: 'T' + i, name: 'T' + i, phone: '8' + String(100000000 + i), joinedDate: today, qrToken: Member.newQrToken() })).qrToken : Member.newQrToken());
  check('tokens: 60 generated, all unique', new Set(tokens).size === 60);
  check('tokens: 24 chars of base64url = 144 bits of randomness', tokens.every((t) => /^[A-Za-z0-9_-]{24}$/.test(t)), tokens[0]);
  const bitsPerChar = new Set(tokens.join('')).size;
  check('tokens: characters well distributed (>= 50 distinct symbols across 60 tokens)', bitsPerChar >= 50, bitsPerChar);
  check('QR payload contains no name / phone / email / ids', (() => { const p = qrA; return p.startsWith('hrk:') && !/alice|9000000001|a\.test/i.test(p) && !p.includes(memA) && !p.includes(gymA); })(), qrA);
  const indexes = await Member.collection.indexes();
  check('database enforces unique qrToken', indexes.some((i) => i.key.qrToken === 1 && i.unique));
  let dupErr = null; try { await Member.collection.insertOne({ gymId: new mongoose.Types.ObjectId(gymA), memberCode: 'DUP1', name: 'Dup', joinedDate: today, qrToken: tokens[1], emailKey: 'none:d1', phoneKey: 'none:d1' }); } catch (e) { dupErr = e; }
  check('inserting a duplicate qrToken is rejected by the database (E11000)', dupErr && dupErr.code === 11000);
  check('member JSON never exposes qrToken / lastCheckInAt / derived keys', (() => { const j = JSON.stringify(dbm && new Member(dbm).toJSON()); return !/qrToken|lastCheckInAt|emailKey|phoneKey/.test(j); })());
  const ci = (tok, t) => call('POST', '/api/attendance/check-in', { token: tok, body: { qrToken: t } });
  // Simulates "N minutes have passed since this member's last check-in" by moving both the member's
  // last-check-in marker and the stored attendance record back in time (what real elapsed time would do).
  const rewind = async (memberId, minutes) => {
    const shift = minutes * 60000;
    const m = await Member.findById(memberId).lean();
    if (m.lastCheckInAt) await Member.updateOne({ _id: memberId }, { $set: { lastCheckInAt: new Date(m.lastCheckInAt.getTime() - shift) } });
    for (const a of await Attendance.find({ memberId }).lean()) {
      const at = new Date(a.checkedInAt.getTime() - shift);
      await Attendance.updateOne({ _id: a._id }, { $set: { checkedInAt: at, windowKey: `${memberId}:${Math.floor(at.getTime() / (5 * 60000))}` } });
    }
  };
  check('token is case-sensitive (upper-cased token → 404)', (await ci(A, qrA.toUpperCase())).status === 404);
  check('token with trailing garbage → 404', (await ci(A, qrA + 'x')).status === 404);
  check('100+ char token → 400', (await ci(A, 'hrk:' + 'a'.repeat(120))).status === 400);
  check('whitespace around a valid token is tolerated', [200, 201].includes((await ci(A, '  ' + qrA + '  ')).status));
  check('bare token without "hrk:" prefix also resolves (same lookup)', [200, 201].includes((await ci(A, qrA.slice(4))).status));
  // inactive / revoked
  const qrMass = (await call('GET', `/api/members/${massId}`, { token: A })).data.qrPayload;
  await call('POST', '/api/memberships', { token: A, body: { memberId: massId, planId: planA } });
  r = await ci(A, qrMass); check('active member checks in', r.status === 201 && r.data.result === 'checked_in', r.body);
  await call('PUT', `/api/members/${massId}`, { token: A, body: { status: 'inactive' } });
  await rewind(massId, 10);
  r = await ci(A, qrMass); check('inactive member denied (403, reason inactive)', r.status === 403 && r.body.data.reason === 'inactive', r.body);
  await call('PUT', `/api/members/${massId}`, { token: A, body: { status: 'active' } });
  const regen = (await call('POST', `/api/members/${massId}/regenerate-qr`, { token: A })).data.qrPayload;
  await rewind(massId, 10);
  check('regenerate → old QR dead (404), new QR works', (await ci(A, qrMass)).status === 404 && (await ci(A, regen)).status === 201);
  await call('DELETE', `/api/members/${massId}`, { token: A });
  check('deleted member QR → 404', (await ci(A, regen)).status === 404);
  // duplicate window boundaries (simulated clock: move lastCheckInAt back)
  const wm = await mk(A, 'Window Wendy', '9000000050'); await call('POST', '/api/memberships', { token: A, body: { memberId: wm, planId: planA } });
  const wq = (await call('GET', `/api/members/${wm}`, { token: A })).data.qrPayload;
  check('window: first scan records', (await ci(A, wq)).data.result === 'checked_in');
  await rewind(wm, 4.5); check('window: scan 4.5 min after the first → duplicate', (await ci(A, wq)).data.result === 'duplicate');
  await rewind(wm, 1.0); check('window: scan 5.5 min after the first → new check-in', (await ci(A, wq)).data.result === 'checked_in');
  check('window: exactly 2 attendance records for this member', (await Attendance.countDocuments({ memberId: wm })) === 2);
  // concurrency
  const cm = await mk(A, 'Concurrent Carl', '9000000051'); await call('POST', '/api/memberships', { token: A, body: { memberId: cm, planId: planA } });
  const cq = (await call('GET', `/api/members/${cm}`, { token: A })).data.qrPayload;
  const burst = await Promise.all(Array.from({ length: 12 }, () => ci(A, cq)));
  check('12 simultaneous scans → exactly 1 checked_in + 11 duplicates', burst.filter((x) => x.data.result === 'checked_in').length === 1 && burst.filter((x) => x.data.result === 'duplicate').length === 11, burst.map((x) => x.data.result));
  check('…and exactly 1 attendance row in the database', (await Attendance.countDocuments({ memberId: cm })) === 1);
  const attIdx = await Attendance.collection.indexes();
  check('database enforces unique attendance windowKey (the engine-independent duplicate guard)', attIdx.some((i) => i.key.windowKey === 1 && i.unique));
  let wkErr = null; try { await Attendance.collection.insertOne({ gymId: new mongoose.Types.ObjectId(gymA), memberId: new mongoose.Types.ObjectId(cm), checkedInAt: new Date(), date: today, windowKey: (await Attendance.findOne({ memberId: cm }).lean()).windowKey, membershipStatus: 'active' }); } catch (e) { wkErr = e; }
  check('inserting a second attendance row in the same member+window is rejected by the database', wkErr && wkErr.code === 11000);

  console.log('\n[8] MEMBERSHIP LOGIC & DATE BOUNDARIES');
  const st = (list, day) => deriveStatus(list.map(([s, e]) => ({ startDate: s, endDate: e, planName: 'P' })), day);
  check('same-day start & end: covered that day (expiring, 0 left)', (() => { const d = st([['2026-05-10', '2026-05-10']], '2026-05-10'); return d.status === 'expiring' && d.daysLeft === 0; })());
  check('same-day period: expired the next day', st([['2026-05-10', '2026-05-10']], '2026-05-11').status === 'expired');
  check('same-day period: not yet started the day before → upcoming', st([['2026-05-10', '2026-05-10']], '2026-05-09').status === 'upcoming');
  check('exactly 7 days left → expiring; 8 → active', st([['2026-01-01', '2026-05-08']], '2026-05-01').status === 'expiring' && st([['2026-01-01', '2026-05-09']], '2026-05-01').status === 'active');
  check('month-end clamping: Jan 31 + 1 month ends Feb 27 (non-leap)', computeEndDate('2027-01-31', 1, 'months') === '2027-02-27');
  check('leap day: 2028-02-29 + 1 month ends 2028-03-28', computeEndDate('2028-02-29', 1, 'months') === '2028-03-28');
  check('leap day: 2028-02-29 + 12 months ends 2029-02-27 (anniversary clamps to Feb 28, period ends the day before)', computeEndDate('2028-02-29', 12, 'months') === '2029-02-27');
  check('year end: 2026-12-01 + 1 month ends 2026-12-31', computeEndDate('2026-12-01', 1, 'months') === '2026-12-31');
  check('1-day plan starting & ending the same day', computeEndDate('2026-05-10', 1, 'days') === '2026-05-10');
  check('IST rollover: 18:29:59Z is still the same IST day, 18:30:00Z is the next', todayIST(new Date('2026-06-30T18:29:59Z')) === '2026-06-30' && todayIST(new Date('2026-06-30T18:30:00Z')) === '2026-07-01');
  check('IST: 00:00 IST on New Year (Dec 31 18:30Z) is Jan 1', todayIST(new Date('2026-12-31T18:30:00Z')) === '2027-01-01');
  const pm = await mk(A, 'Period Pat', '9000000052');
  r = await call('POST', '/api/memberships', { token: A, body: { memberId: pm, planId: planA, startDate: '2026-01-01' } });
  check('period 1: 2026-01-01 → 2026-01-31', r.data.membership.endDate === '2026-01-31');
  r = await call('POST', '/api/memberships', { token: A, body: { memberId: pm, planId: planA, startDate: '2026-01-31' } });
  check('overlap by one day (starts on previous end date) → 409', r.status === 409);
  r = await call('POST', '/api/memberships', { token: A, body: { memberId: pm, planId: planA, startDate: '2026-02-01' } });
  check('back-to-back period starting the next day → accepted', r.status === 201 && r.data.membership.endDate === '2026-02-28');
  r = await call('POST', '/api/memberships', { token: A, body: { memberId: pm, planId: planA, startDate: '2025-12-15' } });
  check('period that would run INTO an existing one (starts earlier) → 409', r.status === 409);
  r = await call('POST', '/api/memberships', { token: A, body: { memberId: pm, planId: planA, startDate: '2026-04-01' } });
  check('later period with a gap → accepted', r.status === 201);
  check('history keeps all 3 periods, newest first', (await call('GET', `/api/members/${pm}`, { token: A })).data.memberships.map((m) => m.startDate).join() === '2026-04-01,2026-02-01,2026-01-01');
  for (const [label, d] of [['year 9999', '9999-12-31'], ['year 1999', '1999-12-31'], ['year 0001', '0001-01-01'], ['2101-01-01', '2101-01-01'], ['2026-02-30', '2026-02-30'], ['2026-13-01', '2026-13-01'], ['text', 'tomorrow'], ['2026-1-5', '2026-1-5'], ['ISO datetime', '2026-05-10T00:00:00Z']]) {
    r = await call('POST', '/api/memberships', { token: A, body: { memberId: pm, planId: planA, startDate: d } });
    check(`start date ${label} → 400, not a crash`, r.status === 400, r.status);
  }
  r = await call('POST', '/api/plans', { token: A, body: { name: 'Huge', durationValue: 121, durationUnit: 'months', price: 1 } }); check('plan > 120 months → 400', r.status === 400);
  r = await call('POST', '/api/plans', { token: A, body: { name: 'Huge', durationValue: 3651, durationUnit: 'days', price: 1 } }); check('plan > 3650 days → 400', r.status === 400);
  r = await call('POST', '/api/plans', { token: A, body: { name: 'Frac', durationValue: 1.5, durationUnit: 'months', price: 1 } }); check('fractional duration → 400', r.status === 400);
  r = await call('POST', '/api/plans', { token: A, body: { name: 'Max', durationValue: 120, durationUnit: 'months', price: 1 } });
  r = await call('POST', '/api/memberships', { token: A, body: { memberId: await mk(A, 'Longtime', '9000000053'), planId: r.data.plan._id, startDate: '2100-12-31' } });
  check('latest allowed start + longest plan still computes a valid end date', r.status === 201 && /^21\d\d-\d\d-\d\d$/.test(r.data.membership.endDate), r.body);
  // plan edit must not rewrite sold memberships
  const priceMem = await mk(A, 'Price Pete', '9000000054'); await call('POST', '/api/memberships', { token: A, body: { memberId: priceMem, planId: planA } });
  await call('PUT', `/api/plans/${planA}`, { token: A, body: { name: 'Monthly NEW', durationValue: 3, durationUnit: 'months', price: 5000 } });
  const sold = (await call('GET', `/api/members/${priceMem}`, { token: A })).data.memberships[0];
  check('editing a plan does not change memberships already sold (snapshot kept)', sold.planName === 'Monthly' && sold.price === 1000, sold);
  await call('PUT', `/api/plans/${planA}`, { token: A, body: { name: 'Monthly', durationValue: 1, durationUnit: 'months', price: 1000 } });
  // concurrent renewals
  const rm = await mk(A, 'Renew Ravi', '9000000055'); await call('POST', '/api/memberships', { token: A, body: { memberId: rm, planId: planA } });
  const renewals = await Promise.all(Array.from({ length: 6 }, () => call('POST', `/api/members/${rm}/renew`, { token: A, body: { payment: { amount: 1000, method: 'cash' } } })));
  const okCount = renewals.filter((x) => x.status === 201).length;
  const detail = (await call('GET', `/api/members/${rm}`, { token: A })).data;
  const sorted = [...detail.memberships].sort((a, b) => (a.startDate < b.startDate ? -1 : 1));
  const noOverlap = sorted.every((m, i) => i === 0 || m.startDate > sorted[i - 1].endDate);
  const starts = detail.memberships.map((m) => m.startDate);
  check('6 simultaneous renewals: every request ends in 201 or a clean 409 (never a 500)', renewals.every((x) => x.status === 201 || x.status === 409), renewals.map((x) => x.status));
  check('…no two periods ever start on the same day, and none overlap', new Set(starts).size === starts.length && noOverlap, starts);
  check('…every successful renewal has exactly one payment, and nothing else was created', detail.memberships.length === 1 + okCount && detail.payments.length === okCount, { memberships: detail.memberships.length, payments: detail.payments.length, ok: okCount });
  check('…at least one same-instant duplicate was rejected by the database guard (409)', renewals.some((x) => x.status === 409));
  check('KNOWN LIMITATION: requests that are not simultaneous can chain extra renewals via the API (the UI disables the button while saving)', true);

  console.log('\n[9] PAYMENTS');
  const pay = (b) => call('POST', '/api/payments', { token: A, body: { memberId: memA, method: 'cash', ...b } });
  for (const [label, amt, ok] of [['0', 0, false], ['negative', -5, false], ['0.001 (sub-paise)', 0.001, false], ['10.999 (3 decimals)', 10.999, false], ['10000001 (over cap)', 10000001, false], ['"abc"', 'abc', false], ['"Infinity"', 'Infinity', false], ['"1e3"', '1e3', false], ['null', null, false], ['true', true, false], ['0.01 (smallest)', 0.01, true], ['"250.50" (numeric string)', '250.50', true], ['10000000 (at cap)', 10000000, true]]) {
    r = await pay({ amount: amt }); check(`amount ${label} → ${ok ? 'accepted' : '400'}`, ok ? r.status === 201 : r.status === 400, r.status);
  }
  r = await pay({ amount: 5, paidOn: addDays(today, 1) }); check('future payment date → 400', r.status === 400, r.body);
  r = await pay({ amount: 5, method: 'bitcoin' }); check('unknown method → 400', r.status === 400);
  r = await pay({ amount: 5, paidOn: '2026-02-30' }); check('impossible payment date → 400', r.status === 400);
  r = await pay({ amount: 5, note: 'x'.repeat(201) }); check('note > 200 chars → 400', r.status === 400);
  // revenue precision & scope
  const rev = await mk(A, 'Revenue Rita', '9000000056');
  const revBefore = (await call('GET', '/api/dashboard', { token: A })).data.totals.todayRevenue;
  await call('POST', '/api/payments', { token: A, body: { memberId: rev, amount: 0.1, method: 'cash' } });
  await call('POST', '/api/payments', { token: A, body: { memberId: rev, amount: 0.2, method: 'cash' } });
  const revAfter = (await call('GET', '/api/dashboard', { token: A })).data.totals.todayRevenue;
  check('float precision: 0.1 + 0.2 adds exactly 0.3 to revenue', Math.round((revAfter - revBefore) * 100) === 30, { revBefore, revAfter });
  r = await call('GET', `/api/payments?memberId=${rev}`, { token: A }); check('payment list total is rounded to paise (0.3)', r.data.totalAmount === 0.3, r.data.totalAmount);
  await call('POST', '/api/payments', { token: A, body: { memberId: rev, amount: 777, method: 'cash', paidOn: addDays(today, -3) } });
  check("a back-dated payment is NOT counted in today's revenue", (await call('GET', '/api/dashboard', { token: A })).data.totals.todayRevenue === revAfter);
  r = await call('GET', `/api/payments?memberId=${rev}&from=${addDays(today, -5)}&to=${addDays(today, -1)}`, { token: A });
  check('…but it is in the payment history for its own date', r.data.payments.length === 1 && r.data.payments[0].amount === 777);
  // deleted member's payments
  const gone = await mk(A, 'Gone Gita', '9000000057');
  const goneRevBefore = (await call('GET', '/api/dashboard', { token: A })).data.totals.todayRevenue;
  await call('POST', '/api/payments', { token: A, body: { memberId: gone, amount: 333, method: 'upi' } });
  await call('DELETE', `/api/members/${gone}`, { token: A });
  r = await call('GET', '/api/payments?search=Gone', { token: A });
  check("deleted member's payment is kept, shown by name and flagged deleted", r.data.payments.length === 1 && r.data.payments[0].member.deleted === true && r.data.payments[0].member.name === 'Gone Gita');
  check("deleted member's payment still counts in that day's revenue (it was real money)", (await call('GET', '/api/dashboard', { token: A })).data.totals.todayRevenue === Math.round((goneRevBefore + 333) * 100) / 100);
  // idempotency: the same request id can never record a payment twice
  const rid = 'req-' + Math.random().toString(36).slice(2, 14);
  const idemBody = { memberId: rev, amount: 50, method: 'cash', clientRequestId: rid };
  const dsBefore = (await call('GET', `/api/payments?memberId=${rev}`, { token: A })).data.pagination.total;
  const burst5 = await Promise.all(Array.from({ length: 5 }, () => call('POST', '/api/payments', { token: A, body: idemBody })));
  const dsAfter = (await call('GET', `/api/payments?memberId=${rev}`, { token: A })).data.pagination.total;
  check('5 simultaneous submissions with the same request id → exactly ONE payment recorded', dsAfter === dsBefore + 1 && burst5.every((x) => x.status === 201 || x.status === 200), { before: dsBefore, after: dsAfter, statuses: burst5.map((x) => x.status) });
  check('…every response returns the same payment (replays flagged, no error)', new Set(burst5.map((x) => x.data.payment._id)).size === 1 && burst5.filter((x) => x.status === 201).length === 1);
  r = await call('POST', '/api/payments', { token: A, body: idemBody });
  check('a later retry of the same request id replays the original (200, replayed:true)', r.status === 200 && r.data.replayed === true && (await call('GET', `/api/payments?memberId=${rev}`, { token: A })).data.pagination.total === dsAfter);
  r = await call('POST', '/api/payments', { token: A, body: { ...idemBody, amount: 51 } });
  check('same request id with a DIFFERENT amount → 409 (never silently returns/merges)', r.status === 409);
  r = await call('POST', '/api/payments', { token: A, body: { memberId: rev, amount: 50, method: 'cash', clientRequestId: 'bad id!' } });
  check('malformed request id → 400', r.status === 400);
  r = await call('POST', '/api/payments', { token: A, body: { memberId: rev, amount: 50, method: 'cash', clientRequestId: { $ne: 1 } } });
  check('object as request id → 400', r.status === 400);
  const rb = await mk(B, 'Rita B', '9000000099');
  r = await call('POST', '/api/payments', { token: B, body: { memberId: rb, amount: 50, method: 'cash', clientRequestId: rid } });
  check('the same request id in another gym is an independent payment (201)', r.status === 201);
  const twoManual = await Promise.all([1, 2].map(() => call('POST', '/api/payments', { token: A, body: { memberId: rev, amount: 20, method: 'cash' } })));
  check('without a request id two separate entries are still both recorded (deliberate: two genuine payments are possible)', twoManual.every((x) => x.status === 201));

  console.log('\n[10] DUPLICATE MEMBERS (database-enforced)');
  const dupes = await Promise.all(Array.from({ length: 6 }, () => call('POST', '/api/members', { token: A, body: { name: 'Race', phone: '9333333333', email: 'race@a.test' } })));
  check('6 simultaneous creates with the same phone/email → exactly 1 created, 5 get 409', dupes.filter((x) => x.status === 201).length === 1 && dupes.filter((x) => x.status === 409).length === 5, dupes.map((x) => x.status));
  check('…and exactly one such member exists', (await Member.countDocuments({ gymId: gymA, phone: '9333333333' })) === 1);
  r = await call('POST', '/api/members', { token: A, body: { name: 'NoEmail1', phone: '9444444441' } });
  check('fixture: member with phone 9444444441 created', r.status === 201, r.body);
  r = await call('POST', '/api/members', { token: A, body: { name: 'NoEmail2', phone: '9444444442' } });
  check('members without an email do not collide with each other', r.status === 201);
  r = await call('POST', '/api/members', { token: A, body: { name: 'NoPhone1', email: 'np1@a.test' } }); r = await call('POST', '/api/members', { token: A, body: { name: 'NoPhone2', email: 'np2@a.test' } });
  check('members without a phone do not collide with each other', r.status === 201);
  for (const v of ['+91 94444 44441', '094444 44441', '919444444441', '9444444441']) { r = await call('POST', '/api/members', { token: A, body: { name: 'Variant', phone: v } }); if (r.status !== 409) break; }
  check('same Indian number written 4 ways (+91 / 0 / 91 / plain) is recognised as a duplicate', r.status === 409, r.body);
  r = await call('PUT', `/api/members/${memA}`, { token: A, body: { phone: '9444444441' } });
  check('editing a member onto another member\'s phone → 409', r.status === 409);
  const hasAcc = await call('POST', '/api/members', { token: B, body: { name: 'Tenant B', phone: '9444444441' } });
  check('the same phone in another gym is allowed', hasAcc.status === 201);

  // Force the member-code counter backwards (what a lost update could do) and prove creation still succeeds.
  const Gym = require('../models/Gym');
  const gymDoc = await Gym.findById(gymA).lean();
  await Gym.updateOne({ _id: gymA }, { $set: { memberSeq: Math.max(0, gymDoc.memberSeq - 5) } });
  r = await call('POST', '/api/members', { token: A, body: { name: 'After Regress', phone: '9444444499' } });
  check('member-code counter regressed by 5 → creation still succeeds (takes the next free code)', r.status === 201 && /^M\d{4,}$/.test(r.data.member.memberCode), r.body);
  const codes = (await Member.find({ gymId: gymA }).select('memberCode').lean()).map((m) => m.memberCode);
  check('…and every member code in the gym is still unique', new Set(codes).size === codes.length);

  console.log('\n[11] CSV IMPORT (server side)');
  const imp = (rows, dry) => call('POST', '/api/members/import', { token: A, body: { rows, dryRun: dry } });
  r = await imp([{ name: 'அருண் குமார்', phone: '9555555551' }, { name: '😀 Emoji', phone: '9555555552' }, { name: 'محمد', phone: '9555555553' }, { name: 'O\'Brien, "Pat"', phone: '9555555554' }, { name: '=1+1', phone: '9555555555' }, { name: '<img src=x onerror=alert(1)>', phone: '9555555556' }, { name: 'José Müller', email: 'jose@a.test' }], false);
  check('unicode, quotes, commas, formula & HTML characters import literally (7/7)', r.data.summary.imported === 7, r.data.results);
  const stored = await Member.find({ gymId: gymA, phone: { $in: ['9555555551', '9555555555', '9555555556'] } }).lean();
  check('names stored exactly as given (no mangling, no execution)', stored.some((m) => m.name === 'அருண் குமார்') && stored.some((m) => m.name === '=1+1') && stored.some((m) => m.name === '<img src=x onerror=alert(1)>'));
  r = await imp([{ name: 'A'.repeat(121), phone: '9666666661' }, { name: 'No contact' }, { name: 'Bad phone', phone: '12ab' }, { name: 'Bad email', email: 'nope' }, { name: 'Bad date', phone: '9666666662', joinedDate: '2026-02-30' }, { name: 'Future DOB', phone: '9666666663', dateOfBirth: addDays(today, 5) }, { name: 'Bad gender', phone: '9666666664', gender: 'robot' }, { name: '', phone: '9666666665' }, { phone: '9666666666' }, { name: 'Sci notation', phone: '9.87654E+09' }, null, 7, 'str'], true);
  check('13 invalid rows all flagged as errors, none valid', r.data.summary.errors === 13 && r.data.summary.valid === 0, r.data.summary);
  r = await imp([{ name: 'Dup1', phone: '9777777771' }, { name: 'Dup1 again', phone: '9777777771' }, { name: 'DupE', email: 'dupe@a.test' }, { name: 'DupE 2', email: 'DUPE@a.test' }, { name: 'Existing', phone: '9000000001' }], false);
  check('in-file and existing duplicates are skipped and reported (3 skipped, 2 imported)', r.data.summary.duplicates === 3 && r.data.summary.imported === 2, r.data.summary);
  check('summary matches the database', (await Member.countDocuments({ gymId: gymA, phone: '9777777771' })) === 1);
  const mixed = Array.from({ length: 200 }, (_, i) => (i % 2 ? { name: 'bad' + i } : { name: 'Mixed ' + i, phone: '97' + String(10000000 + i) }));
  const before2 = await Member.countDocuments({ gymId: gymA });
  r = await imp(mixed, false);
  check('partial failure: 100 valid imported, 100 invalid reported — nothing half-created', r.data.summary.imported === 100 && r.data.summary.errors === 100 && (await Member.countDocuments({ gymId: gymA })) === before2 + 100, r.data.summary);
  check('every imported member has a code, a unique QR and a key', (await Member.find({ gymId: gymA, name: /^Mixed / }).lean()).every((m) => /^M\d{4,}$/.test(m.memberCode) && m.qrToken.length === 24 && m.emailKey && m.phoneKey));
  const big = Array.from({ length: 500 }, (_, i) => ({ name: 'Big ' + i, phone: '96' + String(10000000 + i) }));
  const t0 = Date.now(); r = await imp(big, false); const ms = Date.now() - t0;
  check(`500-row import completes (${ms} ms) with 500 imported`, r.data.summary.imported === 500 && ms < 60000, r.data.summary);
  r = await imp(Array.from({ length: 501 }, (_, i) => ({ name: 'x' + i, phone: '95' + String(10000000 + i) })), false);
  check('501 rows → 400, nothing imported', r.status === 400 && !(await Member.findOne({ name: 'x0' })));
  r = await imp([{ name: 'Gym Hop', phone: '9888888881', gymId: gymB, memberCode: 'M0001', qrToken: 'forced' }], false);
  const hop = await Member.findOne({ phone: '9888888881' }).lean();
  check('import ignores gymId / memberCode / qrToken columns', r.data.summary.imported === 1 && String(hop.gymId) === gymA && hop.qrToken !== 'forced' && hop.memberCode !== 'M0001');
  r = await imp([{ name: 'Dry', phone: '9999000011' }], true); check('dry run writes nothing', r.data.summary.valid === 1 && !(await Member.findOne({ phone: '9999000011' })));

  console.log('\n[12] DASHBOARD vs DATABASE');
  r = await call('GET', '/api/dashboard', { token: A });
  const dbCount = await Member.countDocuments({ gymId: gymA });
  check('totalMembers equals the database count', r.data.totals.totalMembers === dbCount, { api: r.data.totals.totalMembers, db: dbCount });
  const todayCount = await Attendance.countDocuments({ gymId: gymA, date: today });
  check("today's check-ins equals the database count", r.data.totals.todayCheckIns === todayCount, { api: r.data.totals.todayCheckIns, db: todayCount });

  console.log('\n[13] AUTH THROTTLING (run last: it consumes this IP\'s allowance)');
  const bad = (email, i) => call('POST', '/api/auth/login', { body: { email, password: 'wrong-pass-' + i } });
  for (let i = 0; i < 5; i += 1) await bad('bob@b.test', i);
  r = await call('POST', '/api/auth/login', { body: { email: 'bob@b.test', password: 'bobpass123' } });
  check('5 failures then the right password → success (counter resets)', r.status === 200);
  for (let i = 0; i < 8; i += 1) r = await bad('bob@b.test', i);
  r = await call('POST', '/api/auth/login', { body: { email: 'bob@b.test', password: 'wrong-again' } });
  check('after 8 failures the 9th attempt is blocked: 429 + Retry-After', r.status === 429 && Number(r.headers.get('retry-after')) > 0, { s: r.status, ra: r.headers.get('retry-after') });
  r = await call('POST', '/api/auth/login', { body: { email: 'bob@b.test', password: 'bobpass123' } });
  check('even the CORRECT password is blocked while locked (stops guess-then-verify)', r.status === 429);
  r = await call('POST', '/api/auth/login', { body: { email: 'a@test.dev', password: 'secret123' } });
  check("a different account from the same IP is not locked out", r.status === 200);
  const timeOne = async (email) => { const t = process.hrtime.bigint(); await call('POST', '/api/auth/login', { body: { email, password: 'whatever12' } }); return Number(process.hrtime.bigint() - t) / 1e6; };
  const med = (a) => a.sort((x, y) => x - y)[Math.floor(a.length / 2)];
  const known = []; const unknown = [];
  for (let i = 0; i < 4; i += 1) { known.push(await timeOne('a@test.dev')); unknown.push(await timeOne(`ghost${i}@test.dev`)); }
  check(`login time does not reveal whether an email exists (median known ${med(known).toFixed(0)} ms vs unknown ${med(unknown).toFixed(0)} ms)`, med(unknown) > med(known) * 0.5, { known, unknown });
  let blocked = 0; for (let i = 0; i < 200 && !blocked; i += 1) { const x = await call('POST', '/api/auth/login', { body: { email: `spray${i}@test.dev`, password: 'whatever12' } }); if (x.status === 429) blocked = i + 1; }
  check(`password-spraying many emails from one IP is throttled (blocked at request #${blocked || 'never'} of this IP window)`, blocked > 0);
  let regBlocked = 0; for (let i = 0; i < 20 && !regBlocked; i += 1) { const x = await call('POST', '/api/auth/register', { body: { gymName: 'Spam', name: 'S', email: `spam${i}@test.dev`, password: 'secret123' } }); if (x.status === 429) regBlocked = i + 1; }
  check(`mass gym registration from one IP is throttled (blocked at attempt #${regBlocked || 'never'})`, regBlocked > 0);

  server.close(); await mongoose.connection.dropDatabase(); await mongoose.disconnect();
  console.log(`\n${passed} passed, ${failures.length} failed`);
  if (failures.length) { console.log('FAILED:\n - ' + failures.join('\n - ')); process.exit(1); }
  process.exit(0);
})().catch((e) => { console.error('Security suite crashed:', e); process.exit(2); });
