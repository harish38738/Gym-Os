/* global document */
// UI audit tests: (a) XSS — hostile names must render as inert text on every screen;
// (b) camera/QR-scanner lifecycle against a SIMULATED camera (mocked getUserMedia / BarcodeDetector).
// This exercises the real check-in page code paths, but it is NOT a real-device camera test.
process.env.JWT_SECRET = process.env.JWT_SECRET || 'test-secret-for-ui-extra-1234567890';
process.env.MONGO_URI = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/hrk-ui-extra-' + Date.now();

const path = require('path');
const fs = require('fs');
const { pathToFileURL } = require('url');
const mongoose = require('mongoose');
const { JSDOM, ResourceLoader } = require('jsdom');
const { assertSafeTestDb, resetDb } = require('./helpers');
const app = require('../app');

const FRONTEND = path.join(__dirname, '..', '..', 'frontend');
let passed = 0; const failures = [];
const check = (name, cond, extra) => { if (cond) { passed += 1; console.log('  ✓', name); } else { failures.push(name); console.log('  ✗', name, extra !== undefined ? String(extra).slice(0, 300) : ''); } };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

(async () => {
  assertSafeTestDb(process.env.MONGO_URI);
  await mongoose.connect(process.env.MONGO_URI);
  await resetDb();
  const server = app.listen(0);
  const apiBase = `http://127.0.0.1:${server.address().port}`;

  class Loader extends ResourceLoader {
    fetch(url) {
      const m = /\/vendor\/([\w.-]+\.js)$/.exec(url);
      return Promise.resolve(m ? fs.readFileSync(path.join(FRONTEND, 'vendor', m[1])) : Buffer.from(''));
    }
  }
  const html = fs.readFileSync(path.join(FRONTEND, 'index.html'), 'utf8').replace(/<script[\s\S]*?<\/script>/g, '').replace(/<link[^>]*>/g, '');
  const dom = new JSDOM(html, { url: 'http://localhost:5173/', runScripts: 'dangerously', resources: new Loader(), pretendToBeVisual: true });
  const { window } = dom;
  window.HRK_CONFIG = { apiBaseUrl: apiBase };
  window.scrollTo = () => {};
  window.isSecureContext = true;
  // jsdom has no media pipeline: report a "ready" video so the scan loop runs.
  Object.defineProperty(window.HTMLMediaElement.prototype, 'readyState', { get: () => 4, configurable: true });
  Object.defineProperty(window.HTMLVideoElement.prototype, 'videoWidth', { get: () => 640, configurable: true });
  Object.defineProperty(window.HTMLVideoElement.prototype, 'videoHeight', { get: () => 480, configurable: true });
  window.HTMLMediaElement.prototype.play = () => Promise.resolve();

  // Count API calls the page makes (used to prove a QR held in view is submitted once).
  const realFetch = globalThis.fetch;
  const calls = [];
  globalThis.fetch = (url, opts) => { calls.push(String(url).replace(apiBase, '') + ' ' + ((opts && opts.method) || 'GET')); return realFetch(url, opts); };

  const camera = { tracks: [], gumCalls: 0, mode: 'ok', pending: null };
  const makeStream = () => { const t = { stopped: false, stop() { this.stopped = true; } }; camera.tracks.push(t); return { getTracks: () => [t] }; };
  const mediaDevices = {
    getUserMedia: () => {
      camera.gumCalls += 1;
      if (camera.mode === 'denied') return Promise.reject(Object.assign(new Error('x'), { name: 'NotAllowedError' }));
      if (camera.mode === 'none') return Promise.reject(Object.assign(new Error('x'), { name: 'NotFoundError' }));
      if (camera.mode === 'busy') return Promise.reject(Object.assign(new Error('x'), { name: 'NotReadableError' }));
      if (camera.mode === 'deferred') return new Promise((res) => { camera.pending = () => res(makeStream()); });
      return Promise.resolve(makeStream());
    }
  };
  Object.defineProperty(globalThis, 'navigator', { value: { mediaDevices }, configurable: true, writable: true });
  Object.assign(globalThis, { window, document: window.document, localStorage: window.localStorage, requestAnimationFrame: window.requestAnimationFrame.bind(window), cancelAnimationFrame: window.cancelAnimationFrame.bind(window) });

  await import(pathToFileURL(path.join(FRONTEND, 'js', 'app.js')).href);
  document.dispatchEvent(new window.Event('DOMContentLoaded'));

  const $ = (s) => document.querySelector(s);
  const text = () => $('#app-main').textContent.replace(/\s+/g, ' ');
  const waitFor = async (fn, label, ms = 6000) => { const t0 = Date.now(); while (Date.now() - t0 < ms) { try { const v = fn(); if (v) return v; } catch (e) { /* retry */ } await sleep(30); } throw new Error('Timed out: ' + label + ' | ' + text().slice(0, 200)); };
  const go = async (hash) => { window.location.hash = hash; await sleep(40); };
  const submit = (f) => f.dispatchEvent(new window.Event('submit', { bubbles: true, cancelable: true }));
  const click = (el) => el.dispatchEvent(new window.MouseEvent('click', { bubbles: true, cancelable: true }));
  const api = async (m, p, tok, body) => { const r = await realFetch(apiBase + p, { method: m, headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + tok }, body: body ? JSON.stringify(body) : undefined }); return (await r.json()).data; };

  // ---------- fixtures with hostile text everywhere a name can appear ----------
  const XSS = '<img src=x onerror="window.__xss=1"><script>window.__xss=2</script>';
  const XSS2 = '"><svg onload="window.__xss=3">';
  let r = await realFetch(apiBase + '/api/auth/register', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ gymName: XSS2 + ' Gym', name: XSS, email: 'x@ui.test', password: 'secret123' }) });
  const T = (await r.json()).data.token;
  const plan = (await api('POST', '/api/plans', T, { name: XSS, durationValue: 1, durationUnit: 'months', price: 500 })).plan._id;
  const mk = async (name, phone, extra = {}) => (await api('POST', '/api/members', T, { name, phone, ...extra })).member._id;
  const hostile = await mk(XSS, '9000000001', { email: 'h@ui.test', password: 'hostilepass1' });
  await api('POST', '/api/memberships', T, { memberId: hostile, planId: plan, startDate: '2026-01-01', payment: { amount: 500, method: 'cash', note: XSS } });
  const qrHostile = (await api('GET', `/api/members/${hostile}`, T)).qrPayload;
  const expiredM = await mk(XSS2, '9000000002');
  await api('POST', '/api/memberships', T, { memberId: expiredM, planId: plan, startDate: '2026-01-01' });
  const active = await mk('Active Anita', '9000000003', { email: 'anita@ui.test', password: 'anitapass12' });
  await api('POST', '/api/memberships', T, { memberId: active, planId: plan, payment: { amount: 500, method: 'upi', note: XSS2 } });
  const qrActive = (await api('GET', `/api/members/${active}`, T)).qrPayload;
  await api('POST', '/api/attendance/check-in', T, { qrToken: qrActive });

  // log the browser in as the admin
  await waitFor(() => $('#loginForm'), 'login');
  let f = $('#loginForm'); f.elements.email.value = 'x@ui.test'; f.elements.password.value = 'secret123'; submit(f);
  await waitFor(() => window.location.hash === '#/dashboard', 'dashboard');

  console.log('\n[A] XSS — hostile names render as inert text');
  const inert = (label) => {
    const injected = document.querySelectorAll('#app-main img, #app-main script, #app-main svg[onload], [onerror], [onload], #app-header img, #app-bottomnav img');
    check(`${label}: no injected elements/handlers; no script ran`, injected.length === 0 && window.__xss === undefined && globalThis.__xss === undefined, `found ${injected.length}`);
  };
  const pages = [
    ['#/dashboard', /Total members/, 'dashboard (header shows hostile gym + user name)'],
    ['#/members', /Active Anita/, 'members list'],
    [`#/members/${hostile}`, /Membership history/, 'member detail (name, plan, payment note)'],
    [`#/members/${hostile}/edit`, /Edit member/, 'member edit form (values in attributes)'],
    ['#/payments', /payments?/, 'payments list'],
    ['#/attendance', /check-in/, 'attendance'],
    ['#/plans', /Membership plans/, 'plans (hostile plan name)'],
    ['#/gym', /Gym profile/, 'gym profile form (hostile gym name in input value)'],
    ['#/more', /More/, 'more']
  ];
  for (const [hash, rx, label] of pages) {
    await go(hash); await waitFor(() => rx.test(text()) || rx.test($('#app-main').innerHTML), label);
    await sleep(80); inert(label);
  }
  await go(`#/members/${hostile}`); await waitFor(() => /Membership history/.test(text()), 'detail');
  check('hostile name is visible as literal text', text().includes('<img src=x'), text().slice(0, 150));
  const nameInput = (await (async () => { await go(`#/members/${hostile}/edit`); await waitFor(() => $('#memberForm'), 'edit'); return $('#memberForm').elements.name.value; })());
  check('edit form field holds the exact hostile string (attribute-escaped round trip)', nameInput === XSS, nameInput);
  // check-in result card with hostile member name + expired denial card
  await go('#/checkin'); await waitFor(() => $('#manualForm'), 'checkin');
  $('#manualCode').value = qrHostile; submit($('#manualForm'));
  await waitFor(() => /Not allowed|Checked in/.test($('#result').textContent), 'hostile checkin');
  inert('check-in result (hostile member name)');
  check('expired member is denied with the reason shown ("Not allowed" card)', /Not allowed/.test($('#result').textContent) && /expired/i.test($('#result').textContent), $('#result').textContent);
  // member portal with hostile names
  await realFetch(apiBase + '/health');
  const logout = () => click($('#logoutBtn'));
  logout(); await waitFor(() => $('#loginForm'), 'login again');
  f = $('#loginForm'); f.elements.email.value = 'h@ui.test'; f.elements.password.value = 'hostilepass1'; submit(f);
  await waitFor(() => window.location.hash === '#/portal', 'portal'); await waitFor(() => /Membership history/.test(text()), 'portal content'); await sleep(80);
  inert('member portal (hostile name, plan, gym)');
  for (const h of ['#/portal/payments', '#/portal/attendance']) { await go(h); await sleep(200); inert('portal ' + h); }
  logout(); await waitFor(() => $('#loginForm'), 'login again');
  f = $('#loginForm'); f.elements.email.value = 'x@ui.test'; f.elements.password.value = 'secret123'; submit(f);
  await waitFor(() => window.location.hash === '#/dashboard', 'admin back');

  console.log('\n[B] CAMERA / QR SCANNER LIFECYCLE (simulated camera)');
  const alive = () => camera.tracks.filter((t) => !t.stopped).length;
  const reset = () => { camera.tracks.length = 0; camera.gumCalls = 0; camera.mode = 'ok'; delete window.BarcodeDetector; };
  const openCheckin = async () => { await go('#/members'); await waitFor(() => $('#search'), 'members page'); await go('#/checkin'); await waitFor(() => $('#camToggle'), 'checkin page'); };

  reset(); await openCheckin();
  check('camera is OFF until the user taps Start (no permission prompt on page load)', camera.gumCalls === 0 && alive() === 0);

  reset(); camera.mode = 'denied'; await openCheckin(); click($('#camToggle'));
  await waitFor(() => /permission was denied/i.test($('#camMsg').textContent), 'denied msg');
  check('permission denied → clear message, camera stays off, manual entry still available', /handheld scanner/.test($('#camMsg').textContent) && !$('#camToggle').disabled && !!$('#manualForm') && alive() === 0);
  camera.mode = 'ok'; click($('#camToggle')); await waitFor(() => alive() === 1, 'retry works');
  check('after denial the user can retry and the camera starts', alive() === 1);

  reset(); camera.mode = 'none'; await openCheckin(); click($('#camToggle'));
  await waitFor(() => /No camera was found/i.test($('#camMsg').textContent), 'none msg');
  check('no camera device → clear message', true);
  reset(); camera.mode = 'busy'; await openCheckin(); click($('#camToggle'));
  await waitFor(() => /used by another app/i.test($('#camMsg').textContent), 'busy msg');
  check('camera busy → clear message', true);

  reset(); window.isSecureContext = false; await openCheckin(); click($('#camToggle'));
  await sleep(50);
  check('insecure (http) page → explains https is required, never calls getUserMedia', /secure \(https\)/.test($('#camMsg').textContent) && camera.gumCalls === 0);
  window.isSecureContext = true;

  reset(); await openCheckin(); click($('#camToggle')); click($('#camToggle')); click($('#camToggle'));
  await waitFor(() => alive() >= 1, 'started'); await sleep(100);
  check('rapid triple-tap on Start opens ONE camera stream (no leaked stream)', camera.gumCalls === 1 && camera.tracks.length === 1, `gum=${camera.gumCalls} tracks=${camera.tracks.length}`);
  click($('#camToggle')); await waitFor(() => alive() === 0, 'stopped');
  check('Stop camera releases the camera hardware (track.stop called)', alive() === 0 && /Start camera/.test($('#camToggle').textContent));

  reset(); await openCheckin(); click($('#camToggle')); await waitFor(() => alive() === 1, 'started');
  await go('#/members'); await sleep(80);
  check('navigating away while scanning releases the camera', alive() === 0, `alive=${alive()}`);

  reset(); camera.mode = 'deferred'; await openCheckin(); click($('#camToggle')); await waitFor(() => camera.pending, 'prompt open');
  await go('#/dashboard'); await sleep(50); camera.pending(); await sleep(150);
  check('REGRESSION: permission granted AFTER leaving the page → camera is switched off, not left running', camera.tracks.length === 1 && alive() === 0, `tracks=${camera.tracks.length} alive=${alive()}`);

  reset(); await openCheckin(); click($('#camToggle')); await waitFor(() => alive() === 1, 'started');
  Object.defineProperty(document, 'hidden', { value: true, configurable: true }); document.dispatchEvent(new window.Event('visibilitychange')); await sleep(50);
  check('tab/app hidden → camera released and user told to tap Start again', alive() === 0 && /paused/i.test($('#camMsg').textContent));
  Object.defineProperty(document, 'hidden', { value: false, configurable: true });

  // end-to-end scan with a mocked BarcodeDetector that "sees" the QR continuously
  reset(); let seen = 0; window.BarcodeDetector = class { static async getSupportedFormats() { return ['qr_code']; } async detect() { seen += 1; return [{ rawValue: qrActive }]; } };
  await openCheckin(); calls.length = 0; click($('#camToggle'));
  await waitFor(() => /Checked in|Already checked in/.test($('#result').textContent), 'scan result', 8000);
  const firstResult = $('#result').textContent;
  await sleep(1500);
  const submits = calls.filter((c) => c.startsWith('/api/attendance/check-in')).length;
  check('camera sees a valid QR → server check-in result is shown', /Active Anita/.test(firstResult), firstResult);
  check(`the same QR held in view for 1.5 s (${seen} detector frames) is submitted ONCE, not on every frame`, seen > 3 && submits === 1, `frames=${seen} submits=${submits}`);
  check('server-side duplicate window reports "Already checked in" (member was checked in earlier in this run)', /Already checked in/.test(firstResult));
  click($('#camToggle')); await waitFor(() => alive() === 0, 'stop');

  // jsQR fallback path (no BarcodeDetector): the vendored decoder must load and decode a real QR frame
  reset(); delete window.BarcodeDetector;
  await openCheckin();
  // Draw a real QR onto the canvas the page will read, by stubbing the 2D context with real QR pixels.
  const vm = require('vm');
  const qrSrc = fs.readFileSync(path.join(FRONTEND, 'vendor', 'qrcode-generator-1.4.4.js'), 'utf8');
  const sandbox = vm.createContext({ self: {}, console }); vm.runInContext(qrSrc, sandbox); const qrcode = vm.runInContext('this', sandbox).qrcode;
  const q = qrcode(0, 'M'); q.addData(qrHostile); q.make();
  const n = q.getModuleCount(); const cell = 6; const margin = 24; const size = n * cell + 2 * margin;
  const px = new Uint8ClampedArray(size * size * 4).fill(255);
  for (let rr = 0; rr < n; rr += 1) for (let cc = 0; cc < n; cc += 1) if (q.isDark(rr, cc)) for (let y = 0; y < cell; y += 1) for (let x = 0; x < cell; x += 1) { const i = ((margin + rr * cell + y) * size + margin + cc * cell + x) * 4; px[i] = px[i + 1] = px[i + 2] = 0; }
  Object.defineProperty(window.HTMLVideoElement.prototype, 'videoWidth', { get: () => size, configurable: true });
  Object.defineProperty(window.HTMLVideoElement.prototype, 'videoHeight', { get: () => size, configurable: true });
  window.HTMLCanvasElement.prototype.getContext = () => ({ drawImage() {}, getImageData: () => ({ data: px }) });
  calls.length = 0; click($('#camToggle'));
  await waitFor(() => calls.some((c) => c.startsWith('/api/attendance/check-in')), 'jsQR decoded + submitted', 8000);
  await waitFor(() => /Not allowed|Checked in/.test($('#result').textContent), 'jsQR result', 8000);
  check('jsQR fallback: vendored decoder loads, decodes a real QR frame and submits the token to the server', /Not allowed/.test($('#result').textContent) && /expired/i.test($('#result').textContent), $('#result').textContent);
  click($('#camToggle')); await waitFor(() => alive() === 0, 'stop');

  console.log('\n[C] CSV IMPORT SCREEN (file → preview → confirm)');
  await go('#/members/import'); await waitFor(() => $('#file'), 'import page');
  const pickFile = (content, name = 'members.csv') => {
    const input = $('#file');
    Object.defineProperty(input, 'files', { value: [{ name, size: content.length, text: async () => content }], configurable: true });
    input.dispatchEvent(new window.Event('change', { bubbles: true }));
  };
  pickFile('name,phone,email\n"Imp, Orted",9123456701,\nBad Phone,12ab,\nNo Contact,,\n' + 'Existing,9000000003,\n');
  await waitFor(() => $('#confirm') || /error/i.test($('#formError').textContent), 'preview');
  check('preview lists each row with its status (1 ready, 1 duplicate, 2 errors)', /1 ready to import/.test(text()) && /1 duplicate/.test(text()) && /2 with errors/.test(text()), text().slice(0, 300));
  const before = (await api('GET', '/api/members?limit=100', T)).pagination.total;
  check('preview saved nothing', before === (await api('GET', '/api/members?limit=100', T)).pagination.total);
  click($('#confirm')); await waitFor(() => /1 member imported/.test(text()), 'imported');
  check('confirm imports only the valid row and reports the skipped ones', /1 duplicate/.test(text()) && /2 with errors/.test(text()));
  check('database now has exactly one more member', (await api('GET', '/api/members?limit=100', T)).pagination.total === before + 1);
  await go('#/members/import'); await waitFor(() => $('#file'), 'import page again');
  pickFile('phone,email\n9123456702,\n'); await waitFor(() => /No .name. column/.test($('#formError').textContent), 'missing name col');
  check('file without a "name" column is rejected with a clear message', true);
  pickFile('name,phone\n'); await waitFor(() => /no member rows/.test($('#formError').textContent), 'empty');
  check('header-only file is rejected with a clear message', true);
  pickFile('name,phone\n"Unclosed,9123456703\nNext,9123456704\n'); await waitFor(() => $('#confirm') || /error|valid/i.test(text()), 'malformed preview');
  const malformed = (await api('GET', '/api/members?search=9123456703', T)).members.length + (await api('GET', '/api/members?search=9123456704', T)).members.length;
  check('malformed CSV (unclosed quote) never silently creates members — it only produces a preview', malformed === 0);

  console.log('\n[D] VENDORED LIBRARIES');
  check('no runtime CDN requests for QR libraries (served from /vendor)', !fs.readFileSync(path.join(FRONTEND, 'js', 'components', 'qrCode.js'), 'utf8').includes('cdnjs') && !fs.readFileSync(path.join(FRONTEND, 'js', 'pages', 'checkin.js'), 'utf8').includes('cdnjs'));

  server.close(); await mongoose.connection.dropDatabase(); await mongoose.disconnect();
  console.log(`\n${passed} passed, ${failures.length} failed`);
  if (failures.length) { console.log('FAILED:\n - ' + failures.join('\n - ')); process.exit(1); }
  process.exit(0);
})().catch((e) => { console.error('UI extra crashed:', e); process.exit(2); });
