// "Real gym simulation": the 20-step workflow of one small gym, with hand-computed expected numbers compared
// with what the API returns, and a second gym used to prove isolation.
//   MONGO_URI=mongodb://127.0.0.1:27017/hrk-test-sim node tests/gym-simulation.js
process.env.JWT_SECRET = process.env.JWT_SECRET || 'test-secret-for-simulation-1234567890';
process.env.MONGO_URI = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/hrk-test-sim-' + Date.now();
process.env.TRUST_PROXY = '1';
const mongoose = require('mongoose');
const { assertSafeTestDb, resetDb } = require('./helpers');
const app = require('../app');
const { simulate } = require('./lib/simulate');
let base; let passed = 0; const failures = [];
const check = (name, cond, extra) => { if (cond) { passed += 1; console.log('  ✓', name); } else { failures.push(name); console.log('  ✗', name, extra !== undefined ? JSON.stringify(extra).slice(0, 300) : ''); } };
const call = async (method, path, { token, body } = {}) => { const res = await fetch(base + path, { method, headers: { 'Content-Type': 'application/json', 'X-Forwarded-For': '10.9.9.' + (1 + Math.floor(Math.random() * 200)), ...(token ? { Authorization: `Bearer ${token}` } : {}) }, body: body ? JSON.stringify(body) : undefined }); const json = await res.json().catch(() => null); return { status: res.status, body: json, data: json && json.data }; };

(async () => {
  assertSafeTestDb(process.env.MONGO_URI); await mongoose.connect(process.env.MONGO_URI); await resetDb();
  const server = app.listen(0); base = `http://127.0.0.1:${server.address().port}`;
  const S = await simulate(call); const { T, M, expected: E, plans, d } = S;
  console.log('\nSimulated steps completed through the API:'); S.log.forEach((l) => console.log('   ' + l));

  console.log('\n[check-ins]');
  for (const n of E.checkins.allowed) check(`${n}: checked in (201)`, S.scans[n].status === 201 && S.scans[n].data.result === 'checked_in', S.scans[n].body);
  for (const [n, why] of Object.entries(E.checkins.refused)) check(`${n}: refused (403, reason "${why}")`, S.scans[n].status === 403 && S.scans[n].body.data.reason === why, S.scans[n].body);
  check('Anita scanned a second time → duplicate, no extra record', S.scans.AnitaAgain.status === 200 && S.scans.AnitaAgain.data.result === 'duplicate');
  let r = await call('GET', `/api/attendance?date=${S.today}`, { token: T }); check("today's attendance has exactly the 6 eligible members", r.data.attendance.length === 6 && E.checkins.allowed.every((n) => r.data.attendance.some((a) => a.member && a.member.name === `${n} Test`)), r.data.attendance.map((a) => a.member && a.member.name));

  console.log('\n[11] dashboard: expected (hand-computed) vs API');
  r = await call('GET', '/api/dashboard', { token: T }); const t = r.data.totals;
  for (const k of Object.keys(E.totals)) check(`dashboard.${k}: expected ${E.totals[k]}, API ${t[k]}`, t[k] === E.totals[k], t);
  check('needs-attention "expiring" = Bala, Indu', JSON.stringify(r.data.attention.expiring.map((x) => x.name).sort()) === JSON.stringify(E.attentionExpiring), r.data.attention.expiring.map((x) => x.name));
  check('needs-attention "expired" = Esha', JSON.stringify(r.data.attention.expired.map((x) => x.name)) === JSON.stringify(E.attentionExpired));
  check('needs-attention "payment not recorded" = Farid (Hari is inactive and excluded)', JSON.stringify(r.data.attention.unpaid.map((x) => x.name)) === JSON.stringify(E.attentionUnpaid), r.data.attention.unpaid.map((x) => x.name));
  check('Bala shows 2 days left, Indu shows 0 (last day)', r.data.attention.expiring.find((x) => x.name === 'Bala Test').daysLeft === 2 && r.data.attention.expiring.find((x) => x.name === 'Indu Test').daysLeft === 0);

  console.log('\n[member list]');
  r = await call('GET', '/api/members?limit=100', { token: T });
  for (const [n, st] of Object.entries(E.statuses)) check(`${n}: status ${st}`, r.data.members.find((m) => m.name === `${n} Test`).membership.status === st);
  for (const [f, n] of [['active', 7], ['expiring', 2], ['expired', 1], ['upcoming', 1], ['none', 1]]) check(`filter "${f}" returns ${n}`, (await call(`GET`, `/api/members?status=${f}&limit=100`, { token: T })).data.members.length === n);
  check('search by phone finds exactly one', (await call('GET', '/api/members?search=9800000005', { token: T })).data.members.length === 1);

  console.log('\n[12-16] member portal');
  const lal = await call('POST', '/api/auth/login', { body: { email: 'lalitha@hrktest.gym', password: 'lalithapass123' } }); const L = lal.data.token;
  r = await call('GET', '/api/me', { token: L }); const adminQr = (await call('GET', `/api/members/${M.Lalitha}`, { token: T })).data.qrPayload;
  check('Lalitha: membership status active, quarterly, 1 period', r.data.membership.status === 'active' && r.data.membership.planName === 'Quarterly' && r.data.memberships.length === 1, r.data.membership);
  check('Lalitha: her QR is the same token the front desk accepts', r.data.qrPayload === adminQr);
  check('Lalitha: 1 attendance record', (await call('GET', '/api/me/attendance', { token: L })).data.attendance.length === 1);
  r = await call('GET', '/api/me/payments', { token: L }); check('Lalitha: 1 payment of ₹2,700', r.data.payments.length === 1 && r.data.payments[0].amount === 2700);
  const ani = await call('POST', '/api/auth/login', { body: { email: 'anita@hrktest.gym', password: 'anitapass123' } });
  r = await call('GET', '/api/me/payments', { token: ani.data.token }); check("Anita sees only Anita's payment (₹1,000), not Lalitha's", r.data.payments.length === 1 && r.data.payments[0].amount === 1000);
  check('Anita attendance = 1 (duplicate scan not counted)', (await call('GET', '/api/me/attendance', { token: ani.data.token })).data.attendance.length === 1);
  check('a member cannot call admin endpoints (403)', (await call('GET', '/api/members', { token: L })).status === 403);

  console.log('\n[17-19] renew Bala (expiring) and verify history + dashboard change');
  const balaBefore = (await call('GET', `/api/members/${M.Bala}`, { token: T })).data;
  r = await call('POST', `/api/members/${M.Bala}/renew`, { token: T, body: { planId: plans.monthly, payment: { amount: 1000, method: 'upi' } } });
  check('renewal created; starts the day after the current period ends', r.status === 201 && r.data.membership.startDate === d(3), r.body);
  const balaAfter = (await call('GET', `/api/members/${M.Bala}`, { token: T })).data;
  check('old membership is still there, unchanged', balaAfter.memberships.length === 2 && balaAfter.memberships.some((m) => m._id === balaBefore.memberships[0]._id && m.startDate === balaBefore.memberships[0].startDate && m.endDate === balaBefore.memberships[0].endDate));
  check('Bala is no longer "expiring" (coverage extended by the renewal)', balaAfter.membership.status === 'active', balaAfter.membership);
  r = await call('GET', '/api/dashboard', { token: T });
  check('dashboard after renewal: expiring 2 → 1 (only Indu)', r.data.totals.expiringMemberships === 1 && r.data.attention.expiring.length === 1 && r.data.attention.expiring[0].name === 'Indu Test', r.data.totals);
  check(`dashboard after renewal: today's revenue ${E.totals.todayRevenue} → ${E.totals.todayRevenue + 1000}`, r.data.totals.todayRevenue === E.totals.todayRevenue + 1000, r.data.totals.todayRevenue);
  check('dashboard after renewal: active memberships unchanged (9), check-ins unchanged (6)', r.data.totals.activeMemberships === 9 && r.data.totals.todayCheckIns === 6);

  console.log('\n[20] gym isolation: a second gym');
  const B = (await call('POST', '/api/auth/register', { body: { gymName: 'Other Gym', name: 'B Owner', email: 'b@other.gym', password: 'gympass1234' } })).data.token;
  const bp = (await call('POST', '/api/plans', { token: B, body: { name: 'Monthly', durationValue: 1, price: 500 } })).data.plan._id;
  const bm = (await call('POST', '/api/members', { token: B, body: { name: 'Bee Member', phone: '9700000001' } })).data.member._id;
  await call('POST', '/api/memberships', { token: B, body: { memberId: bm, planId: bp, payment: { amount: 500, method: 'cash' } } });
  r = await call('GET', '/api/dashboard', { token: B }); check('gym B dashboard: 1 member, ₹500, 0 check-ins (nothing from gym A)', r.data.totals.totalMembers === 1 && r.data.totals.todayRevenue === 500 && r.data.totals.todayCheckIns === 0, r.data.totals);
  r = await call('GET', '/api/dashboard', { token: T }); check('gym A dashboard unchanged by gym B (12 members, check-ins 6)', r.data.totals.totalMembers === 12 && r.data.totals.todayCheckIns === 6);
  check("gym A cannot read gym B's member (404)", (await call('GET', `/api/members/${bm}`, { token: T })).status === 404);
  check("gym A cannot pay for gym B's member (404)", (await call('POST', '/api/payments', { token: T, body: { memberId: bm, amount: 1, method: 'cash' } })).status === 404);
  check("gym A cannot scan gym B's QR (404)", (await call('POST', '/api/attendance/check-in', { token: T, body: { qrToken: (await call('GET', `/api/members/${bm}`, { token: B })).data.qrPayload } })).status === 404);
  check('payment totals are separate (A ≠ B)', (await call('GET', '/api/payments', { token: B })).data.totalAmount === 500);

  server.close(); await mongoose.connection.dropDatabase(); await mongoose.disconnect();
  console.log(`\n${passed} passed, ${failures.length} failed`);
  if (failures.length) { console.log('FAILED:\n - ' + failures.join('\n - ')); process.exit(1); }
  process.exit(0);
})().catch((e) => { console.error('Simulation crashed:', e); process.exit(2); });
