const { verifyToken } = require('../services/jwtService');
const User = require('../models/User');

/**
 * Requires "Authorization: Bearer <token>". Attaches req.user (with gymId and
 * role). Every data query downstream scopes by req.user.gymId.
 */
const protect = async (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ success: false, message: 'No authentication token provided' });
    }

    let decoded;
    try {
      decoded = verifyToken(authHeader.split(' ')[1]);
    } catch (error) {
      return res.status(401).json({ success: false, message: 'Invalid or expired token' });
    }

    const user = await User.findById(decoded.id);
    if (!user || !user.gymId) {
      return res.status(401).json({ success: false, message: 'The user for this token no longer exists' });
    }

    // A password reset invalidates sessions that were started before it.
    if (user.passwordChangedAt && decoded.iat * 1000 < Math.floor(user.passwordChangedAt.getTime() / 1000) * 1000) {
      return res.status(401).json({ success: false, message: 'Your password was changed. Please log in again.' });
    }

    req.user = user;
    next();
  } catch (error) {
    next(error);
  }
};

/** Restricts a route to one role. Use after protect. */
const requireRole = (role) => (req, res, next) => {
  if (!req.user || req.user.role !== role) {
    return res.status(403).json({ success: false, message: 'You do not have permission to do this' });
  }
  next();
};

module.exports = { protect, requireRole };
