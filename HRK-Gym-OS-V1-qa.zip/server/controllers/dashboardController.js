const Member = require('../models/Member');
const Membership = require('../models/Membership');
const Payment = require('../models/Payment');
const Attendance = require('../models/Attendance');
const asyncHandler = require('../utils/asyncHandler');
const v = require('../utils/validate');
const { EXPIRING_DAYS } = require('../config/constants');
const { todayIST } = require('../utils/dates');
const { getStatusMap, statusFor } = require('../services/membershipService');

const ATTENTION_LIMIT = 8;

// GET /api/dashboard — every number is computed from the database on each request.
const getDashboard = asyncHandler(async (req, res) => {
  const gymId = req.user.gymId;
  const today = todayIST();

  const [members, statusMap, todayCheckIns, todayPayments, openMemberships] = await Promise.all([
    Member.find({ gymId }).select('name memberCode phone email status').lean(),
    getStatusMap(gymId, today),
    Attendance.countDocuments({ gymId, date: today }),
    Payment.find({ gymId, paidOn: today }).select('amount').lean(),
    Membership.find({ gymId, endDate: { $gte: today } }).select('memberId planName price startDate endDate').lean()
  ]);

  let activeMemberships = 0;
  let expiringMemberships = 0;
  let expiredMembers = 0;
  const expiring = [];
  const expired = [];

  for (const m of members) {
    const derived = statusFor(statusMap, m._id);
    const entry = {
      memberId: m._id, name: m.name, memberCode: m.memberCode, phone: m.phone || null, email: m.email || null,
      endDate: derived.coverageEnd || derived.lastEndDate, daysLeft: derived.daysLeft
    };
    if (derived.status === 'active' || derived.status === 'expiring') activeMemberships += 1;
    if (derived.status === 'expiring') {
      expiringMemberships += 1;
      if (m.status === 'active') expiring.push(entry);
    }
    if (derived.status === 'expired') {
      expiredMembers += 1;
      if (m.status === 'active') expired.push({ ...entry, daysAgo: -derived.daysLeft });
    }
  }
  expiring.sort((a, b) => a.daysLeft - b.daysLeft);
  expired.sort((a, b) => a.daysAgo - b.daysAgo); // most recently expired first

  // Memberships (still running or booked) that have no payment recorded against them.
  const unpaid = [];
  if (openMemberships.length) {
    const paid = await Payment.find({ gymId, membershipId: { $in: openMemberships.map((m) => m._id) } }).select('membershipId').lean();
    const paidIds = new Set(paid.map((p) => p.membershipId.toString()));
    const memberById = new Map(members.map((m) => [m._id.toString(), m]));
    for (const ms of openMemberships) {
      if (paidIds.has(ms._id.toString())) continue;
      const m = memberById.get(ms.memberId.toString());
      if (!m || m.status !== 'active') continue;
      unpaid.push({ membershipId: ms._id, memberId: m._id, name: m.name, memberCode: m.memberCode, planName: ms.planName, price: ms.price, startDate: ms.startDate, endDate: ms.endDate });
    }
    unpaid.sort((a, b) => (a.startDate < b.startDate ? -1 : 1));
  }

  res.status(200).json({
    success: true,
    message: 'Dashboard retrieved',
    data: {
      date: today,
      expiringWithinDays: EXPIRING_DAYS,
      totals: {
        totalMembers: members.length,
        inactiveMembers: members.filter((m) => m.status === 'inactive').length,
        activeMemberships,
        expiringMemberships,
        expiredMembers,
        todayCheckIns,
        todayRevenue: v.round2(todayPayments.reduce((sum, p) => sum + p.amount, 0))
      },
      attention: {
        expiring: expiring.slice(0, ATTENTION_LIMIT),
        expiringCount: expiring.length,
        expired: expired.slice(0, ATTENTION_LIMIT),
        expiredCount: expired.length,
        unpaid: unpaid.slice(0, ATTENTION_LIMIT),
        unpaidCount: unpaid.length
      }
    }
  });
});

module.exports = { getDashboard };
