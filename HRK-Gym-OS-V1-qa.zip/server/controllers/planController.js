const MembershipPlan = require('../models/MembershipPlan');
const asyncHandler = require('../utils/asyncHandler');
const AppError = require('../utils/AppError');
const v = require('../utils/validate');
const { MAX_PLAN_DAYS, MAX_PLAN_MONTHS, MAX_MONEY } = require('../config/constants');

const readPlan = (body) => {
  const durationUnit = v.oneOf(body.durationUnit || 'months', 'Duration unit', ['days', 'months'], { required: true });
  const maxDuration = durationUnit === 'days' ? MAX_PLAN_DAYS : MAX_PLAN_MONTHS;
  return {
    name: v.str(body.name, 'Plan name', { required: true, max: 80 }),
    durationValue: v.number(body.durationValue, 'Duration', { required: true, min: 1, max: maxDuration, integer: true }),
    durationUnit,
    price: v.money(body.price, 'Price', { required: true, min: 0, max: MAX_MONEY }),
    isActive: body.isActive === undefined ? true : Boolean(body.isActive)
  };
};

// GET /api/plans?active=true
const listPlans = asyncHandler(async (req, res) => {
  const filter = { gymId: req.user.gymId };
  if (req.query.active === 'true') filter.isActive = true;
  const plans = await MembershipPlan.find(filter).sort({ isActive: -1, durationValue: 1, name: 1 });
  res.status(200).json({ success: true, message: 'Plans retrieved', data: { plans } });
});

// POST /api/plans
const createPlan = asyncHandler(async (req, res) => {
  const plan = await MembershipPlan.create({ gymId: req.user.gymId, ...readPlan(req.body) });
  res.status(201).json({ success: true, message: 'Plan created', data: { plan } });
});

// PUT /api/plans/:id — editing a plan never changes memberships already sold (they keep a snapshot).
const updatePlan = asyncHandler(async (req, res) => {
  const plan = await MembershipPlan.findOne({ _id: v.objectId(req.params.id), gymId: req.user.gymId });
  if (!plan) throw new AppError('Plan not found', 404);
  Object.assign(plan, readPlan(req.body));
  await plan.save();
  res.status(200).json({ success: true, message: 'Plan updated', data: { plan } });
});

// DELETE /api/plans/:id
const deletePlan = asyncHandler(async (req, res) => {
  const plan = await MembershipPlan.findOneAndDelete({ _id: v.objectId(req.params.id), gymId: req.user.gymId });
  if (!plan) throw new AppError('Plan not found', 404);
  res.status(200).json({ success: true, message: 'Plan deleted', data: {} });
});

module.exports = { listPlans, createPlan, updatePlan, deletePlan };
