const Member = require('../models/Member');
const Gym = require('../models/Gym');
const User = require('../models/User');
const Membership = require('../models/Membership');
const MembershipPlan = require('../models/MembershipPlan');
const Payment = require('../models/Payment');
const Attendance = require('../models/Attendance');
const asyncHandler = require('../utils/asyncHandler');
const AppError = require('../utils/AppError');
const v = require('../utils/validate');
const { GENDERS } = require('../config/constants');
const { todayIST } = require('../utils/dates');
const { hashPassword } = require('../services/passwordService');
const { readPayment } = require('../services/paymentInput');
const { getStatusMap, statusFor, getMemberStatus, createMembership } = require('../services/membershipService');

const QR_PREFIX = 'hrk:';
const qrPayload = (member) => `${QR_PREFIX}${member.qrToken}`;

const MEMBERSHIP_STATUSES = ['active', 'expiring', 'expired', 'upcoming', 'none'];

const summarize = (derived) => ({
  status: derived.status,
  planName: derived.currentMembership ? derived.currentMembership.planName : null,
  coverageEnd: derived.coverageEnd,
  daysLeft: derived.daysLeft,
  lastEndDate: derived.lastEndDate,
  nextStartDate: derived.nextStartDate
});

const nextMemberCode = async (gymId) => {
  const gym = await Gym.findByIdAndUpdate(gymId, { $inc: { memberSeq: 1 } }, { new: true });
  return `M${String(gym.memberSeq).padStart(4, '0')}`;
};

// Maps a unique-index violation (a race the pre-checks can't catch) to a friendly 409. The message is chosen by
// looking at what actually exists, not by parsing the driver's error text.
const duplicateError = async (err, { gymId, phone, email, excludeId }) => {
  if (!(err && err.code === 11000)) return err;
  const others = excludeId ? { _id: { $ne: excludeId } } : {};
  if (phone && (await Member.exists({ gymId, phone, ...others }))) return new AppError('A member with this phone number already exists', 409);
  if (email && (await Member.exists({ gymId, email, ...others }))) return new AppError('A member with this email already exists', 409);
  return new AppError('This member already exists', 409);
};

// Creates a member with the next free member code (M0001, M0002, ...). The counter is incremented atomically,
// and the unique (gymId, memberCode) index is the safety net: if two requests ever get the same code, the loser
// simply takes the next one instead of failing.
const createWithNextCode = async (data) => {
  for (let attempt = 0; attempt < 6; attempt += 1) {
    const memberCode = await nextMemberCode(data.gymId);
    try {
      return await Member.create({ ...data, memberCode, qrToken: Member.newQrToken() });
    } catch (err) {
      if (!(err && err.code === 11000)) throw err;
      // Which unique index was hit? Don't parse error text (it differs between MongoDB versions / compatible
      // engines): ask the database. If the code is already taken, try the next one; otherwise it is a real
      // duplicate (phone / email) and is reported by the caller.
      const codeTaken = await Member.exists({ gymId: data.gymId, memberCode });
      if (!codeTaken) throw err;
    }
  }
  throw new AppError('Could not allocate a member ID. Please try again.', 503);
};

const findMemberOr404 = async (req, id = req.params.id) => {
  const member = await Member.findOne({ _id: v.objectId(id, 'member id'), gymId: req.user.gymId });
  if (!member) throw new AppError('Member not found', 404);
  return member;
};

/** Reads and validates member fields from a request body. Only keys present are returned. */
const readMemberFields = (body) => {
  const out = {};
  const has = (k) => Object.prototype.hasOwnProperty.call(body, k);
  if (has('name')) out.name = v.str(body.name, 'Name', { required: true });
  if (has('email')) out.email = v.email(body.email, 'Email');
  if (has('phone')) out.phone = v.phone(body.phone, 'Phone');
  if (has('gender')) out.gender = v.oneOf(body.gender, 'Gender', GENDERS);
  if (has('dateOfBirth')) {
    out.dateOfBirth = v.date(body.dateOfBirth, 'Date of birth');
    if (out.dateOfBirth && out.dateOfBirth > todayIST()) throw new AppError('Date of birth cannot be in the future', 400);
  }
  if (has('joinedDate')) out.joinedDate = v.date(body.joinedDate, 'Joined date', { required: true });
  if (has('status')) out.status = v.oneOf(body.status, 'Status', ['active', 'inactive'], { required: true });
  return out;
};

// GET /api/members?search=&status=&accountStatus=&page=&limit=
const listMembers = asyncHandler(async (req, res) => {
  const { status, accountStatus } = req.query;
  const search = v.searchText(req.query.search);
  const filter = { gymId: req.user.gymId };

  if (search) {
    const rx = { $regex: v.escapeRegex(search), $options: 'i' };
    filter.$or = [{ name: rx }, { email: rx }, { phone: rx }, { memberCode: rx }];
  }
  if (accountStatus) filter.status = v.oneOf(accountStatus, 'accountStatus', ['active', 'inactive']);
  if (status) v.oneOf(status, 'status', MEMBERSHIP_STATUSES);

  const [members, statusMap] = await Promise.all([
    Member.find(filter).sort({ createdAt: -1 }),
    getStatusMap(req.user.gymId)
  ]);

  let rows = members.map((m) => ({ ...m.toJSON(), membership: summarize(statusFor(statusMap, m._id)) }));
  if (status) rows = rows.filter((r) => r.membership.status === status);

  const page = Math.max(1, parseInt(req.query.page, 10) || 1);
  const limit = Math.min(100, Math.max(1, parseInt(req.query.limit, 10) || 20));
  const total = rows.length;

  res.status(200).json({
    success: true,
    message: 'Members retrieved',
    data: {
      members: rows.slice((page - 1) * limit, page * limit),
      pagination: { page, limit, total, pages: Math.max(1, Math.ceil(total / limit)) }
    }
  });
});

// POST /api/members
const createMember = asyncHandler(async (req, res) => {
  const fields = readMemberFields({ joinedDate: todayIST(), ...req.body });
  if (!fields.name) throw new AppError('Name is required', 400);
  if (!fields.email && !fields.phone) throw new AppError('Provide an email or a phone number', 400);
  const portalPassword = v.password(req.body.password, 'Portal password', { required: false });
  if (portalPassword && !fields.email) throw new AppError('An email is required to give a member portal access', 400);

  const gymId = req.user.gymId;
  if (fields.email) {
    if (await Member.findOne({ gymId, email: fields.email })) throw new AppError('A member with this email already exists', 409);
    if (portalPassword && (await User.findOne({ email: fields.email }))) {
      throw new AppError('This email is already used by another login', 409);
    }
  }
  if (fields.phone && (await Member.findOne({ gymId, phone: fields.phone }))) {
    throw new AppError('A member with this phone number already exists', 409);
  }

  let member;
  try {
    member = await createWithNextCode({ ...fields, gymId });
  } catch (err) {
    throw await duplicateError(err, { gymId, phone: fields.phone, email: fields.email });
  }

  if (portalPassword) {
    try {
      const user = await User.create({
        name: member.name,
        email: member.email,
        password: await hashPassword(portalPassword),
        role: 'member',
        gymId,
        memberId: member._id
      });
      member.userId = user._id;
      await member.save();
    } catch (err) {
      await Member.deleteOne({ _id: member._id });
      throw err;
    }
  }

  res.status(201).json({ success: true, message: 'Member created', data: { member: { ...member.toJSON(), hasPortalLogin: Boolean(member.userId) } } });
});

// GET /api/members/:id — profile, membership history, payments, recent attendance, QR
const getMember = asyncHandler(async (req, res) => {
  const member = await findMemberOr404(req);
  const today = todayIST();
  const [memberships, payments, attendance, derived] = await Promise.all([
    Membership.find({ gymId: req.user.gymId, memberId: member._id }).sort({ startDate: -1 }),
    Payment.find({ gymId: req.user.gymId, memberId: member._id }).sort({ paidOn: -1, createdAt: -1 }),
    Attendance.find({ gymId: req.user.gymId, memberId: member._id }).sort({ checkedInAt: -1 }).limit(20),
    getMemberStatus(req.user.gymId, member._id, today)
  ]);

  const paidByMembership = new Map();
  for (const p of payments) {
    if (p.membershipId) {
      const k = p.membershipId.toString();
      paidByMembership.set(k, (paidByMembership.get(k) || 0) + p.amount);
    }
  }

  const history = memberships.map((m) => ({
    ...m.toJSON(),
    period: m.endDate < today ? 'ended' : m.startDate > today ? 'upcoming' : 'current',
    amountPaid: paidByMembership.get(m._id.toString()) || 0
  }));

  res.status(200).json({
    success: true,
    message: 'Member retrieved',
    data: {
      member: { ...member.toJSON(), hasPortalLogin: Boolean(member.userId) },
      qrPayload: qrPayload(member),
      membership: summarize(derived),
      memberships: history,
      payments,
      attendance
    }
  });
});

// PUT /api/members/:id
const updateMember = asyncHandler(async (req, res) => {
  const member = await findMemberOr404(req);
  const fields = readMemberFields(req.body);
  const gymId = req.user.gymId;
  const has = (k) => Object.prototype.hasOwnProperty.call(req.body, k);

  const nextEmail = has('email') ? fields.email : member.email;
  const nextPhone = has('phone') ? fields.phone : member.phone;
  if (!nextEmail && !nextPhone) throw new AppError('A member needs an email or a phone number', 400);

  if (has('email') && fields.email && fields.email !== member.email) {
    if (await Member.findOne({ gymId, email: fields.email, _id: { $ne: member._id } })) throw new AppError('A member with this email already exists', 409);
  }
  if (has('phone') && fields.phone && fields.phone !== member.phone) {
    if (await Member.findOne({ gymId, phone: fields.phone, _id: { $ne: member._id } })) throw new AppError('A member with this phone number already exists', 409);
  }

  let user = null;
  if (member.userId) {
    user = await User.findById(member.userId).select('+password');
    if (has('email') && !fields.email) throw new AppError("This member's portal login uses their email, so it can't be removed", 400);
    if (has('email') && fields.email && fields.email !== user.email) {
      if (await User.findOne({ email: fields.email, _id: { $ne: user._id } })) throw new AppError('This email is already used by another login', 409);
    }
  }

  const newPassword = v.password(req.body.password, 'Portal password', { required: false });
  if (newPassword && !nextEmail) throw new AppError('An email is required to give a member portal access', 400);
  if (newPassword && !user && (await User.findOne({ email: nextEmail }))) throw new AppError('This email is already used by another login', 409);

  for (const [k, val] of Object.entries(fields)) {
    if (val === undefined) member.set(k, undefined);
    else member.set(k, val);
  }
  try {
    await member.save();
  } catch (err) {
    throw await duplicateError(err, { gymId, phone: member.phone, email: member.email, excludeId: member._id });
  }

  if (user) {
    user.name = member.name;
    user.email = member.email;
    if (newPassword) {
      user.password = await hashPassword(newPassword);
      user.passwordChangedAt = new Date(); // signs the member out of any session started with the old password
    }
    await user.save();
  } else if (newPassword) {
    const created = await User.create({
      name: member.name,
      email: member.email,
      password: await hashPassword(newPassword),
      role: 'member',
      gymId,
      memberId: member._id
    });
    member.userId = created._id;
    await member.save();
  }

  res.status(200).json({ success: true, message: 'Member updated', data: { member: { ...member.toJSON(), hasPortalLogin: Boolean(member.userId) } } });
});

// DELETE /api/members/:id — removes the member, their memberships, attendance and portal login.
// Payments are financial records and are kept (they carry a copy of the member's name).
const deleteMember = asyncHandler(async (req, res) => {
  const member = await findMemberOr404(req);
  const gymId = req.user.gymId;
  await Promise.all([
    Membership.deleteMany({ gymId, memberId: member._id }),
    Attendance.deleteMany({ gymId, memberId: member._id }),
    member.userId ? User.deleteOne({ _id: member.userId, gymId }) : null
  ]);
  await Member.deleteOne({ _id: member._id });
  res.status(200).json({ success: true, message: 'Member deleted', data: {} });
});

// POST /api/members/:id/regenerate-qr — invalidates the old QR (e.g. lost phone / shared screenshot).
const regenerateQr = asyncHandler(async (req, res) => {
  const member = await findMemberOr404(req);
  member.qrToken = Member.newQrToken();
  await member.save();
  res.status(200).json({ success: true, message: 'QR code regenerated', data: { qrPayload: qrPayload(member) } });
});

// POST /api/members/:id/renew — adds a new membership period; history is never overwritten.
// planId is optional: it defaults to the member's most recent plan.
const renewMember = asyncHandler(async (req, res) => {
  const member = await findMemberOr404(req);
  const gymId = req.user.gymId;

  let plan;
  if (req.body.planId) {
    plan = await MembershipPlan.findOne({ _id: v.objectId(req.body.planId, 'plan id'), gymId });
  } else {
    const last = await Membership.findOne({ gymId, memberId: member._id }).sort({ endDate: -1 });
    if (!last) throw new AppError('This member has no previous membership. Choose a plan.', 400);
    plan = last.planId ? await MembershipPlan.findOne({ _id: last.planId, gymId }) : null;
    if (!plan) throw new AppError('The previous plan no longer exists. Choose a plan.', 400);
  }
  if (!plan) throw new AppError('Plan not found', 404);
  if (!plan.isActive) throw new AppError('This plan is inactive. Activate it or choose another plan.', 400);

  const startDate = v.date(req.body.startDate, 'Start date');
  const payment = readPayment(req.body.payment);
  const result = await createMembership({ gymId, member, plan, startDate, payment });

  res.status(201).json({ success: true, message: 'Membership renewed', data: result });
});

// POST /api/members/import  { rows: [...], dryRun?: boolean }
// Validates every row on the server. dryRun=true returns the preview only;
// otherwise valid rows are created. Invalid / duplicate rows are skipped and reported.
const MAX_IMPORT_ROWS = 500;
const importMembers = asyncHandler(async (req, res) => {
  const rows = req.body.rows;
  if (!Array.isArray(rows) || rows.length === 0) throw new AppError('No rows to import', 400);
  if (rows.length > MAX_IMPORT_ROWS) throw new AppError(`Import at most ${MAX_IMPORT_ROWS} members at a time`, 400);
  const dryRun = req.body.dryRun === true;
  const gymId = req.user.gymId;

  const existing = await Member.find({ gymId }).select('email phone').lean();
  const seenEmails = new Set(existing.filter((m) => m.email).map((m) => m.email));
  const seenPhones = new Set(existing.filter((m) => m.phone).map((m) => m.phone));

  const results = [];
  let created = 0;
  for (let i = 0; i < rows.length; i += 1) {
    const raw = rows[i] && typeof rows[i] === 'object' ? rows[i] : {};
    const line = i + 1;
    try {
      const fields = readMemberFields({
        name: raw.name, email: raw.email, phone: raw.phone, gender: raw.gender,
        dateOfBirth: raw.dateOfBirth, joinedDate: raw.joinedDate || todayIST()
      });
      if (!fields.name) throw new AppError('Name is required', 400);
      if (!fields.email && !fields.phone) throw new AppError('Needs a phone number or an email', 400);
      if (fields.email && seenEmails.has(fields.email)) { results.push({ line, name: fields.name, status: 'duplicate', message: 'Email already exists' }); continue; }
      if (fields.phone && seenPhones.has(fields.phone)) { results.push({ line, name: fields.name, status: 'duplicate', message: 'Phone already exists' }); continue; }
      if (fields.email) seenEmails.add(fields.email);
      if (fields.phone) seenPhones.add(fields.phone);

      if (!dryRun) {
        try {
          await createWithNextCode({ ...fields, gymId });
        } catch (err) {
          if (err && err.code === 11000) { results.push({ line, name: fields.name, status: 'duplicate', message: 'Already exists' }); continue; }
          throw err;
        }
        created += 1;
      }
      results.push({ line, name: fields.name, status: dryRun ? 'valid' : 'imported' });
    } catch (err) {
      const name = typeof raw.name === 'string' ? raw.name.slice(0, 120) : '';
      if (err.name === 'AppError' || err.name === 'ValidationError') {
        results.push({ line, name, status: 'error', message: err.message });
      } else {
        // An unexpected failure on one row must not abort the batch or hide what already happened.
        console.error('Member import row failed:', err);
        results.push({ line, name, status: 'error', message: 'Could not save this row. Please try it again.' });
      }
    }
  }

  const count = (st) => results.filter((r) => r.status === st).length;
  res.status(200).json({
    success: true,
    message: dryRun ? 'Import preview' : `${created} member${created === 1 ? '' : 's'} imported`,
    data: { dryRun, results, summary: { total: rows.length, valid: count('valid'), imported: created, duplicates: count('duplicate'), errors: count('error') } }
  });
});

module.exports = {
  importMembers,
  listMembers, createMember, getMember, updateMember, deleteMember, regenerateQr, renewMember, qrPayload, QR_PREFIX
};
