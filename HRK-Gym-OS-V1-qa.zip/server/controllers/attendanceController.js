const Member = require('../models/Member');
const Attendance = require('../models/Attendance');
const asyncHandler = require('../utils/asyncHandler');
const AppError = require('../utils/AppError');
const v = require('../utils/validate');
const { DUPLICATE_CHECKIN_MINUTES } = require('../config/constants');
const { todayIST, dateOfInstantIST } = require('../utils/dates');
const { getMemberStatus } = require('../services/membershipService');

const QR_PREFIX = 'hrk:';

// POST /api/attendance/check-in  { qrToken }
// Every decision is made here, server-side. The scanned text is only a lookup key.
const checkIn = asyncHandler(async (req, res) => {
  const raw = typeof req.body.qrToken === 'string' ? req.body.qrToken.trim() : '';
  const token = raw.startsWith(QR_PREFIX) ? raw.slice(QR_PREFIX.length) : raw;
  if (!token || token.length > 100) throw new AppError('This is not a valid member QR code', 400);

  // Scoped to the admin's gym: a QR from another gym looks exactly like an unknown QR.
  const member = await Member.findOne({ qrToken: token, gymId: req.user.gymId });
  if (!member) throw new AppError('QR code not recognised for this gym', 404);

  const who = { _id: member._id, name: member.name, memberCode: member.memberCode };

  if (member.status !== 'active') {
    throw new AppError(`${member.name}'s account is inactive`, 403, { result: 'denied', member: who, reason: 'inactive' });
  }

  const now = new Date();
  const derived = await getMemberStatus(req.user.gymId, member._id, todayIST(now));
  const membership = { status: derived.status, endDate: derived.coverageEnd, daysLeft: derived.daysLeft, planName: derived.currentMembership ? derived.currentMembership.planName : null };

  if (derived.status !== 'active' && derived.status !== 'expiring') {
    const reason = derived.status;
    const text = {
      expired: `${member.name}'s membership expired on ${derived.lastEndDate}`,
      upcoming: `${member.name}'s membership starts on ${derived.nextStartDate}`,
      none: `${member.name} has no membership`
    }[reason];
    throw new AppError(text, 403, { result: 'denied', member: who, reason, membership });
  }

  // Duplicate protection. The claim below is a single atomic update: of several simultaneous scans only
  // one can move lastCheckInAt forward, so only one attendance record is ever written per window.
  const since = new Date(now.getTime() - DUPLICATE_CHECKIN_MINUTES * 60000);
  const claimed = await Member.findOneAndUpdate(
    { _id: member._id, gymId: req.user.gymId, $or: [{ lastCheckInAt: null }, { lastCheckInAt: { $lte: since } }] },
    { $set: { lastCheckInAt: now } },
    { new: false }
  );
  if (!claimed) {
    const recent = await Attendance.findOne({ gymId: req.user.gymId, memberId: member._id }).sort({ checkedInAt: -1 });
    return res.status(200).json({
      success: true,
      message: `${member.name} already checked in${recent ? ' at ' + recent.checkedInAt.toISOString() : ''}`,
      data: { result: 'duplicate', member: who, membership, attendance: recent }
    });
  }

  const bucket = Math.floor(now.getTime() / (DUPLICATE_CHECKIN_MINUTES * 60000));
  let attendance;
  try {
    attendance = await Attendance.create({
      gymId: req.user.gymId,
      memberId: member._id,
      checkedInAt: now,
      date: dateOfInstantIST(now),
      type: 'qr',
      windowKey: `${member._id}:${bucket}`,
      membershipStatus: derived.status
    });
  } catch (err) {
    if (err && err.code === 11000) {
      // A simultaneous scan of the same QR won the race and is already recorded: report it as a duplicate.
      const winner = await Attendance.findOne({ gymId: req.user.gymId, memberId: member._id }).sort({ checkedInAt: -1 });
      return res.status(200).json({
        success: true,
        message: `${member.name} already checked in${winner ? ' at ' + winner.checkedInAt.toISOString() : ''}`,
        data: { result: 'duplicate', member: who, membership, attendance: winner }
      });
    }
    // Give the claim back so the member isn't blocked for 5 minutes without an attendance record.
    await Member.updateOne({ _id: member._id }, { $set: { lastCheckInAt: claimed.lastCheckInAt || null } });
    throw err;
  }

  res.status(201).json({
    success: true,
    message: `${member.name} checked in`,
    data: { result: 'checked_in', member: who, membership, attendance }
  });
});

// GET /api/attendance?date=&from=&to=&search=&memberId=&page=&limit=
const listAttendance = asyncHandler(async (req, res) => {
  const gymId = req.user.gymId;
  const { date, from, to, memberId } = req.query;
  const search = v.searchText(req.query.search);
  const filter = { gymId };

  const day = v.date(date, 'date');
  const fromDate = v.date(from, 'from');
  const toDate = v.date(to, 'to');
  if (day) filter.date = day;
  else if (fromDate || toDate) {
    filter.date = {};
    if (fromDate) filter.date.$gte = fromDate;
    if (toDate) filter.date.$lte = toDate;
  }
  if (memberId) filter.memberId = v.objectId(memberId, 'member id');
  if (search) {
    const rx = { $regex: v.escapeRegex(search), $options: 'i' };
    const matching = await Member.find({ gymId, $or: [{ name: rx }, { memberCode: rx }, { phone: rx }] }).select('_id');
    filter.memberId = { $in: matching.map((m) => m._id) };
  }

  const page = Math.max(1, parseInt(req.query.page, 10) || 1);
  const limit = Math.min(100, Math.max(1, parseInt(req.query.limit, 10) || 25));

  const [total, rows] = await Promise.all([
    Attendance.countDocuments(filter),
    Attendance.find(filter).sort({ checkedInAt: -1 }).skip((page - 1) * limit).limit(limit).populate('memberId', 'name memberCode')
  ]);

  const attendance = rows.map((a) => {
    const json = a.toJSON();
    json.member = a.memberId && a.memberId.name ? { _id: a.memberId._id, name: a.memberId.name, memberCode: a.memberId.memberCode } : null;
    json.memberId = a.memberId ? a.memberId._id : null;
    return json;
  });

  res.status(200).json({
    success: true,
    message: 'Attendance retrieved',
    data: { attendance, pagination: { page, limit, total, pages: Math.max(1, Math.ceil(total / limit)) } }
  });
});

module.exports = { checkIn, listAttendance };
