const Gym = require('../models/Gym');
const asyncHandler = require('../utils/asyncHandler');
const AppError = require('../utils/AppError');
const v = require('../utils/validate');

// GET /api/gym
const getGym = asyncHandler(async (req, res) => {
  const gym = await Gym.findById(req.user.gymId);
  if (!gym) throw new AppError('Gym not found', 404);
  res.status(200).json({ success: true, message: 'Gym retrieved', data: { gym } });
});

// PUT /api/gym
const updateGym = asyncHandler(async (req, res) => {
  const gym = await Gym.findById(req.user.gymId);
  if (!gym) throw new AppError('Gym not found', 404);

  gym.name = v.str(req.body.name, 'Gym name', { required: true, max: 120 });
  gym.phone = v.phone(req.body.phone, 'Phone');
  gym.address = v.str(req.body.address, 'Address', { max: 300 });
  gym.city = v.str(req.body.city, 'City', { max: 80 });
  await gym.save();

  res.status(200).json({ success: true, message: 'Gym updated', data: { gym } });
});

module.exports = { getGym, updateGym };
