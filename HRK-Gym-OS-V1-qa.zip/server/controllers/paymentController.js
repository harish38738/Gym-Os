const Member = require('../models/Member');
const Membership = require('../models/Membership');
const Payment = require('../models/Payment');
const asyncHandler = require('../utils/asyncHandler');
const AppError = require('../utils/AppError');
const v = require('../utils/validate');
const { PAYMENT_METHODS } = require('../config/constants');
const { readPayment } = require('../services/paymentInput');

// GET /api/payments?search=&memberId=&method=&from=&to=&page=&limit=
const listPayments = asyncHandler(async (req, res) => {
  const gymId = req.user.gymId;
  const { memberId, method, from, to } = req.query;
  const search = v.searchText(req.query.search);
  const filter = { gymId };

  if (memberId) filter.memberId = v.objectId(memberId, 'member id');
  if (method) filter.method = v.oneOf(method, 'method', PAYMENT_METHODS);
  const fromDate = v.date(from, 'from');
  const toDate = v.date(to, 'to');
  if (fromDate || toDate) {
    filter.paidOn = {};
    if (fromDate) filter.paidOn.$gte = fromDate;
    if (toDate) filter.paidOn.$lte = toDate;
  }
  if (search) {
    const rx = { $regex: v.escapeRegex(search), $options: 'i' };
    const matching = await Member.find({ gymId, $or: [{ name: rx }, { memberCode: rx }, { phone: rx }] }).select('_id');
    // memberName snapshot also lets us find payments of members deleted since.
    filter.$or = [{ memberId: { $in: matching.map((m) => m._id) } }, { memberName: rx }];
  }

  const page = Math.max(1, parseInt(req.query.page, 10) || 1);
  const limit = Math.min(100, Math.max(1, parseInt(req.query.limit, 10) || 20));

  const [total, pageRows, amounts] = await Promise.all([
    Payment.countDocuments(filter),
    Payment.find(filter).sort({ paidOn: -1, createdAt: -1 }).skip((page - 1) * limit).limit(limit).populate('memberId', 'name memberCode'),
    Payment.find(filter).select('amount').lean()
  ]);

  const payments = pageRows.map((p) => {
    const json = p.toJSON();
    const populated = p.memberId && p.memberId.name ? p.memberId : null;
    json.member = populated
      ? { _id: populated._id, name: populated.name, memberCode: populated.memberCode }
      : { _id: null, name: p.memberName, memberCode: null, deleted: true };
    json.memberId = populated ? populated._id : null;
    return json;
  });

  res.status(200).json({
    success: true,
    message: 'Payments retrieved',
    data: {
      payments,
      totalAmount: v.round2(amounts.reduce((sum, p) => sum + p.amount, 0)),
      pagination: { page, limit, total, pages: Math.max(1, Math.ceil(total / limit)) }
    }
  });
});

// POST /api/payments — { memberId, membershipId?, amount, method, paidOn?, note? }
const recordPayment = asyncHandler(async (req, res) => {
  const gymId = req.user.gymId;
  const member = await Member.findOne({ _id: v.objectId(req.body.memberId, 'member id'), gymId });
  if (!member) throw new AppError('Member not found', 404);

  let membershipId;
  if (req.body.membershipId) {
    const membership = await Membership.findOne({ _id: v.objectId(req.body.membershipId, 'membership id'), gymId, memberId: member._id });
    if (!membership) throw new AppError('Membership not found for this member', 404);
    membershipId = membership._id;
  }

  const input = readPayment(req.body);
  let clientRequestId;
  if (req.body.clientRequestId !== undefined && req.body.clientRequestId !== null && req.body.clientRequestId !== '') {
    if (typeof req.body.clientRequestId !== 'string' || !/^[A-Za-z0-9_-]{8,64}$/.test(req.body.clientRequestId)) throw new AppError('clientRequestId must be 8-64 letters, digits, - or _', 400);
    clientRequestId = req.body.clientRequestId;
  }
  try {
    const payment = await Payment.create({ gymId, memberId: member._id, membershipId, memberName: member.name, clientRequestId, ...input });
    return res.status(201).json({ success: true, message: 'Payment recorded', data: { payment } });
  } catch (err) {
    if (!(err && err.code === 11000 && clientRequestId)) throw err;
    // The same request was already processed (retry / double tap): return the original, don't record it again.
    const original = await Payment.findOne({ gymId, requestKey: `${gymId}:${clientRequestId}` });
    if (!original) throw err;
    const same = String(original.memberId) === String(member._id) && original.amount === input.amount && original.method === input.method && original.paidOn === input.paidOn;
    if (!same) throw new AppError('This request id was already used for a different payment', 409);
    return res.status(200).json({ success: true, message: 'Payment was already recorded', data: { payment: original, replayed: true } });
  }
});

// DELETE /api/payments/:id — removes a payment entered by mistake.
const deletePayment = asyncHandler(async (req, res) => {
  const payment = await Payment.findOneAndDelete({ _id: v.objectId(req.params.id), gymId: req.user.gymId });
  if (!payment) throw new AppError('Payment not found', 404);
  res.status(200).json({ success: true, message: 'Payment deleted', data: {} });
});

module.exports = { listPayments, recordPayment, deletePayment };
