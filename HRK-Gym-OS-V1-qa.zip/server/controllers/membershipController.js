const Member = require('../models/Member');
const MembershipPlan = require('../models/MembershipPlan');
const asyncHandler = require('../utils/asyncHandler');
const AppError = require('../utils/AppError');
const v = require('../utils/validate');
const { readPayment } = require('../services/paymentInput');
const { createMembership } = require('../services/membershipService');

// POST /api/memberships — assign a plan to a member (optionally recording the payment in the same step).
const assignMembership = asyncHandler(async (req, res) => {
  const gymId = req.user.gymId;
  const member = await Member.findOne({ _id: v.objectId(req.body.memberId, 'member id'), gymId });
  if (!member) throw new AppError('Member not found', 404);
  const plan = await MembershipPlan.findOne({ _id: v.objectId(req.body.planId, 'plan id'), gymId });
  if (!plan) throw new AppError('Plan not found', 404);
  if (!plan.isActive) throw new AppError('This plan is inactive. Activate it or choose another plan.', 400);

  const startDate = v.date(req.body.startDate, 'Start date');
  const payment = readPayment(req.body.payment);
  const result = await createMembership({ gymId, member, plan, startDate, payment });

  res.status(201).json({ success: true, message: 'Membership assigned', data: result });
});

module.exports = { assignMembership };
