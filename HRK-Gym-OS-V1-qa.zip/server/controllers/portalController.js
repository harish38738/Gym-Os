const Gym = require('../models/Gym');
const Member = require('../models/Member');
const Membership = require('../models/Membership');
const Payment = require('../models/Payment');
const Attendance = require('../models/Attendance');
const asyncHandler = require('../utils/asyncHandler');
const AppError = require('../utils/AppError');
const { todayIST } = require('../utils/dates');
const { deriveStatus } = require('../services/membershipService');

const QR_PREFIX = 'hrk:';

// The member is always taken from the logged-in user, never from a request parameter,
// so a member can only ever read their own records.
const loadOwnMember = async (req) => {
  const member = await Member.findOne({ _id: req.user.memberId, gymId: req.user.gymId });
  if (!member) throw new AppError('Your member record was not found. Please contact your gym.', 404);
  return member;
};

// GET /api/me — membership status, QR payload, membership history
const getOverview = asyncHandler(async (req, res) => {
  const member = await loadOwnMember(req);
  const today = todayIST();
  const [gym, memberships] = await Promise.all([
    Gym.findById(req.user.gymId),
    Membership.find({ gymId: req.user.gymId, memberId: member._id }).sort({ startDate: -1 })
  ]);
  const derived = deriveStatus(memberships.map((m) => m.toObject()), today);

  res.status(200).json({
    success: true,
    message: 'Overview retrieved',
    data: {
      member: member.toJSON(),
      gym: gym ? { name: gym.name, phone: gym.phone, address: gym.address, city: gym.city } : null,
      qrPayload: `${QR_PREFIX}${member.qrToken}`,
      membership: {
        status: derived.status,
        planName: derived.currentMembership ? derived.currentMembership.planName : null,
        coverageEnd: derived.coverageEnd,
        daysLeft: derived.daysLeft,
        lastEndDate: derived.lastEndDate,
        nextStartDate: derived.nextStartDate
      },
      memberships: memberships.map((m) => ({
        ...m.toJSON(),
        period: m.endDate < today ? 'ended' : m.startDate > today ? 'upcoming' : 'current'
      }))
    }
  });
});

const pageParams = (req) => ({
  page: Math.max(1, parseInt(req.query.page, 10) || 1),
  limit: Math.min(100, Math.max(1, parseInt(req.query.limit, 10) || 25))
});

// GET /api/me/attendance
const getMyAttendance = asyncHandler(async (req, res) => {
  const member = await loadOwnMember(req);
  const { page, limit } = pageParams(req);
  const filter = { gymId: req.user.gymId, memberId: member._id };
  const [total, attendance] = await Promise.all([
    Attendance.countDocuments(filter),
    Attendance.find(filter).sort({ checkedInAt: -1 }).skip((page - 1) * limit).limit(limit)
  ]);
  res.status(200).json({ success: true, message: 'Attendance retrieved', data: { attendance, pagination: { page, limit, total, pages: Math.max(1, Math.ceil(total / limit)) } } });
});

// GET /api/me/payments
const getMyPayments = asyncHandler(async (req, res) => {
  const member = await loadOwnMember(req);
  const { page, limit } = pageParams(req);
  const filter = { gymId: req.user.gymId, memberId: member._id };
  const [total, payments] = await Promise.all([
    Payment.countDocuments(filter),
    Payment.find(filter).sort({ paidOn: -1, createdAt: -1 }).skip((page - 1) * limit).limit(limit)
  ]);
  res.status(200).json({ success: true, message: 'Payments retrieved', data: { payments, pagination: { page, limit, total, pages: Math.max(1, Math.ceil(total / limit)) } } });
});

module.exports = { getOverview, getMyAttendance, getMyPayments };
