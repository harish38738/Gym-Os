const User = require('../models/User');
const Gym = require('../models/Gym');
const { hashPassword, comparePassword, compareAgainstDummy } = require('../services/passwordService');
const { failureLock } = require('../utils/rateLimit');
const { LOGIN_WINDOW_MS, LOGIN_MAX_FAILURES } = require('../config/constants');
const { generateToken } = require('../services/jwtService');
const asyncHandler = require('../utils/asyncHandler');
const AppError = require('../utils/AppError');
const v = require('../utils/validate');

// Repeated wrong passwords for one email from one IP are locked out for the rest of the window.
// Keyed by ip+email so an attacker can't lock the real owner out from a different network.
const loginLock = failureLock({
  windowMs: LOGIN_WINDOW_MS,
  maxFailures: LOGIN_MAX_FAILURES,
  message: 'Too many failed login attempts. Please wait a few minutes and try again.'
});

const toPublicUser = (user) => ({
  id: user._id,
  name: user.name,
  email: user.email,
  role: user.role,
  gymId: user.gymId,
  memberId: user.memberId
});

// POST /api/auth/register — a gym owner signs up: creates the gym and its admin.
const register = asyncHandler(async (req, res) => {
  const gymName = v.str(req.body.gymName, 'Gym name', { required: true, max: 120 });
  const name = v.str(req.body.name, 'Name', { required: true });
  const email = v.email(req.body.email, 'Email', { required: true });
  const password = v.password(req.body.password);

  if (await User.findOne({ email })) {
    throw new AppError('A user with this email already exists', 409);
  }

  const gym = await Gym.create({ name: gymName });
  let user;
  try {
    user = await User.create({
      name,
      email,
      password: await hashPassword(password),
      role: 'admin',
      gymId: gym._id
    });
  } catch (err) {
    await Gym.deleteOne({ _id: gym._id }); // don't leave an owner-less gym behind
    throw err;
  }

  res.status(201).json({
    success: true,
    message: 'Gym registered successfully',
    data: { token: generateToken({ id: user._id }), user: toPublicUser(user), gym }
  });
});

// POST /api/auth/login — admins and members both log in here; the role decides the app they see.
const login = asyncHandler(async (req, res) => {
  const email = v.email(req.body.email, 'Email', { required: true });
  const password = typeof req.body.password === 'string' ? req.body.password : '';
  if (!password) throw new AppError('Email and password are required', 400);

  const lockKey = `${req.ip}|${email}`;
  loginLock.check(lockKey);

  const user = await User.findOne({ email }).select('+password');
  const ok = user ? await comparePassword(password, user.password) : await compareAgainstDummy(password);
  if (!ok) {
    loginLock.fail(lockKey);
    throw new AppError('Invalid email or password', 401);
  }
  loginLock.succeed(lockKey);

  res.status(200).json({
    success: true,
    message: 'Login successful',
    data: { token: generateToken({ id: user._id }), user: toPublicUser(user) }
  });
});

// GET /api/auth/profile
const getProfile = asyncHandler(async (req, res) => {
  const gym = await Gym.findById(req.user.gymId);
  res.status(200).json({
    success: true,
    message: 'Profile retrieved successfully',
    data: { user: toPublicUser(req.user), gym }
  });
});

module.exports = { register, login, getProfile };
