# HRK Gym OS — V1

**Simple gym management for independent gyms.** Built by HRK Groups.

One reliable place for a gym owner to manage **members, memberships, payments and attendance** — and to see at a glance what is happening in the gym today.

```
Gym → Member → Membership → Payment → QR check-in → Attendance → Expiry → Renewal
```

## What it does

**Admin (gym owner / front desk)**
- Register a gym, log in, log out (JWT).
- Members: add, view, edit, delete, search, filter (by membership status and account status). Optional CSV import with preview.
- Membership plans: define your own (name, duration in days or months, price, active/inactive).
- Assign a plan to a member; **renew** (adds a new period — history is never overwritten).
- Payments: record, list, filter, delete mistaken entries.
- QR check-in: scan a member's QR with the phone camera (or a handheld scanner / typed code). The server validates everything and records attendance; repeat scans within 5 minutes are not duplicated.
- Attendance: today's list, history, search by member/date.
- Dashboard (real data only): total members, active memberships, expiring memberships, today's check-ins, today's revenue, plus a "needs attention" area (expiring, expired, memberships with no payment recorded).
- Gym profile: name, phone, city, address.

**Member portal** (small on purpose): log in, see membership status and history, show personal QR, see own attendance and own payments.

## Stack

| Part | Tech |
|---|---|
| Frontend (`frontend/`) | Vanilla HTML/CSS/JS ES modules, Tailwind CSS (CDN), hash routing, **no build step** |
| Backend (`server/`) | Node.js (>=18), Express, MongoDB + Mongoose, JWT, bcryptjs, dotenv |

No AI, no external API keys. The two small QR libraries (drawing; scanning fallback for browsers without `BarcodeDetector`) are **vendored** in `frontend/vendor/` — no CDN needed for check-in. The page still loads Tailwind (CDN) and Google Fonts at runtime (see *Known limitations*).

## Setup

### Requirements
- Node.js 18+
- A MongoDB database (local `mongod`, Docker, or MongoDB Atlas)

### Backend
```bash
cd server
cp .env.example .env      # then edit values
npm install
npm run dev               # or: npm start
```
API runs on `http://localhost:5000` (health check: `GET /`).

### Frontend
```bash
cd frontend
npm run dev               # serves on http://localhost:5173 (uses `npx serve`)
```
Any static file server works. If the API is not on `http://localhost:5000`, edit `frontend/js/config.js`.

> Camera scanning only works over **https** (or `localhost`). Deploy the frontend on https for phones.

### Environment variables (`server/.env`)
| Variable | Required | Purpose |
|---|---|---|
| `MONGO_URI` | yes | MongoDB connection string (`mongodb://…` or Atlas `mongodb+srv://…`) |
| `JWT_SECRET` | yes | Secret for signing login tokens (long random string; in production ≥ 24 chars or the server refuses to start) |
| `CORS_ORIGIN` | **yes in production** | Allowed frontend origin(s), comma-separated, e.g. `https://gym.example.com`. Unset = any origin (development only) |
| `TRUST_PROXY` | when behind a proxy | Number of reverse proxies in front of the API (Render/Heroku/Nginx = `1`). Needed so login throttling sees the real client IP |
| `NODE_ENV` | recommended | `production` enables HSTS and the production checks above |
| `JWT_EXPIRES_IN` | no | Login lifetime (default `7d`, e.g. `12h`) |
| `PORT` | no | API port (default 5000) |

### Database requirements
MongoDB 5+ (or compatible). No manual setup: collections and indexes are created by Mongoose on first use.

## Core entities

| Model | Key fields |
|---|---|
| `Gym` | name, phone, address, city |
| `User` | name, email (unique), password hash, `role` (`admin` \| `member`), `gymId`, `memberId` |
| `Member` | `gymId`, `memberCode` (M0001…), name, email/phone, gender, dateOfBirth, joinedDate, status, `qrToken` |
| `MembershipPlan` | `gymId`, name, durationValue + durationUnit, price, isActive |
| `Membership` | `gymId`, `memberId`, plan snapshot (name, price), startDate, endDate — **one row per period** |
| `Payment` | `gymId`, `memberId`, optional `membershipId`, amount, method, paidOn, note |
| `Attendance` | `gymId`, `memberId`, checkedInAt, date, type, membershipStatus |

Every gym-owned record carries `gymId`, and every query is scoped by the logged-in user's `gymId` (see *Isolation* below).

### Membership status is derived, never stored
From the membership periods and today's date (IST):
- **active** – covered today, more than 7 days left
- **expiring** – covered today, 7 days or fewer left (0 = last day)
- **expired** – had memberships, none cover today
- **upcoming** – a future period is booked, nothing covers today
- **none** – never had a membership

Back-to-back renewals extend coverage, so renewing early clears "expiring". Periods may not overlap.

### Dates and timezone
Calendar dates (membership start/end, payment date, attendance day) are stored as plain `YYYY-MM-DD` strings in **IST (Asia/Kolkata)** and never converted through UTC, so there are no off-by-one-day bugs. End dates are inclusive: a 1-month plan starting 1 Jan ends 31 Jan. Exact moments (check-in time) are stored as real timestamps. The IST day rolls over at 18:30 UTC.

## API overview

All responses: `{ success, message, data }` (errors: `{ success: false, message }`). Send `Authorization: Bearer <token>`.

| Area | Endpoints |
|---|---|
| Auth | `POST /api/auth/register` (creates gym + admin) · `POST /api/auth/login` (admin & member) · `GET /api/auth/profile` |
| Gym | `GET /api/gym` · `PUT /api/gym` |
| Dashboard | `GET /api/dashboard` |
| Plans | `GET/POST /api/plans` · `PUT/DELETE /api/plans/:id` |
| Members | `GET/POST /api/members` · `GET/PUT/DELETE /api/members/:id` · `POST /api/members/:id/renew` · `POST /api/members/:id/regenerate-qr` · `POST /api/members/import` (`dryRun` for preview) |
| Memberships | `POST /api/memberships` (assign a plan, optionally with its payment) |
| Payments | `GET/POST /api/payments` (optional `clientRequestId`: a retried/double-sent request with the same id is recorded once) · `DELETE /api/payments/:id` |
| Attendance | `POST /api/attendance/check-in` · `GET /api/attendance` |
| Member portal | `GET /api/me` · `GET /api/me/attendance` · `GET /api/me/payments` |

Admin routes require `role: admin`; `/api/me/*` requires `role: member`.

## Authentication & security
- Passwords: bcrypt, minimum 8 characters (max 72 bytes, bcrypt's limit); never selected or returned.
- JWT: HS256 pinned on sign **and** verify, 7-day default lifetime, `Authorization: Bearer` header (no cookies → no CSRF surface). Logout clears the token in the browser; tokens are stateless, so a copied token stays valid until it expires — except that an admin resetting a member's password invalidates that member's older sessions.
- **Login throttling** (in memory, per server process): 8 failed attempts per IP+email per 15 min → 429 with `Retry-After`; 120 auth requests per IP per 15 min; 10 gym registrations per IP per hour. Unknown-email logins cost the same time as wrong-password logins (no account enumeration by timing).
- Roles: admin routes require `role: admin`; `/api/me/*` requires `role: member`. A member's identity comes from the token, never a request parameter.
- **Gym isolation:** every query includes `gymId` from the authenticated user. Cross-gym access returns 404. Covered by tests (see below).
- **QR:** `hrk:<24 random base64url chars>` (144 bits). No name, email, phone or id. Looked up *within the admin's gym*, then account status, membership status and a 5-minute duplicate window are checked server-side. Duplicate scans are prevented by a database unique index (not only application logic). An admin can replace a member's QR at any time.
- Input validated server-side (types, lengths, enum values, calendar dates within 2000–2100, money to 2 decimals); search is escaped and capped; operator objects (`{"$gt":""}`) are rejected; mass-assignment is impossible (whitelisted fields only).
- Security headers on every API response (`nosniff`, `DENY` framing, `no-store`, restrictive CSP, HSTS in production); CORS limited to `CORS_ORIGIN`; errors never leak internals or echo input.
- Payments recorded from the app carry a request id, so a retry after a flaky network or a double tap can never double-count revenue.
- Frontend escapes every dynamic string before rendering (tested with hostile names on every screen). `frontend/_headers` sets security headers on Netlify/Cloudflare Pages.

## Testing

Tests need a running MongoDB-compatible database and create/drop their own database. **They refuse to run unless the database name starts with `hrk-test`, `hrk-e2e`, `hrk-ui` or `hrk-probe`** (override: `ALLOW_TEST_DB_DROP=1`), so they can't wipe a real database by accident.

```bash
cd server
npm install
MONGO_URI=mongodb://127.0.0.1:27017/hrk-test npm test        # API + jsdom UI suites (702 checks)
```

| Suite | File | What it covers |
|---|---|---|
| API end-to-end | `tests/e2e.js` | Whole workflow: auth, gym, plans, members, assignment, renewal history, payments, QR check-in, attendance, dashboard, portal, CSV import |
| Security & correctness | `tests/security.js` | Gym A vs Gym B isolation, privilege escalation, token forgery, hostile/NoSQL payloads, headers/CORS, QR entropy/revocation/duplicate window/concurrent scans, payments + idempotency, DB-enforced duplicates, CSV import, auth throttling |
| Endpoint matrix | `tests/api-matrix.js` | Every route × {no token, bad token, wrong role, other gym's id, malformed id, missing resource, invalid/extreme bodies, duplicates}: must be the right 4xx, never 2xx/5xx |
| IST midnight | `tests/midnight.js` | Whole stack with a controllable clock moved across 23:59:59 → 00:00:01 IST, month/year/leap ends |
| Gym simulation | `tests/gym-simulation.js` | 12-member gym, 20-step workflow, hand-computed expected dashboard numbers, second gym for isolation |
| UI smoke / extra | `tests/ui-smoke.js`, `tests/ui-extra.js` | Real router/pages in **jsdom**: forms, search, modals, XSS with hostile names, scanner lifecycle against a *mocked* camera, CSV screen |
| DB outage (optional) | `tests/db-down.js` | Stops and restarts the database mid-run (needs `DB_STOP_CMD` / `DB_START_CMD`; skipped otherwise) |

**Real-browser tests** (Chromium via Puppeteer, fake camera device): see `qa-browser/README.md`. They are *not* a physical-phone test. Results and what remains unverified: **`AUDIT.md`**.

## Production notes
- Deploy the API behind https; set `NODE_ENV=production`, `CORS_ORIGIN`, `TRUST_PROXY`, a strong `JWT_SECRET`. The API creates its indexes at startup and refuses to start if that fails. `GET /health` returns 503 when the database is down.
- Login throttling is per process. If you run more than one API instance, move it to a shared store (e.g. Redis).
- Back up the database; there is no export feature in V1.
- If you ran an earlier build of V1 against a database, drop that database first: the unique member keys introduced in the audit pass would clash with old rows.

## V1 scope

**In:** everything above.

**Explicitly out of V1:** AI, WhatsApp automation, inventory, staff management, multi-branch, workout programming, nutrition, advanced analytics, native apps, wearables, complex accounting/invoicing, payment gateway, marketplace, social features, biometric/face attendance, CRM, classes/scheduling, trainer management.

## Known limitations
**Genuine V1 limitations (by design / not built):**
- No password reset or "forgot password" flow — a forgotten admin password needs a manual database fix. Admins can reset a *member's* portal password.
- No dues/balance tracking. The "payment not recorded" list only flags memberships with no payment at all; partial payments are shown per membership on the member page.
- Payment form retries are idempotent (request id), but two *separate* manual entries of the same amount are both recorded on purpose (two genuine payments are possible); mistaken payments can be deleted.
- Members are not allowed to share a phone number or email inside one gym (database-enforced). Families sharing a phone must use different numbers for now.
- Deleting a member removes their memberships, attendance and login but keeps their payments (labelled by name).
- The QR is static: a screenshot works until the admin replaces it ("Replace QR code"). Front-desk staff see the member's name on every scan.
- Gym staff share one admin login (no staff accounts, no audit log of who deleted a payment).
- Today's revenue counts payments by their *payment date*; a back-dated payment does not appear in today's revenue.
- Scale: the members list and dashboard compute status over all of a gym's members in memory. Measured ~0.7 s (list) and ~1.8 s (dashboard) at 2,000 members on the test engine — fine for typical independent gyms, not for tens of thousands of members.
- Login throttling is per process; multi-instance deployments need a shared store.
- The page loads Tailwind (Play CDN) and Google Fonts from the internet. It is not meant for production-scale traffic, and an offline front desk will lose styling. Replace with a built CSS file before scaling.
- CSV import: max 500 rows per upload; dates must be `YYYY-MM-DD`; Excel can turn phone numbers into `9.87654E+09` — such rows are rejected, not imported wrongly.
- Multi-step writes (renewal + payment) use compensating cleanup instead of transactions, so they work on a standalone MongoDB.

**Untested (not the same as broken) — see `AUDIT.md`:** real MongoDB/Atlas, physical-phone layout, physical-device camera scanning.
