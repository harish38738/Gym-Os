# HRK Gym OS — Deployment

## Repository structure
- `server/` — Express API (Node.js 18+)
- `frontend/` — static frontend (no build step; includes `vendor/` QR libraries and `_headers`)

## Database
Create a MongoDB database (e.g. MongoDB Atlas) and copy its connection string. On Atlas, allow your API host's IP and use a dedicated database user. **Do not point the test suites at it** (they drop the database; they refuse unless the name starts with `hrk-test`).

## Backend (e.g. Render)
- Language: Node · Root directory: `server`
- Build command: `npm install` · Start command: `npm start`
- Environment variables:
  - `MONGO_URI` — connection string
  - `JWT_SECRET` — random, ≥ 24 characters
  - `NODE_ENV=production`
  - `CORS_ORIGIN` — your frontend URL, e.g. `https://gym.example.com` (the server will not start in production without it)
  - `TRUST_PROXY=1` — so login throttling uses the real client IP
  - `PORT` is set by the host
- Health check path: `/health` (503 when the database is unreachable).

## Frontend (e.g. Netlify / Cloudflare Pages / any static host)
- Publish directory: `frontend`
- Edit `frontend/js/config.js` and set `apiBaseUrl` to the deployed backend URL (no trailing slash).
- Serve over **https** — phone camera scanning for check-in requires it.
- `frontend/_headers` is applied automatically on Netlify/Cloudflare Pages; on other hosts set the same headers.

## After deploying
1. Register the gym, add a plan, add a member with a portal password, assign the plan.
2. Open the member's portal on a phone, show the QR, and scan it from a second phone at `/#/checkin` over https.
3. Check the layout on the phones your staff actually use. (These last two steps have not been tested on real devices — see `AUDIT.md`.)
