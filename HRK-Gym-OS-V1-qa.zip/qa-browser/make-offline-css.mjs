// Only needed on a machine WITHOUT internet (OFFLINE_ASSETS=1): builds the app's Tailwind CSS from the same inline config
// that index.html passes to the Tailwind Play CDN, so the browser tests render the real design without the CDN.
import fs from 'node:fs'; import path from 'node:path'; import { execSync } from 'node:child_process'; import { fileURLToPath } from 'node:url';
const HERE = path.dirname(fileURLToPath(import.meta.url)); const FE = path.join(HERE, '..', 'frontend'); const OUT = path.join(HERE, '.offline');
fs.mkdirSync(OUT, { recursive: true });
const html = fs.readFileSync(path.join(FE, 'index.html'), 'utf8');
const a = html.indexOf('tailwind.config = ') + 'tailwind.config = '.length; const b = html.indexOf('</script>', a);
const cfg = html.slice(a, b).trim().replace(/;$/, '');
fs.writeFileSync(path.join(OUT, 'tw.config.cjs'), `module.exports = Object.assign(${cfg}, { content: [${JSON.stringify(path.join(FE, 'index.html'))}, ${JSON.stringify(path.join(FE, 'js/**/*.js'))}] });\n`);
fs.writeFileSync(path.join(OUT, 'in.css'), '@tailwind base;\n@tailwind components;\n@tailwind utilities;\n' + fs.readFileSync(path.join(FE, 'css/styles.css'), 'utf8'));
execSync(`npx tailwindcss -c ${path.join(OUT, 'tw.config.cjs')} -i ${path.join(OUT, 'in.css')} -o ${path.join(OUT, 'tw.css')}`, { stdio: 'inherit', cwd: HERE });
console.log('built', path.join(OUT, 'tw.css'));
