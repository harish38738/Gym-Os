import fs from 'node:fs';
import vm from 'node:vm';
// Writes a Y4M "camera" video whose frames show the given text as a QR code (white background, black modules).
export function makeY4m(text, file, { W = 640, H = 480, frames = 12, qrPx = 380 } = {}) {
  const src = fs.readFileSync(new URL('../frontend/vendor/qrcode-generator-1.4.4.js', import.meta.url), 'utf8');
  const sb = vm.createContext({ self: {}, console }); vm.runInContext(src, sb);
  const qrcode = vm.runInContext('this', sb).qrcode;
  const q = qrcode(0, 'M'); q.addData(text); q.make();
  const n = q.getModuleCount(); const quiet = 4; const cell = Math.floor(qrPx / (n + 2 * quiet));
  const total = (n + 2 * quiet) * cell; const ox = Math.floor((W - total) / 2); const oy = Math.floor((H - total) / 2);
  const Y = Buffer.alloc(W * H, 235);
  for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) if (q.isDark(r, c)) for (let y = 0; y < cell; y++) for (let x = 0; x < cell; x++) Y[(oy + (quiet + r) * cell + y) * W + ox + (quiet + c) * cell + x] = 16;
  const U = Buffer.alloc((W / 2) * (H / 2), 128); const V = Buffer.alloc((W / 2) * (H / 2), 128);
  const parts = [Buffer.from(`YUV4MPEG2 W${W} H${H} F10:1 Ip A1:1 C420jpeg\n`)];
  for (let i = 0; i < frames; i++) parts.push(Buffer.from('FRAME\n'), Y, U, V);
  fs.writeFileSync(file, Buffer.concat(parts));
  return { modules: n, cell };
}
