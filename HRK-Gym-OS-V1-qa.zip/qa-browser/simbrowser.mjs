import { createRequire } from 'node:module';
import { startStack, launch, newPage, sleep, waitText, SERVER_DIR, FRONTEND_DIR, TEST_MONGO } from './harness.mjs';
process.env.TRUST_PROXY = '1';
const stack = await startStack({ serverDir: SERVER_DIR, frontendDir: FRONTEND_DIR, mongoUri: TEST_MONGO, env: { TRUST_PROXY: '1' } });
const req = createRequire(SERVER_DIR + '/package.json');
const { simulate } = req('./tests/lib/simulate.js');
let n = 0; const call = (m, p, o) => stack.call(m, p, { ...o });
const S = await simulate(call); const E = S.expected;
console.log('simulated gym created through the API:', S.log.length, 'steps');
const inr = (x) => '₹' + x.toLocaleString('en-IN');
let pass = 0, fail = 0; const rec = (name, ok, extra = '') => { ok ? pass++ : fail++; console.log(ok ? '  ✓' : '  ✗', name, ok ? '' : extra); };
const browser = await launch();
for (const vp of [{ label: 'phone-393', width: 393, height: 851, mobile: true, dpr: 2 }, { label: 'desktop-1280', width: 1280, height: 800, mobile: false, dpr: 1 }]) {
  console.log(`\n=== ${vp.label}: UI vs expected vs API`);
  const ctx = await browser.createBrowserContext(); const page = await newPage(ctx, vp);
  await page.goto(stack.webBase + '/'); const user = (await call('POST', '/api/auth/login', { body: { email: 'owner@hrktest.gym', password: 'gympass1234' } })).data;
  await page.evaluate((t, u) => { localStorage.setItem('hrk_token', t); localStorage.setItem('hrk_user', JSON.stringify(u)); }, user.token, user.user);
  await page.goto(stack.webBase + '/#/dashboard'); await waitText(page, /Needs attention/); await sleep(500);
  const ui = await page.evaluate(() => { const o = {}; for (const a of document.querySelectorAll('#app-main a[href^="#/"]')) { const l = a.querySelector('span')?.textContent.trim(); const v = a.querySelector('.font-metric-val')?.textContent.trim(); if (l && v) o[l] = v; } return o; });
  const api = (await call('GET', '/api/dashboard', { token: user.token })).data.totals;
  const T = E.totals;
  for (const [label, key, fmt] of [['Total members', 'totalMembers', String], ['Active memberships', 'activeMemberships', String], ['Expiring soon', 'expiringMemberships', String], ["Today's check-ins", 'todayCheckIns', String], ["Today's revenue", 'todayRevenue', inr]]) {
    const exp = fmt(T[key]);
    rec(`${label}: expected ${exp} | API ${fmt(api[key])} | screen ${ui[label]}`, ui[label] === exp && fmt(api[key]) === exp, `ui=${ui[label]} api=${api[key]} exp=${exp}`);
  }
  const att = await page.evaluate(() => [...document.querySelectorAll('#app-main section')].map((s) => ({ title: s.querySelector('h2')?.textContent.trim(), names: [...s.querySelectorAll('li a > div:first-child > div:first-child')].map((e) => e.textContent.trim()) })));
  const get = (t) => (att.find((a) => a.title === t) || { names: [] }).names.sort();
  rec('screen "Expiring soon" lists exactly Bala, Indu', JSON.stringify(get('Expiring soon')) === JSON.stringify(E.attentionExpiring), JSON.stringify(att));
  rec('screen "Expired" lists exactly Esha', JSON.stringify(get('Expired')) === JSON.stringify(E.attentionExpired));
  rec('screen "Payment not recorded" lists exactly Farid', JSON.stringify(get('Payment not recorded')) === JSON.stringify(E.attentionUnpaid));
  await page.screenshot({ path: `./shots/sim-${vp.label}-dashboard.png` });

  await page.goto(stack.webBase + '/#/members'); await waitText(page, /Anita Test/); await sleep(500);
  const rows = await page.evaluate(() => [...document.querySelectorAll('#list a')].map((a) => ({ name: a.querySelector('.font-title-sm')?.textContent.trim(), chip: a.querySelector('div.shrink-0 span')?.textContent.trim(), inactiveBadge: [...a.querySelectorAll('span')].some((x) => x.textContent.trim() === 'Inactive') })));
  const label = { active: 'Active', expiring: 'Expiring', expired: 'Expired', upcoming: 'Starts soon', none: 'No membership' };
  let allOk = rows.length === 12; const bad = [];
  for (const [nm, st] of Object.entries(E.statuses)) { const row = rows.find((r) => r.name === `${nm} Test`); if (!row || row.chip !== label[st]) { allOk = false; bad.push(`${nm}: ${row && row.chip} ≠ ${label[st]}`); } }
  rec('members screen: all 12 members show the expected status chip', allOk, bad.join('; '));
  rec('members screen: only Hari carries the "Inactive" account badge', rows.filter((r) => r.inactiveBadge).map((r) => r.name).join() === 'Hari Test', JSON.stringify(rows.filter((r) => r.inactiveBadge)));
  await page.screenshot({ path: `./shots/sim-${vp.label}-members.png` });

  await page.goto(stack.webBase + `/#/members/${S.M.Bala}`); await waitText(page, /Membership history/); await sleep(500);
  const bala = await page.evaluate(() => document.body.innerText.replace(/\s+/g, ' '));
  rec('Bala detail: "Expiring", 2 days left, plan Monthly', /Expiring/.test(bala) && /2 days left/.test(bala));
  rec('Bala detail: payment history shows ₹1,000 · UPI', /₹1,000/.test(bala) && /UPI/.test(bala));
  await page.screenshot({ path: `./shots/sim-${vp.label}-bala.png` });

  await page.goto(stack.webBase + '/#/attendance'); await waitText(page, /check-ins? on today/); await sleep(300);
  const attText = await page.evaluate(() => document.body.innerText.replace(/\s+/g, ' '));
  rec('attendance screen: "6 check-ins on today", lists Anita once', /6 check-ins on today/.test(attText) && (attText.match(/Anita Test/g) || []).length === 1, attText.slice(0, 200));
  await page.goto(stack.webBase + '/#/payments'); await waitText(page, /Total of/); await sleep(300);
  const payText = await page.evaluate(() => document.body.innerText.replace(/\s+/g, ' '));
  const totalPaid = 1000 + 1000 + 2700 + 9600 + 1000 + 1000 + 1000 + 1000 + 1000 + 1000 + 1000 + 2700 + 0;
  rec('payments screen total equals the sum of all recorded payments (hand-computed)', payText.includes(inr(1000 * 8 + 2700 * 2 + 9600)), payText.slice(0, 160));
  const noisy = [...page.__log.pageErrors, ...page.__log.console, ...page.__log.failed];
  rec(`no console/page errors and no 4xx/5xx during the ${vp.label} session`, noisy.length === 0 && page.__log.http.length === 0, noisy.concat(page.__log.http).slice(0, 3).join(' | '));
  // member portal in the same browser
  await page.evaluate(() => localStorage.clear());
  await page.goto(stack.webBase + '/#/login'); await page.waitForSelector('#loginForm');
  await page.type('#email', 'lalitha@hrktest.gym'); await page.type('#password', 'lalithapass123'); await page.click('#submitBtn');
  await page.waitForFunction(() => location.hash === '#/portal'); await waitText(page, /Your check-in QR/); await sleep(600);
  const portal = await page.evaluate(() => ({ text: document.body.innerText.replace(/\s+/g, ' '), qr: !!document.querySelector('#qr svg') }));
  rec('portal (Lalitha): Active, Quarterly, QR drawn', /Active/.test(portal.text) && /Quarterly/.test(portal.text) && portal.qr, portal.text.slice(0, 200));
  await page.screenshot({ path: `./shots/sim-${vp.label}-portal.png` });
  await page.goto(stack.webBase + '/#/portal/payments'); await waitText(page, /₹2,700/); rec('portal payments: ₹2,700 only', !/₹1,000/.test(await page.evaluate(() => document.body.innerText)));
  await page.goto(stack.webBase + '/#/portal/attendance'); await waitText(page, /1 visit/); rec('portal attendance: 1 visit', true);
  await ctx.close();
}
await browser.close(); await stack.stop();
console.log(`\nREAL-CHROMIUM SIMULATED-GYM CHECK: ${pass} passed, ${fail} failed`); process.exit(fail ? 1 : 0);
