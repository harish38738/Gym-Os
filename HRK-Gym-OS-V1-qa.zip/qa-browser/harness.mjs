import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';
import chromium from '@sparticuz/chromium';
import puppeteer from 'puppeteer-core';

process.env.AWS_EXECUTION_ENV = 'AWS_Lambda_nodejs20.x';
const HERE = path.dirname(fileURLToPath(import.meta.url));
export const SERVER_DIR = process.env.SERVER_DIR || path.join(HERE, '..', 'server');
export const FRONTEND_DIR = process.env.FRONTEND_DIR || path.join(HERE, '..', 'frontend');
export const TEST_MONGO = process.env.QA_MONGO || 'mongodb://127.0.0.1:27017/hrk-test-browser';
// OFFLINE_ASSETS=1 replaces the Tailwind CDN + Google Fonts with a locally built stylesheet (for machines without internet).
const OFFLINE = process.env.OFFLINE_ASSETS === '1';
const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.woff2': 'font/woff2', '.json': 'application/json' };

fs.mkdirSync(path.join(process.cwd(), 'shots'), { recursive: true });

export async function startStack({ serverDir, mongoUri, frontendDir, apiPort = 5180, webPort = 5181, env = {} }) {
  const webBase = `http://localhost:${webPort}`;
  const apiBase = `http://localhost:${apiPort}`;
  Object.assign(process.env, { JWT_SECRET: 'qa-secret-for-browser-tests-123456789', MONGO_URI: mongoUri, CORS_ORIGIN: webBase }, env);
  const req = createRequire(path.join(serverDir, 'package.json'));
  const mongoose = req('mongoose');
  const app = req('./app');
  await mongoose.connect(mongoUri);
  await mongoose.connection.dropDatabase();
  await Promise.all(Object.values(mongoose.models).map((m) => m.createIndexes()));
  const api = http.createServer(app); await new Promise((r) => api.listen(apiPort, r));

  const rawIndex = fs.readFileSync(path.join(frontendDir, 'index.html'), 'utf8');
  const fonts = `
@font-face{font-family:'Plus Jakarta Sans';font-weight:400;src:url(/__f/pj400.woff2) format('woff2')}
@font-face{font-family:'Plus Jakarta Sans';font-weight:600;src:url(/__f/pj600.woff2) format('woff2')}
@font-face{font-family:'Plus Jakarta Sans';font-weight:700;src:url(/__f/pj700.woff2) format('woff2')}
@font-face{font-family:'Plus Jakarta Sans';font-weight:800;src:url(/__f/pj800.woff2) format('woff2')}
@font-face{font-family:'Material Symbols Outlined';font-style:normal;font-weight:100 700;src:url(/__f/ms.woff2) format('woff2')}
.material-symbols-outlined{font-family:'Material Symbols Outlined';font-weight:normal;font-style:normal;font-size:24px;line-height:1;letter-spacing:normal;text-transform:none;display:inline-block;white-space:nowrap;word-wrap:normal;direction:ltr;-webkit-font-feature-settings:'liga';font-feature-settings:'liga';-webkit-font-smoothing:antialiased}`;
  // The sandbox has no internet, so the Tailwind Play CDN + Google Fonts are replaced by the same config compiled
  // offline with the Tailwind CLI and the same two font families served from npm. Everything else is the real app.
  const index = !OFFLINE ? rawIndex : rawIndex
    .replace(/<link[^>]*fonts\.(googleapis|gstatic)\.com[^>]*>/g, '')
    .replace('<script src="https://cdn.tailwindcss.com"></script>', '<link rel="stylesheet" href="/__tw.css"><style>' + fonts + '</style><script>window.tailwind={}</script>');
  const fontFiles = {
    '/__f/pj400.woff2': '@fontsource/plus-jakarta-sans/files/plus-jakarta-sans-latin-400-normal.woff2',
    '/__f/pj600.woff2': '@fontsource/plus-jakarta-sans/files/plus-jakarta-sans-latin-600-normal.woff2',
    '/__f/pj700.woff2': '@fontsource/plus-jakarta-sans/files/plus-jakarta-sans-latin-700-normal.woff2',
    '/__f/pj800.woff2': '@fontsource/plus-jakarta-sans/files/plus-jakarta-sans-latin-800-normal.woff2',
    '/__f/ms.woff2': 'material-symbols/material-symbols-outlined.woff2'
  };
  const web = http.createServer((rq, rs) => {
    const url = rq.url.split('?')[0];
    const send = (code, type, body) => { rs.writeHead(code, { 'Content-Type': type, 'Cache-Control': 'no-store' }); rs.end(body); };
    if (url === '/' || url === '/index.html') return send(200, 'text/html', index);
    if (url === '/js/config.js') return send(200, 'text/javascript', `window.HRK_CONFIG={apiBaseUrl:'${apiBase}'};`);
    if (url === '/__tw.css') return send(200, 'text/css', fs.readFileSync(path.join(HERE, '.offline', 'tw.css')));
    if (fontFiles[url]) return send(200, 'font/woff2', fs.readFileSync(path.join(HERE, 'node_modules', fontFiles[url])));
    const file = path.normalize(path.join(frontendDir, url));
    if (!file.startsWith(frontendDir) || !fs.existsSync(file) || fs.statSync(file).isDirectory()) return send(404, 'text/plain', 'not found');
    send(200, MIME[path.extname(file)] || 'application/octet-stream', fs.readFileSync(file));
  });
  await new Promise((r) => web.listen(webPort, r));

  const call = async (method, p, { token, body } = {}) => {
    const r = await fetch(apiBase + p, { method, headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: 'Bearer ' + token } : {}) }, body: body ? JSON.stringify(body) : undefined });
    const j = await r.json().catch(() => null); return { status: r.status, data: j && j.data, body: j };
  };
  return { apiBase, webBase, call, mongoose, req, stop: async () => { api.close(); web.close(); await mongoose.connection.dropDatabase(); await mongoose.disconnect(); } };
}

export async function launch({ camera = null, extraArgs = [], noFakeUi = false } = {}) {
  const args = [...chromium.args.filter((a) => !a.startsWith('--use-gl') && a !== '--single-process'), '--no-sandbox', ...extraArgs];
  if (camera) args.push(...(noFakeUi ? [] : ['--use-fake-ui-for-media-stream']), '--use-fake-device-for-media-stream', `--use-file-for-fake-video-capture=${camera}`);
  // CHROME_PATH = a system Chrome/Chromium; otherwise the Chromium bundled in @sparticuz/chromium is used.
  if (process.env.CHROME_PATH) return puppeteer.launch({ executablePath: process.env.CHROME_PATH, headless: true, args: args.filter((a) => !a.startsWith('--headless')) });
  return puppeteer.launch({ executablePath: await chromium.executablePath(), headless: 'shell', args });
}

/** Opens a page with recording of console errors, page errors and failed/4xx-5xx requests. */
export async function newPage(browser, { width, height, mobile = false, dpr = 1, name = 'page' }) {
  const page = await browser.newPage();
  await page.setViewport({ width, height, deviceScaleFactor: dpr, isMobile: mobile, hasTouch: mobile });
  if (mobile) await page.setUserAgent('Mozilla/5.0 (Linux; Android 14; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0 Mobile Safari/537.36');
  const log = { console: [], pageErrors: [], failed: [], http: [] };
  page.on('console', (m) => { if (['error', 'warning'].includes(m.type())) log.console.push(`${m.type()}: ${m.text()}`); });
  page.on('pageerror', (e) => log.pageErrors.push(String(e.message || e)));
  page.on('requestfailed', (r) => log.failed.push(`${r.method()} ${r.url()} ${r.failure() && r.failure().errorText}`));
  page.on('response', (r) => { if (r.status() >= 400) log.http.push(`${r.status()} ${r.request().method()} ${r.url()}`); });
  page.__log = log; page.__name = name;
  return page;
}
export const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
export async function waitText(page, rx, ms = 8000) {
  await page.waitForFunction((src) => new RegExp(src).test(document.body.innerText), { timeout: ms }, rx.source);
}
