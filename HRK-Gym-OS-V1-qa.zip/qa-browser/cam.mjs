// Real Chromium getUserMedia pipeline fed by a FAKE camera device that plays a QR video.
// This is NOT a physical Android/iPhone camera test.
import fs from 'node:fs';
import { startStack, launch, newPage, sleep, waitText, SERVER_DIR, FRONTEND_DIR, TEST_MONGO } from './harness.mjs';
import { makeY4m } from './y4m.mjs';

const stack = await startStack({ serverDir: SERVER_DIR, frontendDir: FRONTEND_DIR, mongoUri: TEST_MONGO });
const { call } = stack; const results = [];
const rec = (n, ok, extra = '') => { results.push(ok); console.log(ok ? '  ✓' : '  ✗', n, extra); };
const reg = async (g, e) => (await call('POST', '/api/auth/register', { body: { gymName: g, name: 'Owner', email: e, password: 'secret1234' } })).data;
const A = await reg('Cam Gym A', 'a@cam.test'); const B = await reg('Cam Gym B', 'b@cam.test');
const mk = async (tok, name, phone) => (await call('POST', '/api/members', { token: tok, body: { name, phone } })).data.member._id;
const plan = async (tok) => (await call('POST', '/api/plans', { token: tok, body: { name: 'Monthly', durationValue: 1, durationUnit: 'months', price: 1000 } })).data.plan._id;
const pA = await plan(A.token); const pB = await plan(B.token);
const active = await mk(A.token, 'Active Anita', '9000000001'); await call('POST', '/api/memberships', { token: A.token, body: { memberId: active, planId: pA } });
const expired = await mk(A.token, 'Expired Ezhil', '9000000002'); await call('POST', '/api/memberships', { token: A.token, body: { memberId: expired, planId: pA, startDate: '2026-01-01' } });
const other = await mk(B.token, 'GymB Bala', '9000000003'); await call('POST', '/api/memberships', { token: B.token, body: { memberId: other, planId: pB } });
const qr = async (tok, id) => (await call('GET', `/api/members/${id}`, { token: tok })).data.qrPayload;
const files = { active: './shots/cam-active.y4m', expired: './shots/cam-expired.y4m', gymB: './shots/cam-gymb.y4m', bogus: './shots/cam-bogus.y4m' };
makeY4m(await qr(A.token, active), files.active); makeY4m(await qr(A.token, expired), files.expired); makeY4m(await qr(B.token, other), files.gymB); makeY4m('hrk:ThisTokenDoesNotExist12345', files.bogus);
const attCount = async (tok, memberId) => (await call('GET', `/api/attendance?memberId=${memberId}`, { token: tok })).data.attendance.length;

const openCheckin = async (browser, label) => {
  const page = await newPage(browser, { width: 393, height: 851, mobile: true, dpr: 2, name: label });
  await page.evaluateOnNewDocument(() => {
    window.__streams = []; window.__gum = 0; window.__gumErr = [];
    const md = navigator.mediaDevices; if (!md) return; const orig = md.getUserMedia.bind(md);
    md.getUserMedia = async (c) => { window.__gum++; try { const s = await orig(c); window.__streams.push(s); return s; } catch (e) { window.__gumErr.push(e.name); throw e; } };
  });
  await page.goto(stack.webBase + '/'); await page.evaluate((t, u) => { localStorage.setItem('hrk_token', t); localStorage.setItem('hrk_user', JSON.stringify(u)); }, A.token, A.user);
  await page.goto(stack.webBase + '/#/checkin'); await page.waitForSelector('#camToggle');
  return page;
};
const live = (page) => page.evaluate(() => window.__streams.flatMap((s) => s.getTracks()).filter((t) => t.readyState === 'live').length);
const checkinRequests = (page) => { const reqs = []; page.on('request', (r) => { if (r.url().includes('/attendance/check-in')) reqs.push(r.url()); }); return reqs; };

// ---------- 1. valid member, full lifecycle ----------
console.log('\n[1] valid member QR through the real camera pipeline');
let browser = await launch({ camera: files.active });
let page = await openCheckin(browser, 'valid');
console.log('   BarcodeDetector in this Chromium:', await page.evaluate(() => 'BarcodeDetector' in window), '| secure context:', await page.evaluate(() => isSecureContext));
rec('camera is off until Start is tapped (no getUserMedia call on load)', (await page.evaluate(() => window.__gum)) === 0);
const reqs = checkinRequests(page);
await page.click('#camToggle');
await page.waitForFunction(() => /Checked in|Already checked in|Not allowed|not recognised/i.test(document.querySelector('#result').textContent), { timeout: 15000 });
const resultText = await page.$eval('#result', (e) => e.textContent.replace(/\s+/g, ' '));
rec('real camera frame decoded → "Checked in" with the right member', /Checked in/.test(resultText) && /Active Anita/.test(resultText), resultText);
rec('real <video> is playing with live frames', await page.evaluate(() => { const v = document.querySelector('#video'); return !v.classList.contains('hidden') && v.videoWidth > 0 && !v.paused; }));
rec('camera hardware stream is live while scanning (1 live track)', (await live(page)) === 1);
await sleep(8000);
rec(`the same QR kept in view for 8+ s is sent to the server ONCE (requests: ${reqs.length}) and the card stays "Checked in"`, reqs.length === 1 && /Checked in/.test(await page.$eval('#result', (e) => e.textContent)) && !/Already/.test(await page.$eval('#result', (e) => e.textContent)), reqs.length);
rec('attendance in the database: exactly 1 record', (await attCount(A.token, active)) === 1);
await page.screenshot({ path: './shots/cam-valid-result.png' });
for (const [w, h] of [[393, 851], [375, 667], [320, 568]]) {
  await page.setViewport({ width: w, height: h, deviceScaleFactor: 2, isMobile: true, hasTouch: true }); await sleep(300);
  await page.evaluate(() => window.scrollTo(0, 0)); await sleep(200);
  const vis = await page.evaluate(() => { const r = document.querySelector('#result').getBoundingClientRect(); const n = document.querySelector('#app-bottomnav nav').getBoundingClientRect(); return { top: Math.round(r.top), bottom: Math.round(r.bottom), navTop: Math.round(n.top), vh: innerHeight }; });
  rec(`REGRESSION: scan result is visible on screen WITHOUT scrolling at ${w}x${h} (result ${vis.top}-${vis.bottom}, bottom bar starts ${vis.navTop})`, vis.top >= 0 && vis.top < vis.navTop - 40 && (h >= 667 ? vis.bottom <= vis.navTop + 4 : true), JSON.stringify(vis));
}
await page.setViewport({ width: 393, height: 851, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
await page.click('#camToggle'); await sleep(300);
rec('tapping "Stop camera" releases the camera (0 live tracks)', (await live(page)) === 0 && /Start camera/.test(await page.$eval('#camToggle', (e) => e.textContent)));
await page.click('#camToggle'); await sleep(1500);
await page.goto(stack.webBase + '/#/members'); await sleep(500);
rec('navigating away while the camera runs releases it (0 live tracks)', (await live(page)) === 0, await live(page));
await page.goto(stack.webBase + '/#/checkin'); await page.waitForSelector('#camToggle'); await page.click('#camToggle');
await page.waitForFunction(() => /Already checked in/.test(document.querySelector('#result').textContent), { timeout: 15000 });
rec('returning and scanning again within 5 min → "Already checked in" (no second record)', (await attCount(A.token, active)) === 1);
await page.goto(stack.webBase + '/#/members'); await sleep(400);
rec('left again: camera released (0 live tracks)', (await live(page)) === 0);
// rapid triple tap
await page.goto(stack.webBase + '/#/checkin'); await page.waitForSelector('#camToggle'); await page.evaluate(() => { window.__streams = []; window.__gum = 0; });
await page.evaluate(() => { const b = document.querySelector('#camToggle'); b.click(); b.click(); b.click(); }); await sleep(2500);
rec(`rapid triple-tap on Start opens ONE camera stream (getUserMedia calls: ${await page.evaluate(() => window.__gum)})`, (await page.evaluate(() => window.__gum)) === 1 && (await live(page)) === 1);
const noisy = [...page.__log.pageErrors, ...page.__log.console]; 
rec(`no console/page errors during the camera session (${noisy.length})`, noisy.length === 0, noisy.slice(0, 2).join(' | '));
await browser.close();

// ---------- 2. expired / wrong gym / unknown QR ----------
for (const [key, rx, label] of [['expired', /Not allowed[\s\S]*expired/i, 'expired member QR → "Not allowed … expired", no attendance'], ['gymB', /QR not recognised/i, "another gym's member QR → \"QR not recognised\" (no member info), no attendance"], ['bogus', /QR not recognised/i, 'unknown QR → "QR not recognised"']]) {
  console.log(`\n[2:${key}]`);
  browser = await launch({ camera: files[key] }); page = await openCheckin(browser, key);
  await page.click('#camToggle');
  await page.waitForFunction(() => /Not allowed|not recognised|Checked in/i.test(document.querySelector('#result').textContent), { timeout: 15000 });
  const t = await page.$eval('#result', (e) => e.textContent.replace(/\s+/g, ' '));
  rec(label, rx.test(t), t);
  if (key === 'expired') rec('…and no attendance row was created for the expired member', (await attCount(A.token, expired)) === 0);
  if (key === 'gymB') { rec("…the other gym's member name is not revealed", !/Bala/.test(t)); rec('…and gym B has no attendance record', (await attCount(B.token, other)) === 0); }
  await page.screenshot({ path: `./shots/cam-${key}.png` });
  await browser.close();
}

// ---------- 3. camera that cannot be opened (headless Chromium has no permission prompt) ----------
// NOTE: headless Chromium cannot show/deny/grant a camera permission prompt (it returns NotSupportedError), so a REAL
// NotAllowedError → "permission denied" → re-allow cycle could NOT be exercised here. The NotAllowedError message path
// is covered only by the jsdom mock. This section only proves that when getUserMedia fails, the page stays usable.
console.log('\n[3] getUserMedia failure in a real browser (permission prompt unavailable in headless Chromium)');
browser = await launch({ camera: files.active, noFakeUi: true, extraArgs: ['--deny-permission-prompts'] });
page = await openCheckin(browser, 'perm');
await page.click('#camToggle'); await sleep(2500);
const msg = await page.$eval('#camMsg', (e) => e.textContent); const errs = await page.evaluate(() => window.__gumErr);
rec(`browser refuses the camera (${errs.join(',')}) → understandable message, no crash`, errs.length === 1 && /Could not open the camera|permission/i.test(msg) && /handheld scanner/.test(msg), msg);
rec('…camera stays off, Start button is usable again, manual/handheld-scanner input available', (await live(page)) === 0 && !(await page.$eval('#camToggle', (e) => e.disabled)) && !!(await page.$('#manualForm')));
const mcode = await qr(A.token, active);
await page.type('#manualCode', mcode); await page.keyboard.press('Enter');
await page.waitForFunction(() => /Checked in|Already checked in/.test(document.querySelector('#result').textContent), { timeout: 8000 });
rec('…and check-in still works through the handheld-scanner/typed-code input', true);
await browser.close();

await stack.stop();
const bad = results.filter((x) => !x).length;
console.log(`\nREAL-CHROMIUM FAKE-CAMERA TEST: ${results.length - bad} passed, ${bad} failed`);
process.exit(bad ? 1 : 0);
