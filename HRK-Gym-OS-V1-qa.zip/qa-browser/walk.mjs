// Real-browser (headless Chromium 153) walkthrough through the REAL UI at phone/desktop sizes.
import fs from 'node:fs';
import { startStack, launch, newPage, sleep, waitText, SERVER_DIR, FRONTEND_DIR, TEST_MONGO } from './harness.mjs';
const stack = await startStack({ serverDir: SERVER_DIR, frontendDir: FRONTEND_DIR, mongoUri: TEST_MONGO });
const { call } = stack;
const results = []; const rec = (name, ok, extra = '') => { results.push({ name, ok }); console.log(ok ? '  ✓' : '  ✗', name, extra); };
fs.mkdirSync('./shots', { recursive: true });

// fixtures through the API (so the screens have realistic data), registered via the UI below for the admin
const VIEWPORTS = [
  { label: 'android-393', width: 393, height: 851, mobile: true, dpr: 2.75 },
  { label: 'iphone-se-375', width: 375, height: 667, mobile: true, dpr: 2 },
  { label: 'narrow-320', width: 320, height: 568, mobile: true, dpr: 2 },
  { label: 'desktop-1280', width: 1280, height: 800, mobile: false, dpr: 1 }
];
const ONLY = process.env.ONLY; const RUN = ONLY ? VIEWPORTS.filter((v) => v.label === ONLY) : VIEWPORTS;
const browser = await launch();

// ---------- measure helpers executed in the page ----------
const audit = (page) => page.evaluate(() => {
  const vw = document.documentElement.clientWidth;
  const out = { overflowX: document.documentElement.scrollWidth - vw, wideEls: [], smallTargets: [], clippedText: [] };
  for (const el of document.querySelectorAll('#app-main *, #app-header *, #app-bottomnav *')) {
    const r = el.getBoundingClientRect();
    if (r.width === 0 || r.height === 0) continue;
    const cs = getComputedStyle(el);
    if (cs.visibility === 'hidden' || cs.display === 'none') continue;
    if (r.right > vw + 1 && !el.closest('[class*="overflow-x"], [class*="overflow-y-auto"]')) out.wideEls.push(`${el.tagName.toLowerCase()}.${(el.className || '').toString().slice(0, 40)} right=${Math.round(r.right)}`);
  }
  for (const el of document.querySelectorAll('button, a, input, select, [role=button]')) {
    const r = el.getBoundingClientRect(); const cs = getComputedStyle(el);
    if (r.width === 0 || r.height === 0 || cs.display === 'none' || cs.visibility === 'hidden') continue;
    if (el.type === 'checkbox' || el.classList.contains('sr-only')) continue;
    if (el.tagName === 'A' && el.closest('p, li') && !el.className.toString().includes('flex')) continue; // inline text links
    if (r.height < 40 || r.width < 40) out.smallTargets.push(`${el.tagName.toLowerCase()} "${(el.innerText || el.getAttribute('aria-label') || el.id || '').trim().slice(0, 22)}" ${Math.round(r.width)}x${Math.round(r.height)}`);
  }
  for (const el of document.querySelectorAll('#app-main h1, #app-main h2, #app-main button, #app-main a, #app-main label')) {
    if (el.scrollWidth > el.clientWidth + 2 && getComputedStyle(el).overflow !== 'visible') out.clippedText.push((el.innerText || '').slice(0, 30));
  }
  return out;
});

// ---------- the run ----------
let adminToken; let memberLogin = { email: 'meena@qa.test', password: 'meenapass1' };
for (const vp of RUN) {
  console.log(`\n=== ${vp.label} (${vp.width}x${vp.height})`);
  const ctx = await browser.createBrowserContext();
  const page = await newPage(ctx, vp);
  await page.goto(stack.webBase + '/#/register', { waitUntil: 'networkidle0' });
  // Register through the real form (first viewport only creates the gym; others log in)
  const email = `owner-${vp.label}@qa.test`;
  await page.type('#gymName', `QA Gym ${vp.label}`); await page.type('#name', 'Owner'); await page.type('#email', email); await page.type('#password', 'secret1234');
  await page.tap ? await page.tap('#submitBtn') : await page.click('#submitBtn');
  await page.waitForFunction(() => location.hash === '#/dashboard', { timeout: 8000 });
  await waitText(page, /no members yet/i);
  rec(`${vp.label}: register via UI → dashboard empty state`, true);
  let a = await audit(page); const screens = {};
  const check = async (label, extraWait) => { if (extraWait) await extraWait(); await sleep(250); const m = await audit(page); screens[label] = m;
    const bad = m.overflowX > 1 || m.wideEls.length;
    rec(`${vp.label}: ${label}: no horizontal overflow`, !bad, bad ? `overflowX=${m.overflowX} ${m.wideEls.slice(0, 3).join(' | ')}` : '');
    if (m.smallTargets.length) console.log(`     small targets (<40px) on ${label}:`, m.smallTargets.slice(0, 6).join(' ; '));
    if (m.clippedText.length) console.log(`     clipped text on ${label}:`, m.clippedText.slice(0, 4).join(' ; '));
    if (vp.mobile && !/modal/.test(label)) {
      const hidden = await page.evaluate(async () => { window.scrollTo(0, document.documentElement.scrollHeight); await new Promise((r) => setTimeout(r, 200)); const nav = document.querySelector('#app-bottomnav nav'); if (!nav || nav.offsetParent === null) return []; const n = nav.getBoundingClientRect(); const bad = [];
        for (const el of document.querySelectorAll('#app-main button, #app-main a, #app-main input, #app-main select')) { const r = el.getBoundingClientRect(); if (!r.width || !r.height || getComputedStyle(el).visibility === 'hidden') continue; if (r.bottom > n.top + 2 && r.top < innerHeight && r.bottom <= document.documentElement.scrollHeight) bad.push((el.innerText || el.id || el.tagName).trim().slice(0, 20)); } window.scrollTo(0, 0); return bad; });
      rec(`${vp.label}: ${label}: nothing is stuck behind the bottom bar at the end of the page`, hidden.length === 0, hidden.slice(0, 3).join(','));
    }
    await page.screenshot({ path: `./shots/${vp.label}-${label.replace(/\W+/g, '_')}.png` }); };
  await check('dashboard-empty');

  // token for API fixtures
  const tok = await page.evaluate(() => localStorage.getItem('hrk_token'));
  // plan via UI
  await page.goto(stack.webBase + '/#/plans'); await waitText(page, /No membership plans yet/);
  await page.click('#addPlan'); await page.waitForSelector('#planForm');
  await page.click('[data-preset="0"]'); await page.type('#price', '1200');
  await check('plan-modal'); 
  await page.click('#planSubmit'); await waitText(page, /Monthly/); await sleep(200);
  await check('plans');
  const plans = (await call('GET', '/api/plans', { token: tok })).data.plans; const planId = plans[0]._id;

  // member via UI form
  await page.goto(stack.webBase + '/#/members/new'); await page.waitForSelector('#memberForm');
  await page.type('#name', 'Meena Sundaram'); await page.type('#phone', '98765' + String(Math.floor(Math.random()*90000+10000))); await page.type('#email', `meena-${vp.label}@qa.test`); await page.type('#password', 'meenapass1');
  await check('member-form');
  await page.click('#saveBtn'); await page.waitForFunction(() => /#\/members\/[a-f0-9]{24}/.test(location.hash), { timeout: 8000 }); await waitText(page, /No membership assigned yet/);
  await sleep(400); await check('member-detail-no-plan');
  // assign + pay via UI
  await page.click('#msBtn'); await page.waitForSelector('#msForm'); await check('assign-modal');
  await page.click('#msSubmit'); await waitText(page, /Paid/); await sleep(900);
  await check('member-detail-active');
  // QR visible
  const qrOk = await page.evaluate(() => { const s = document.querySelector('#qr svg'); if (!s) return false; const r = s.getBoundingClientRect(); return r.width > 150 && r.height > 150; });
  rec(`${vp.label}: member QR is displayed at a scannable size`, qrOk);
  // renewal via UI
  // REGRESSION: immediately after a toast ("Plan assigned") the next modal's submit button must be tappable.
  await page.click('#msBtn'); await page.waitForSelector('#msForm');
  const covered = await page.evaluate(() => { const b = document.querySelector('#msSubmit'); b.scrollIntoView({ block: 'center' }); const r = b.getBoundingClientRect(); const t = document.elementFromPoint(r.x + r.width / 2, r.y + r.height / 2); return !(t === b || b.contains(t)); });
  rec(`${vp.label}: nothing (e.g. a fading toast) covers the modal's submit button`, !covered);
  await page.click('#msSubmit'); await page.waitForFunction(() => (document.body.innerText.match(/Monthly/g) || []).length >= 2 && !document.querySelector('#msForm'), { timeout: 8000 });
  await sleep(800);
  rec(`${vp.label}: renewal via UI adds a second period`, true);
  // payment modal
  await page.waitForSelector('#payBtn'); await sleep(300); await page.click('#payBtn'); await page.waitForSelector('#payForm'); await check('payment-modal'); await page.keyboard.press('Escape');
  await sleep(200);
  // other screens
  for (const [h, rx, label] of [['#/dashboard', /Needs attention/, 'dashboard'], ['#/members', /Meena/, 'members'], ['#/payments', /payments?/, 'payments'], ['#/attendance', /check-in/i, 'attendance'], ['#/checkin', /Camera is off/, 'checkin'], ['#/gym', /Gym profile/, 'gym'], ['#/more', /Log out/, 'more'], ['#/members/import', /Import members/, 'import']]) {
    await page.goto(stack.webBase + '/' + h); await waitText(page, rx); await check(label);
  }
  // keyboard: focus a field in the modal on phones and check the submit button stays reachable
  if (vp.mobile) {
    await page.goto(stack.webBase + '/#/payments'); await waitText(page, /payments?/); await page.click('#addPayment'); await sleep(300);
    const pickerOk = await page.evaluate(() => !!document.querySelector('#pickSearch')); rec(`${vp.label}: payment member-picker opens`, pickerOk);
    await page.keyboard.press('Escape');
  }
  // log out via UI, log in as the member in the same browser page
  await page.goto(stack.webBase + '/#/more'); await waitText(page, /Log out/);
  if (vp.mobile) { await page.evaluate(() => window.scrollTo(0, document.documentElement.scrollHeight)); await sleep(250); await page.click('#logout'); } else { await page.goto(stack.webBase + '/#/dashboard'); await waitText(page, /Total members/); await sleep(600); await page.click('#logoutBtn'); await sleep(300); console.log('   [desktop logout] hash=', await page.evaluate(() => location.hash), 'token=', await page.evaluate(() => !!localStorage.getItem('hrk_token'))); }
  try { await page.waitForFunction(() => location.hash === '#/login', { timeout: 6000 }); } catch (e) { console.log('   [DEBUG logout stuck] hash=', await page.evaluate(() => location.hash), '| text=', (await page.evaluate(() => document.body.innerText)).replace(/\s+/g, ' ').slice(0, 200), '| dialogs=', await page.evaluate(() => document.querySelectorAll('[role=dialog]').length)); throw e; }
  await check('login');
  await page.type('#email', `meena-${vp.label}@qa.test`); await page.type('#password', 'meenapass1'); await page.click('#submitBtn');
  await page.waitForFunction(() => location.hash === '#/portal'); await waitText(page, /Your check-in QR/); await sleep(500);
  await check('portal-home');
  rec(`${vp.label}: portal QR is displayed`, await page.evaluate(() => !!document.querySelector('#qr svg')));
  await page.goto(stack.webBase + '/#/portal/attendance'); await waitText(page, /No check-ins yet/); await check('portal-attendance');
  await page.goto(stack.webBase + '/#/portal/payments'); await waitText(page, /₹1,200/); await check('portal-payments');
  await page.goto(stack.webBase + '/#/members'); await page.waitForFunction(() => location.hash === '#/portal'); rec(`${vp.label}: member cannot open admin pages (redirected to portal)`, true);

  const log = page.__log;
  const noisy = [...log.pageErrors, ...log.console, ...log.failed];
  rec(`${vp.label}: browser console/page errors during the whole walkthrough = ${noisy.length}`, noisy.length === 0, noisy.slice(0, 3).join(' || '));
  rec(`${vp.label}: unexpected HTTP 4xx/5xx responses = ${log.http.length}`, log.http.length === 0, log.http.slice(0, 3).join(' || '));
  fs.writeFileSync(`./shots/${vp.label}-audit.json`, JSON.stringify(screens, null, 1));
  await page.close(); await ctx.close();
}
await browser.close(); await stack.stop();
const failed = results.filter((r) => !r.ok);
console.log(`\nREAL-BROWSER WALKTHROUGH: ${results.length - failed.length} passed, ${failed.length} failed`);
process.exit(failed.length ? 1 : 0);
