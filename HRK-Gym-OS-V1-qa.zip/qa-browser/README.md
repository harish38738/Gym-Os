# Real-browser tests (Chromium)

These drive the **real app** (real frontend files, real API, real database) in a real Chromium browser through Puppeteer.

| Script | What it does |
|---|---|
| `walk.mjs` | Registers a gym through the UI and walks every screen at 393×851 (Android), 375×667 (iPhone SE), 320×568 and 1280×800 desktop. Measures horizontal overflow, touch-target sizes, content hidden behind the bottom bar, console errors, failed requests |
| `cam.mjs` | QR check-in through the real `getUserMedia` pipeline. Chromium's **fake camera device** plays a video of real QR codes: valid, expired, other gym, unknown. Checks camera start/stop/leave-page cleanup, duplicate scans, result visibility |
| `simbrowser.mjs` | Builds a 12-member gym through the API and compares the dashboard, member list, attendance, payments and member portal on screen with hand-computed values |

**What this is not:** a physical Android/iPhone test. Headless Chromium does not reproduce iOS Safari, real touch/keyboard behaviour, or a real camera's autofocus/glare, and cannot show a camera-permission prompt.

## Run
```bash
cd qa-browser
npm install
# needs a MongoDB whose database name starts with "hrk-test" (the scripts DROP it)
export QA_MONGO=mongodb://127.0.0.1:27017/hrk-test-browser
npm test                       # all three
```
Options: `CHROME_PATH=/path/to/chrome` to use a system Chrome instead of the bundled Chromium; `ONLY=android-393 node walk.mjs` for one viewport; `SERVER_DIR`/`FRONTEND_DIR` to point at other copies. On a machine with no internet run `OFFLINE_ASSETS=1 npm run offline-css && OFFLINE_ASSETS=1 npm test` (replaces the Tailwind CDN and Google Fonts with a locally built stylesheet and npm-hosted fonts). Screenshots are written to `qa-browser/shots/`.
