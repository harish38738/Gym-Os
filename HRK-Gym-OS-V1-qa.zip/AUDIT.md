# HRK Gym OS V1 — QA & Release Audit

**Release decision: NOT READY** — see section 12. No known defect blocks release; the blockers are mandatory verifications that could not be performed in the audit environment (physical phones, and a modern MongoDB/Atlas run).

Legend: **PASS** = exercised by a test that ran · **FAIL** · **UNVERIFIED** = not run. Nothing is marked PASS from code reading alone.

## 1. Executive summary

The audited V1 was installed from scratch, run, and tested from three perspectives (admin, front desk, member) with automated API, security, jsdom-UI, **real-Chromium** and **real-MongoDB** tests, plus a 12-member simulated gym. The QA pass found and fixed 8 further product defects (1 × P1, 4 × P2, 3 × P3), several of which only appear in a real browser (a fading toast blocking taps, one long email widening the whole page on phones, the scan result sitting below the fold). Every automated check now passes on both database engines.

What is **not** proven: the app on a physical Android phone or iPhone (incl. iOS Safari), a physical camera scanning a QR on a phone screen, the camera-permission prompt (headless Chromium cannot show one), Firefox/Edge/Safari, and Mongoose 8 against a modern MongoDB (the real server available here was 3.6.8).

## 2. Environment

| Item | Value |
|---|---|
| Install | clean copy, `npm ci` (server), `npm install` (browser tests); no AI key; env = `MONGO_URI` + `JWT_SECRET` only |
| Node | 22 |
| Engine A | FerretDB 1.24 (SQLite backend) + **Mongoose 8** (the version the project ships with) — **not equivalent to MongoDB** |
| Engine B | **real `mongod` 3.6.8** (Ubuntu package, ~2018) + **Mongoose 7.8.7** (newest driver that can talk to a 3.6 server; Mongoose 8 requires MongoDB ≥ 4.2) |
| Browser | headless **Chromium 153** (bundled via `@sparticuz/chromium`), Puppeteer; mobile emulation (touch, DPR 2–2.75), fake camera device |
| Sandbox limit | no internet: Tailwind CDN + Google Fonts replaced by the *same* Tailwind config compiled locally + the same two fonts from npm. Everything else is the shipped app |
| Test databases | all named `hrk-test…`; the suites refuse any other name |

## 3. Tests — results

| Suite | FerretDB + Mongoose 8 | **Real mongod 3.6.8 + Mongoose 7** |
|---|---|---|
| API end-to-end (`e2e`) | 132 / 132 | 132 / 132 |
| Security & correctness (`security`) | 191 / 191 | 191 / 191 |
| Endpoint matrix (`api-matrix`) | 206 / 206 | 206 / 206 |
| IST midnight (`midnight`) | 28 / 28 | 28 / 28 |
| Gym simulation (`gym-simulation`) | 60 / 60 | 60 / 60 |
| **API total** | **617 / 617** | **617 / 617** |
| UI smoke + extra (jsdom) | 85 / 85 | 85 / 85 |
| DB outage (`db-down`: real server killed + restarted) | n/a | 18 / 18 |
| Real-Chromium walkthrough (4 viewports) | 166 / 166 | — |
| Real-Chromium fake-camera QR test | — | 24 / 24 (also run on FerretDB) |
| Real-Chromium simulated-gym UI check | 36 / 36 | 36 / 36 |

Also: API suites re-run with the server clock in `America/Los_Angeles` and `Pacific/Kiritimati` — all pass. Security suite stress-run in parallel earlier in the audit (9/9). Lint (ad-hoc ESLint 9, no linter is configured in the repo): 0 errors, 13 warnings (unused catch variables). `npm audit --omit=dev`: 0 vulnerabilities (dev-only `nodemon` chain has 3 advisories). Build: N/A — the project has no build step.

## 4. API results

- Every endpoint was exercised with: no token, bad token, wrong role, another gym's id, malformed id, nonexistent id, invalid/extreme bodies, malformed JSON, duplicates. All gave the expected 4xx (never 2xx, never 5xx). Table printed by `node tests/api-matrix.js`.
- Authentication: registration (valid, bad email, weak password, missing fields, duplicate email, array/overlong fields), login (wrong password, unknown account, missing/operator-object/array credentials), repeated failures → 429 + `Retry-After`; unknown-email logins cost the same time as wrong-password logins.
- **Logout:** clears the token in the browser (verified). Tokens are stateless 7-day JWTs, so a copied token stays valid until it expires — documented limitation (P3). An admin resetting a member's password ends that member's older sessions (tested).
- Duplicate gym names are allowed (a gym name is not an identifier); duplicate plan names are allowed; zero-price plans are allowed (free trials); inactive plans cannot be assigned (400).

## 5. Security results

Gym isolation: 24 explicit cross-gym attacks (read/edit/delete/renew/regenerate-QR/assign/pay/scan/search/import/dashboard/portal) all refused (404/403); Gym A's data was byte-identical afterwards. The 20-step simulation repeats the isolation check with a second gym.
Also tested: privilege escalation via body fields, forged/expired/`alg:none`/wrong-algorithm tokens, 30 hostile payloads (NoSQL operators, prototype pollution, regex bombs, 5,000-char search, oversize bodies) → none caused a 500 or stored corrupted data, XSS with `<img onerror>`/`<script>`/`<svg onload>` as gym, user, member, plan and payment-note text on every screen (rendered inert), CORS allow-list, security headers (`nosniff`, `DENY`, `no-store`, CSP, HSTS in production), no raw stack traces or driver text in any error (including during a real database outage).
Secrets scan: no JWT secret, DB URI with credentials, API key, Gemini/AI key or password in the frontend or anywhere in the repo (only the placeholder in `.env.example`). The browser stores only the login token, user name/role and gym name.

| Severity | Finding | Status |
|---|---|---|
| Critical | none found | — |
| High | (earlier audit) brute-force throttling, concurrent check-in duplication, test suite able to wipe a real DB | fixed |
| Medium | Tailwind Play CDN + Google Fonts run in the app's origin while the token is in `localStorage`; no CSP possible with the no-build setup | **open** (replace CDN with built CSS before scaling) |
| Medium | no password reset (forgotten admin password = manual DB fix) | **open** (documented) |
| Low | static QR (screenshot works until the admin replaces it); cross-gym "email already used" hint; in-memory throttling (per process); 8-char passwords, no breached-password check | open / documented |
| Info | stateless 7-day tokens; one shared admin login per gym, no audit log | documented |

## 6. Database results

On the **real mongod 3.6.8** (Mongoose 7): connection, all models, unique indexes enforced by the database (member email/phone keys, QR token, attendance window key, payment request key, membership member+start), duplicate-key races (6 simultaneous creates → 1 created), 12 simultaneous scans → 1 attendance row, concurrent renewals, deletion behaviour (member delete removes memberships/attendance/login, keeps payments), timestamps, persistence across a database stop/start (18/18). Same results on FerretDB.
**Unverified:** Mongoose 8 / driver 6 against MongoDB ≥ 4.2 and MongoDB Atlas (TLS, SRV connection string, IP allow-list). The code uses only basic operators and plain unique indexes (see the code audit in the previous report: no aggregation, transactions, partial/sparse/text indexes), but it has not been run against Atlas.

## 7. Mobile results

**Real Chromium with phone emulation — not a physical device.** Screens: register, login, dashboard (empty and with data), members, member form, member detail, plans (+modal), payments (+modal, +member picker), attendance, check-in, gym profile, more, CSV import, member portal (home/attendance/payments). Viewports 393×851 (Android), 375×667 (iPhone SE), 320×568, desktop 1280×800.

| Check | Result |
|---|---|
| No horizontal overflow, every screen, every viewport | PASS (after fix) |
| Nothing interactive hidden behind the bottom bar at the end of a page | PASS |
| Interactive elements < 40 px tall on phone screens | none remaining (desktop nav links are 28 px — mouse UI) |
| Modals usable, submit button not covered by a toast | PASS (after fix) |
| Console errors / failed requests / 4xx-5xx during full walkthroughs | 0 / 0 / 0 |
| Member cannot open admin pages | PASS |

Known cosmetic (P3): on a 320×568 screen the scan-result card is partly under the bottom bar (its title is visible); "Today's check-ins" wraps to two lines in a 2-column card.
**UNVERIFIED:** physical Android phone, physical iPhone, iOS Safari rendering and its on-screen-keyboard behaviour, Firefox, Edge.

## 8. QR / camera results

**Real Chromium `getUserMedia` pipeline with a FAKE camera device playing real QR video — not a physical camera.** (headless Chromium reported no `BarcodeDetector`, so the vendored jsQR fallback decoded the frames — the same path an iPhone uses.)

PASS: camera off until Start is tapped · valid QR decoded → "Checked in" with the right member · held in view 8+ s → exactly one request, card stays "Checked in" · Stop releases the camera · leaving the page releases it · returning and scanning again → "Already checked in", still one attendance row · rapid triple-tap on Start opens one stream · expired member → "Not allowed … expired", no attendance · other gym's QR → "QR not recognised", name not revealed · unknown QR → "QR not recognised" · result visible without scrolling at 393×851 / 375×667 / 320×568 · no console errors · handheld-scanner/typed-code entry works when the camera cannot open.

**REAL DEVICE CAMERA TEST: UNVERIFIED.** Also unverified in any real browser: the genuine camera-permission prompt, **deny → re-enable** (headless Chromium returns `NotSupportedError`; the `NotAllowedError` message path is covered only by a jsdom mock), camera behaviour on Android Chrome and iPhone Safari, scanning a QR displayed on another phone's screen (glare, autofocus, brightness).

## 9. Performance results (real mongod 3.6.8, median of 5 runs; number of database queries per request in brackets)

| Members | list p.1 | search | filter "expiring" | dashboard | payments p.1 | attendance today | attendance p.1 |
|---|---|---|---|---|---|---|---|
| 100 | 70 ms (3) | 12 (3) | 16 (3) | 14 (7) | 16 (5) | 12 (4) | 13 (4) |
| 500 | 41 | 13 | 35 | 25 | 13 | 8 | 12 |
| 1,000 | 65 | 20 | 72 | 42 | 19 | 9 | 18 |
| 2,000 | 159 | 37 | 161 | 77 | 27 | 11 | 27 |

Query counts are constant (3/3/3/7/5/4/4) at every size — **no N+1**. The member list and dashboard load all of a gym's members and memberships to derive status, so they grow linearly (159 ms / 77 ms at 2,000 members). No optimisation was made: it is not a problem at gym scale. (On the FerretDB test engine the same requests took 0.7–1.9 s at 2,000 members — an engine property, not the app.)

## 10. Bugs found in this QA pass

| # | Sev | Bug | Fix | Regression test |
|---|---|---|---|---|
| 1 | **P1** | A retried or double-sent payment request was recorded twice (revenue overstated). Previously accepted as a limitation | Payment form sends a request id; unique key per gym+id; replay returns the original; same id with different data → 409 | `security.js` §9 (5 simultaneous submits → 1 payment) |
| 2 | P2 | A fading toast sat over the next modal's submit button (pointer events): "Renew" right after "Assign" could not be tapped for ~3 s. Real-browser only | toast is `pointer-events-none` | `walk.mjs`: nothing covers the modal's submit button |
| 3 | P2 | One long email or name made the whole page scroll sideways on a phone (grid items with no `min-width:0`). Real-browser only | `min-w-0` on cards and detail columns | `walk.mjs` overflow check on every screen (repro with a 70-char email) |
| 4 | P2 | After a scan, the "Checked in / Not allowed" result was below the fold under the camera: the person at the desk had to scroll to see it | result moved directly under the camera; camera box shorter on short phones | `cam.mjs`: result visible without scrolling at 3 phone sizes |
| 5 | P2 | `payment: "x"` (malformed) on assign/renew was silently dropped → membership created with no payment and a 201 | malformed payment → 400 | `api-matrix.js` |
| 6 | P3 | Result card flipped from "Checked in" to "Already checked in" 4 s later while the member still held the QR up | a code that stays in view is submitted once; resubmitted only after it left view 1.5 s | `cam.mjs` (8 s hold → 1 request, card unchanged) |
| 7 | P3 | Database outage returned a generic 500 | clear 503 "temporarily unavailable, try again"; `/health` 503 | `db-down.js` (real server killed) |
| 8 | P3 | Bottom-nav "Check-in" wrapped to two lines; search placeholder clipped; "Check in" button wrapped; several text links 19–21 px tall | nowrap/size fixes, 44 px tap areas | `walk.mjs` (touch-target and overflow audit) |
| 9 | test | Test-harness and fixture mistakes found and fixed while building the new suites (not product bugs) | — | — |

Defects fixed in the earlier hardening pass (check-in race, brute force, camera leak, stale-render race, money validation, etc.) are listed in the previous report; their tests are included in the suites above.

## 11. Remaining issues, limitations, scope

**Remaining product issues (none blocks a supervised pilot):** P3 — token stays valid after logout until expiry; P3 — 320×568 result card partly under the bottom bar; P3 — "Today's check-ins" label wraps; P2 (known) — no password reset; P2 (known) — Tailwind/Fonts CDN dependency (offline front desk loses styling; supply-chain exposure).
**Known limitations:** no dues/balance tracking; one shared admin login and no audit log; members in one gym cannot share a phone number or email; deleting a member keeps their payments (labelled by name); static QR; throttling is per process; members list / dashboard compute in memory; CSV max 500 rows with `YYYY-MM-DD` dates; back-dated payments don't count in "today's revenue".
**Scope check:** the shipped V1 contains only: admin login, gym profile, dashboard, members, plans, memberships, renewals, payments, QR check-in, attendance, CSV import; member login, status/history, QR, attendance, payments. No AI, workouts, nutrition, WhatsApp, inventory, staff, multi-branch, analytics, native apps, wearables, marketplace, social, classes or CRM. The QA pass added no features (payment idempotency, the 503 message and layout fixes are defect fixes).
Documentation checked against the code: README, DEPLOYMENT.md and this file match the routes, environment variables, scripts and test names; no Fitzy/College/Gemini references remain except the "excluded features" lines and the tests that assert their absence.

## 12. Acceptance criteria

| # | Criterion | Status |
|---|---|---|
| 1–2 | Admin login; gym isolation | PASS |
| 3–6 | Members; plans; assignment; renewal | PASS |
| 7–8 | Payments; payment history (own gym / own member only) | PASS |
| 9 | QR check-in (valid/invalid/expired/other gym/duplicate/concurrent) | PASS (API) · camera: see 20 |
| 10–11 | Attendance; dashboard equals hand-computed values (API **and** screen) | PASS |
| 12 | Membership status and IST boundaries (incl. 00:00 IST end-to-end) | PASS |
| 13 | Member portal | PASS |
| 14 | CSV import | PASS (server + preview/confirm screen; real file picker simulated) |
| 15 | Real MongoDB | **PASS on `mongod` 3.6.8 + Mongoose 7 · UNVERIFIED on Mongoose 8 / Atlas** |
| 16 | Mobile layout | PASS in real Chromium emulation · **UNVERIFIED on physical devices** |
| 17 | Desktop browsers | PASS Chromium · **UNVERIFIED Firefox / Edge / Safari** |
| 18 | Security audit | PASS (see section 5 for open items) |
| 19 | Performance | PASS (section 9) |
| 20 | Camera QR on physical devices | **UNVERIFIED** |
| 21 | Clean install / production mode / env | PASS |

## 13. Release decision

**NOT READY**

No defect is known to block release. The following mandatory verifications could not be performed here and are therefore the blockers:

**Blocker 1 — Physical-device mobile + camera test (iPhone Safari and Android Chrome)**
- *Problem:* never run on a physical phone: layout, on-screen keyboard, camera permission prompt, deny → re-enable, scanning a QR shown on another phone, iOS Safari's jsQR path.
- *Reproduction / test:* follow section 14, parts A–C.
- *Severity if it fails:* P1 (QR check-in is the only check-in route; there is no manual check-in by member search).
- *Root cause / fix:* none identified; fix depends on what fails (e.g. scan-box size, autofocus constraints, `playsinline`).
- *Blocks pilot:* **yes**.

**Blocker 2 — Run on Mongoose 8 + a modern MongoDB (Atlas scratch database)**
- *Problem:* the shipped dependency is Mongoose 8; the real server available here (3.6.8) only supports Mongoose 7. Same code, different driver and server version.
- *Reproduction / test:* `cd server && MONGO_URI="mongodb+srv://…/hrk-test-atlas" npm test` (every suite refuses a database name that doesn't start with `hrk-test`).
- *Severity if it fails:* P1.
- *Root cause / fix:* none identified (only basic operators and plain unique indexes are used).
- *Blocks pilot:* **yes**.

If both pass, the decision becomes **READY FOR REAL-GYM PILOT**, run as a supervised pilot with the known limitations above.

## 14. Physical-device checklist (about 30 minutes)

Deploy per `DEPLOYMENT.md` (https). Use Phone A (member portal) and Phone B (admin) — once with iPhone/Safari as B, once with Android/Chrome as B.
**A. Layout:** at each phone, walk register → dashboard → members → add member → plan → assign → payment → attendance → check-in → member portal. Check: no sideways scrolling, no clipped buttons, keyboard doesn't hide the Save button, buttons easy to tap.
**B. Camera:** 1) open Check-in on Phone B, tap Start camera, **Allow** → camera shows. 2) Show a member's QR on Phone A → "Checked in" with the right name within ~2 s, once. 3) Show it again → "Already checked in". 4) Show an expired member's QR → "Not allowed". 5) Tap Stop → camera light off. 6) Start, then switch to another tab/app → camera stops; come back, Start works. 7) Start, then tap Members → camera light goes off. 8) Reload, tap Start, **Block** → readable message, typed-code box still there. 9) Browser settings → allow camera → Start works again.
**C. Money/dashboard:** record a payment, double-tap the Save button → one payment; dashboard numbers match what you entered.
