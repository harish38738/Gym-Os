// Presentation-only lists. The backend is the source of truth for what is valid
// (server/config/constants.js); these just add labels and colours.

export const PAYMENT_METHODS = [
  { value: 'cash', label: 'Cash' },
  { value: 'upi', label: 'UPI' },
  { value: 'card', label: 'Card' },
  { value: 'other', label: 'Other' }
];

export const methodLabel = (v) => (PAYMENT_METHODS.find((m) => m.value === v) || { label: v }).label;

export const GENDERS = [
  { value: '', label: 'Prefer not to say' },
  { value: 'male', label: 'Male' },
  { value: 'female', label: 'Female' },
  { value: 'other', label: 'Other' }
];

// Membership status → label + chip colours.
export const STATUS_META = {
  active: { label: 'Active', cls: 'bg-primary-fixed text-on-primary-fixed' },
  expiring: { label: 'Expiring', cls: 'bg-[#ffe9b8] text-[#5c4300]' },
  expired: { label: 'Expired', cls: 'bg-error-container text-on-error-container' },
  upcoming: { label: 'Starts soon', cls: 'bg-secondary-container text-on-secondary-container' },
  none: { label: 'No membership', cls: 'bg-surface-container-high text-on-surface-variant' }
};
