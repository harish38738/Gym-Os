// Small CSV parser (RFC-4180 style): quoted fields, escaped quotes, commas and
// newlines inside quotes, CRLF/LF, BOM. Returns an array of string arrays.
export function parseCsv(text) {
  const src = String(text).replace(/^\uFEFF/, '');
  const rows = [];
  let row = [];
  let field = '';
  let inQuotes = false;

  for (let i = 0; i < src.length; i++) {
    const c = src[i];
    if (inQuotes) {
      if (c === '"') {
        if (src[i + 1] === '"') { field += '"'; i++; } else inQuotes = false;
      } else field += c;
    } else if (c === '"') inQuotes = true;
    else if (c === ',') { row.push(field); field = ''; }
    else if (c === '\n' || c === '\r') {
      if (c === '\r' && src[i + 1] === '\n') i++;
      row.push(field); field = '';
      rows.push(row); row = [];
    } else field += c;
  }
  if (field !== '' || row.length) { row.push(field); rows.push(row); }
  return rows.filter((r) => r.some((cell) => cell.trim() !== ''));
}

const HEADER_ALIASES = {
  name: ['name', 'full name', 'member name', 'member'],
  phone: ['phone', 'mobile', 'phone number', 'mobile number', 'contact'],
  email: ['email', 'email address', 'e-mail'],
  gender: ['gender', 'sex'],
  dateOfBirth: ['date of birth', 'dob', 'dateofbirth', 'birth date', 'birthdate'],
  joinedDate: ['joined', 'joined date', 'joined on', 'join date', 'joineddate', 'date joined']
};

/** CSV text → { rows: [{name, phone, ...}], missingName: boolean }. First line must be headers. */
export function csvToMemberRows(text) {
  const table = parseCsv(text);
  if (!table.length) return { rows: [], missingName: false, headers: [] };
  const headers = table[0].map((h) => h.trim().toLowerCase());
  const index = {};
  for (const [key, aliases] of Object.entries(HEADER_ALIASES)) {
    const i = headers.findIndex((h) => aliases.includes(h));
    if (i !== -1) index[key] = i;
  }
  const rows = table.slice(1).map((cells) => {
    const out = {};
    for (const [key, i] of Object.entries(index)) out[key] = (cells[i] || '').trim();
    return out;
  });
  return { rows, missingName: index.name === undefined, headers: table[0] };
}

/** Dates like 05/01/2026 are ambiguous, so only YYYY-MM-DD is accepted (the server enforces it). */
export const SAMPLE_CSV = 'name,phone,email,gender,date of birth,joined date\nArun Kumar,9876543210,arun@example.com,male,1995-04-12,2026-01-05\nMeena S,9876500002,,female,,2026-02-01\n';
