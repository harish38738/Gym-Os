// Every dynamic string (member names, notes, etc.) MUST go through
// escapeHtml before being interpolated into an innerHTML template — this is
// a vanilla-JS app with no framework escaping for us.

export function escapeHtml(value) {
  if (value === null || value === undefined) return '';
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

export function qs(selector, root = document) { return root.querySelector(selector); }
export function qsa(selector, root = document) { return Array.from(root.querySelectorAll(selector)); }

/** Runs fn at most once per `wait` ms after the last call (for search boxes). */
export function debounce(fn, wait = 300) {
  let t;
  return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), wait); };
}

/** Loads a third-party script once (used lazily for QR generate/scan libraries). */
const loaded = new Map();
export function loadScript(src) {
  if (loaded.has(src)) return loaded.get(src);
  const p = new Promise((resolve, reject) => {
    const s = document.createElement('script');
    s.src = src;
    s.onload = resolve;
    s.onerror = () => reject(new Error(`Could not load ${src}`));
    document.head.appendChild(s);
  });
  loaded.set(src, p);
  return p;
}

/** Query params from the hash, e.g. '#/members?status=expiring' → { status: 'expiring' }. */
export function hashQuery() {
  const q = window.location.hash.split('?')[1] || '';
  return Object.fromEntries(new URLSearchParams(q));
}
