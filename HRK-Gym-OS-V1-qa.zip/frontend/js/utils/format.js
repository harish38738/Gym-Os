// Dates: the API sends calendar dates as 'YYYY-MM-DD' strings in IST. They are
// parsed by hand (never `new Date('YYYY-MM-DD')`, which is UTC and can shift a
// day) so what the owner types is exactly what is shown and stored.

const TZ = 'Asia/Kolkata';
const dayFmt = new Intl.DateTimeFormat('en-CA', { timeZone: TZ, year: 'numeric', month: '2-digit', day: '2-digit' });

/** Today's date in IST, 'YYYY-MM-DD'. */
export const todayStr = () => dayFmt.format(new Date());

export function addDaysStr(str, n) {
  const [y, m, d] = str.split('-').map(Number);
  return new Date(Date.UTC(y, m - 1, d + n)).toISOString().slice(0, 10);
}

/** 'YYYY-MM-DD' → '15 Sep 2026' */
export function formatDate(str) {
  if (!str) return '—';
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(str);
  if (!m) return String(str);
  const d = new Date(Date.UTC(+m[1], +m[2] - 1, +m[3]));
  return d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric', timeZone: 'UTC' });
}

/** Exact moment (ISO string) → '15 Sep 2026, 6:05 pm' in IST. */
export function formatDateTime(instant) {
  if (!instant) return '—';
  const d = new Date(instant);
  if (Number.isNaN(d.getTime())) return '—';
  return d.toLocaleString('en-IN', { day: 'numeric', month: 'short', year: 'numeric', hour: 'numeric', minute: '2-digit', hour12: true, timeZone: TZ });
}

export function formatTime(instant) {
  if (!instant) return '—';
  const d = new Date(instant);
  if (Number.isNaN(d.getTime())) return '—';
  return d.toLocaleTimeString('en-IN', { hour: 'numeric', minute: '2-digit', hour12: true, timeZone: TZ });
}

/** 1500 → '₹1,500'; keeps paise only if present. */
export function formatINR(amount) {
  const n = Number(amount) || 0;
  return n.toLocaleString('en-IN', { style: 'currency', currency: 'INR', minimumFractionDigits: Number.isInteger(n) ? 0 : 2, maximumFractionDigits: 2 });
}

export function formatNumber(n) {
  if (n === null || n === undefined || Number.isNaN(Number(n))) return '0';
  return Number(n).toLocaleString('en-IN');
}

export function pluralDays(n) {
  return `${n} day${n === 1 ? '' : 's'}`;
}

/** Friendly fallback message when an ApiError doesn't have a useful one. */
export function friendlyErrorMessage(error, fallback = 'Something went wrong. Please try again.') {
  if (!error) return fallback;
  return error.message || fallback;
}
