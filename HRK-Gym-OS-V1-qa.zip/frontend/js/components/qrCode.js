// QR rendering (member portal + admin member page). Uses the small
// qrcode-generator library (vendored in frontend/vendor), loaded lazily. The QR content is an
// opaque token ("hrk:<random>") — no personal data is ever encoded.
import { loadScript, escapeHtml } from '../utils/dom.js';

// Served from this app (frontend/vendor), not a CDN: the QR must still draw if the gym's internet is flaky.
const SRC = 'vendor/qrcode-generator-1.4.4.js';

/** Fills `el` with an SVG QR code for `text`. */
export async function renderQr(el, text) {
  try {
    await loadScript(SRC);
    const qr = window.qrcode(0, 'M');
    qr.addData(text);
    qr.make();
    el.innerHTML = qr.createSvgTag({ cellSize: 6, margin: 2, scalable: true });
    const svg = el.querySelector('svg');
    if (svg) {
      svg.setAttribute('role', 'img');
      svg.setAttribute('aria-label', 'Member QR code');
      svg.style.width = '100%';
      svg.style.height = 'auto';
    }
  } catch (e) {
    el.innerHTML = `<p class="font-body-sm text-body-sm text-error p-4 text-center">Could not draw the QR code (${escapeHtml(e.message)}). Reload the page and try again.</p>`;
  }
}
