import { openModal } from './modal.js';
import { field, selectField, errorAlert, showFormError, clearFormError, setBusy, BTN_PRIMARY, BTN_SECONDARY } from './ui.js';
import { showToast } from './toast.js';
import { recordPayment } from '../services/paymentService.js';
import { PAYMENT_METHODS } from '../utils/constants.js';
import { formatDate, formatINR, todayStr, friendlyErrorMessage } from '../utils/format.js';

/**
 * Record a payment for a member. `memberships` (optional) lets the owner link the
 * payment to one of that member's membership periods.
 */
// One random id per opened payment form. If the request is retried (slow network, double tap) the server
// recognises the id and does not record the payment a second time.
const newRequestId = () => (window.crypto && window.crypto.randomUUID ? window.crypto.randomUUID() : `r${Date.now().toString(36)}${Math.random().toString(36).slice(2, 12)}`);

export function openPaymentModal({ member, memberships = [], defaultMembershipId = '', defaultAmount = '', onDone }) {
  const options = [{ value: '', label: 'Not linked to a membership' }].concat(
    memberships.map((m) => ({ value: m._id, label: `${m.planName} · ${formatDate(m.startDate)} → ${formatDate(m.endDate)} · ${formatINR(m.price)}` }))
  );

  const modal = openModal({
    title: `Record payment · ${member.name}`,
    bodyHtml: `
      <form id="payForm" class="flex flex-col gap-4" novalidate>
        ${errorAlert()}
        <div class="grid gap-4 sm:grid-cols-2">
          ${field({ id: 'amount', label: 'Amount (₹) *', type: 'number', value: defaultAmount, attrs: 'min="0.01" step="0.01" inputmode="decimal" required' })}
          ${selectField({ id: 'method', label: 'Method', options: PAYMENT_METHODS, value: 'cash' })}
        </div>
        ${field({ id: 'paidOn', label: 'Paid on', type: 'date', value: todayStr() })}
        ${memberships.length ? selectField({ id: 'membershipId', label: 'For membership', options, value: defaultMembershipId }) : ''}
        ${field({ id: 'note', label: 'Note (optional)', attrs: 'maxlength="200"' })}
        <div class="flex flex-col-reverse sm:flex-row gap-space-sm sm:justify-end pt-1">
          <button type="button" data-close class="${BTN_SECONDARY}">Cancel</button>
          <button id="paySubmit" type="submit" class="${BTN_PRIMARY}">Record payment</button>
        </div>
      </form>`
  });

  const form = modal.el.querySelector('#payForm');
  const clientRequestId = newRequestId();
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    clearFormError(modal.el);
    const amount = Number(form.elements.amount.value);
    if (!(amount > 0)) return showFormError(modal.el, 'Enter an amount greater than 0.');

    const payload = { memberId: member._id, amount, method: form.elements.method.value, paidOn: form.elements.paidOn.value || todayStr(), clientRequestId };
    if (form.membershipId && form.elements.membershipId.value) payload.membershipId = form.elements.membershipId.value;
    if (form.elements.note.value.trim()) payload.note = form.elements.note.value.trim();

    const btn = modal.el.querySelector('#paySubmit');
    setBusy(btn, true, 'Saving…');
    try {
      await recordPayment(payload);
      modal.close();
      showToast('Payment recorded', 'success');
      if (onDone) onDone();
    } catch (error) {
      setBusy(btn, false);
      showFormError(modal.el, friendlyErrorMessage(error));
    }
  });
}
