// Small shared UI builders. They return HTML strings; every dynamic value is
// escaped. Keeping them in one place keeps the pages consistent.
import { escapeHtml } from '../utils/dom.js';
import { STATUS_META } from '../utils/constants.js';

export const INPUT_CLS =
  'w-full h-12 px-4 rounded-lg bg-surface-container-low text-on-surface font-body-md text-[16px] leading-6 placeholder:text-outline focus:outline-none focus:bg-surface-container-lowest focus:ring-2 focus:ring-primary/30 shadow-sm transition-all';
export const BTN_PRIMARY =
  'h-12 px-space-lg bg-primary hover:bg-primary-container text-on-primary font-label-md text-label-md rounded-xl shadow-md inline-flex items-center justify-center gap-2 transition-all active:scale-[0.98] disabled:opacity-60 disabled:cursor-not-allowed';
export const BTN_SECONDARY =
  'h-12 px-space-lg bg-surface-container text-on-surface hover:bg-surface-container-high font-label-md text-label-md rounded-xl inline-flex items-center justify-center gap-2 transition-colors disabled:opacity-60';
export const BTN_DANGER =
  'h-12 px-space-lg bg-error-container text-on-error-container hover:bg-error/20 font-label-md text-label-md rounded-xl inline-flex items-center justify-center gap-2 transition-colors';
// min-w-0: cards are usually grid/flex items; without it one long email or name makes the whole page scroll sideways on a phone.
export const CARD = 'bg-surface-container-lowest rounded-2xl shadow-sm min-w-0';

export const icon = (name, cls = '') => `<span class="material-symbols-outlined ${cls}" aria-hidden="true">${name}</span>`;

export function statusChip(status, text) {
  const meta = STATUS_META[status] || STATUS_META.none;
  return `<span class="inline-flex items-center px-2.5 py-1 rounded-full font-label-sm text-label-sm ${meta.cls}">${escapeHtml(text || meta.label)}</span>`;
}

/** Page container + title row. `actions` is raw HTML (already safe). */
export function pageShell({ title, subtitle = '', actions = '', body }) {
  return `
    <div class="max-w-6xl mx-auto px-margin-mobile md:px-margin py-space-lg">
      <div class="flex flex-col sm:flex-row sm:items-end justify-between gap-space-md mb-space-lg">
        <div class="min-w-0">
          <h1 class="font-headline-lg-mobile md:font-headline-lg text-headline-lg-mobile md:text-headline-lg text-on-surface">${escapeHtml(title)}</h1>
          ${subtitle ? `<p class="font-body-md text-body-md text-on-surface-variant mt-1">${escapeHtml(subtitle)}</p>` : ''}
        </div>
        ${actions ? `<div class="flex flex-wrap gap-space-sm">${actions}</div>` : ''}
      </div>
      ${body}
    </div>`;
}

/** Label + input. `attrs` is a raw attribute string, e.g. 'required maxlength="80"'. */
export function field({ id, label, type = 'text', value = '', placeholder = '', attrs = '', hint = '' }) {
  return `
    <div class="flex flex-col gap-1.5">
      <label class="font-label-md text-label-md text-on-surface" for="${id}">${escapeHtml(label)}</label>
      <input id="${id}" name="${id}" type="${type}" value="${escapeHtml(value)}" placeholder="${escapeHtml(placeholder)}" class="${INPUT_CLS}" ${attrs}/>
      ${hint ? `<p class="font-body-sm text-body-sm text-on-surface-variant">${escapeHtml(hint)}</p>` : ''}
    </div>`;
}

/** options: [{value, label}] */
export function selectField({ id, label, options, value = '', attrs = '' }) {
  const opts = options.map((o) => `<option value="${escapeHtml(o.value)}" ${String(o.value) === String(value) ? 'selected' : ''}>${escapeHtml(o.label)}</option>`).join('');
  return `
    <div class="flex flex-col gap-1.5">
      <label class="font-label-md text-label-md text-on-surface" for="${id}">${escapeHtml(label)}</label>
      <select id="${id}" name="${id}" class="${INPUT_CLS}" ${attrs}>${opts}</select>
    </div>`;
}

export function errorAlert(id = 'formError') {
  return `<div id="${id}" class="hidden p-3 rounded-lg bg-error-container text-on-error-container font-body-sm text-body-sm" role="alert"></div>`;
}

export function showFormError(root, message, id = 'formError') {
  const el = root.querySelector(`#${id}`);
  if (!el) return;
  el.textContent = message;
  el.classList.remove('hidden');
}

export function clearFormError(root, id = 'formError') {
  const el = root.querySelector(`#${id}`);
  if (el) el.classList.add('hidden');
}

/** Disables a submit button and swaps its label while a request runs. */
export function setBusy(button, busy, busyLabel = 'Saving…') {
  if (!button) return;
  if (busy) {
    button.dataset.label = button.innerHTML;
    button.disabled = true;
    button.textContent = busyLabel;
  } else {
    button.disabled = false;
    if (button.dataset.label) button.innerHTML = button.dataset.label;
  }
}

/** Prev / next controls. Pages attach click handlers to [data-page]. */
export function pager(p) {
  if (!p || p.pages <= 1) return '';
  const btn = (label, page, disabled) =>
    `<button type="button" data-page="${page}" ${disabled ? 'disabled' : ''} class="min-h-[44px] px-4 rounded-lg bg-surface-container text-on-surface font-label-md text-label-md hover:bg-surface-container-high disabled:opacity-40 disabled:cursor-not-allowed">${label}</button>`;
  return `
    <div class="flex items-center justify-between gap-space-sm mt-space-md">
      ${btn('Previous', p.page - 1, p.page <= 1)}
      <span class="font-body-sm text-body-sm text-on-surface-variant">Page ${p.page} of ${p.pages} · ${p.total} total</span>
      ${btn('Next', p.page + 1, p.page >= p.pages)}
    </div>`;
}
