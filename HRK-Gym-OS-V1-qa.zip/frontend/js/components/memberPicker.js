import { openModal } from './modal.js';
import { INPUT_CLS } from './ui.js';
import { listMembers } from '../services/memberService.js';
import { escapeHtml, debounce } from '../utils/dom.js';
import { friendlyErrorMessage } from '../utils/format.js';

/** Search-and-pick a member (used to record a payment from the Payments page). */
export function openMemberPicker({ title = 'Choose a member', onPick }) {
  const modal = openModal({
    title,
    bodyHtml: `
      <input id="pickSearch" type="search" placeholder="Search name, phone or member ID" class="${INPUT_CLS} mb-3" autocomplete="off" aria-label="Search members"/>
      <div id="pickResults" class="max-h-[50vh] overflow-y-auto"></div>`
  });
  const input = modal.el.querySelector('#pickSearch');
  const results = modal.el.querySelector('#pickResults');
  let members = [];

  async function load() {
    results.innerHTML = '<p class="font-body-md text-body-md text-on-surface-variant py-3">Searching…</p>';
    try {
      members = (await listMembers({ search: input.value.trim(), limit: 10 })).members;
    } catch (error) {
      results.innerHTML = `<p class="font-body-sm text-error py-3">${escapeHtml(friendlyErrorMessage(error))}</p>`;
      return;
    }
    results.innerHTML = members.length
      ? members.map((m, i) => `
          <button type="button" data-i="${i}" class="w-full text-left py-3 px-2 rounded-lg hover:bg-surface-container-low flex flex-col">
            <span class="font-label-md text-label-md text-on-surface">${escapeHtml(m.name)}</span>
            <span class="font-body-sm text-body-sm text-on-surface-variant">${escapeHtml(m.memberCode)}${m.phone ? ' · ' + escapeHtml(m.phone) : ''}</span>
          </button>`).join('')
      : '<p class="font-body-md text-body-md text-on-surface-variant py-3">No members found.</p>';
  }

  results.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-i]');
    if (!btn) return;
    const member = members[Number(btn.dataset.i)];
    modal.close();
    onPick(member);
  });
  input.addEventListener('input', debounce(load));
  load();
  input.focus();
}
