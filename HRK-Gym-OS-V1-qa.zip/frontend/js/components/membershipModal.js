import { openModal } from './modal.js';
import { field, selectField, errorAlert, showFormError, clearFormError, setBusy, BTN_PRIMARY, BTN_SECONDARY } from './ui.js';
import { showToast } from './toast.js';
import { listPlans } from '../services/planService.js';
import { assignMembership, renewMember } from '../services/memberService.js';
import { PAYMENT_METHODS } from '../utils/constants.js';
import { escapeHtml } from '../utils/dom.js';
import { todayStr, formatINR, friendlyErrorMessage } from '../utils/format.js';

const durationText = (p) => `${p.durationValue} ${p.durationUnit === 'days' ? (p.durationValue === 1 ? 'day' : 'days') : (p.durationValue === 1 ? 'month' : 'months')}`;

/**
 * Assign a first plan or renew. `hasHistory` decides which API route is used and
 * the wording. Renewals add a new period; previous periods are never changed.
 */
export async function openMembershipModal({ member, hasHistory, onDone }) {
  const title = hasHistory ? `Renew ${member.name}` : `Assign a plan to ${member.name}`;
  const modal = openModal({ title, bodyHtml: '<p class="font-body-md text-body-md text-on-surface-variant py-4">Loading plans…</p>' });
  const body = modal.el.querySelector('[data-body]');

  let plans;
  try {
    plans = await listPlans({ active: 'true' });
  } catch (error) {
    body.innerHTML = `<div class="p-3 rounded-lg bg-error-container text-on-error-container font-body-sm">${escapeHtml(friendlyErrorMessage(error))}</div>`;
    return;
  }

  if (!plans.length) {
    body.innerHTML = `
      <p class="font-body-md text-body-md text-on-surface-variant mb-4">There are no active membership plans yet. Create a plan first, then come back.</p>
      <a href="#/plans" data-close class="${BTN_PRIMARY} w-full">Go to plans</a>`;
    return;
  }

  body.innerHTML = `
    <form id="msForm" class="flex flex-col gap-4" novalidate>
      ${errorAlert()}
      ${selectField({ id: 'planId', label: 'Plan', options: plans.map((p) => ({ value: p._id, label: `${p.name} · ${durationText(p)} · ${formatINR(p.price)}` })) })}
      ${field({ id: 'startDate', label: 'Start date', type: 'date', hint: hasHistory ? 'Leave blank to start right after the current membership ends (or today if it has already ended).' : 'Leave blank to start today.' })}
      <label class="flex items-center gap-3 min-h-[44px] cursor-pointer">
        <input id="recordPay" type="checkbox" checked class="w-5 h-5 accent-[#006948]"/>
        <span class="font-label-md text-label-md text-on-surface">Record the payment now</span>
      </label>
      <div id="payFields" class="grid gap-4 sm:grid-cols-2">
        ${field({ id: 'amount', label: 'Amount (₹)', type: 'number', value: plans[0].price, attrs: 'min="0.01" step="0.01" inputmode="decimal"' })}
        ${selectField({ id: 'method', label: 'Method', options: PAYMENT_METHODS, value: 'cash' })}
        ${field({ id: 'paidOn', label: 'Paid on', type: 'date', value: todayStr() })}
      </div>
      <div class="flex flex-col-reverse sm:flex-row gap-space-sm sm:justify-end pt-1">
        <button type="button" data-close class="${BTN_SECONDARY}">Cancel</button>
        <button id="msSubmit" type="submit" class="${BTN_PRIMARY}">${hasHistory ? 'Renew membership' : 'Assign plan'}</button>
      </div>
    </form>`;

  const form = body.querySelector('#msForm');
  const payFields = body.querySelector('#payFields');

  form.elements.planId.addEventListener('change', () => {
    const plan = plans.find((p) => p._id === form.elements.planId.value);
    if (plan) form.elements.amount.value = plan.price;
  });
  form.elements.recordPay.addEventListener('change', () => payFields.classList.toggle('hidden', !form.elements.recordPay.checked));

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    clearFormError(body);
    const payload = { planId: form.elements.planId.value };
    if (form.elements.startDate.value) payload.startDate = form.elements.startDate.value;
    if (form.elements.recordPay.checked) {
      const amount = Number(form.elements.amount.value);
      if (!(amount > 0)) return showFormError(body, 'Enter the amount received, or untick “Record the payment now”.');
      payload.payment = { amount, method: form.elements.method.value, paidOn: form.elements.paidOn.value || todayStr() };
    }

    const btn = body.querySelector('#msSubmit');
    setBusy(btn, true, 'Saving…');
    try {
      if (hasHistory) await renewMember(member._id, payload);
      else await assignMembership({ ...payload, memberId: member._id });
      modal.close();
      showToast(hasHistory ? 'Membership renewed' : 'Plan assigned', 'success');
      if (onDone) onDone();
    } catch (error) {
      setBusy(btn, false);
      showFormError(body, friendlyErrorMessage(error));
    }
  });
}
