import { escapeHtml } from '../utils/dom.js';

/**
 * Opens a modal with arbitrary (already-safe) HTML. Returns { el, close }.
 * Click outside / Escape / the close button dismiss it. On phones it slides
 * up as a full-width sheet; on larger screens it is centred.
 */
export function openModal({ title, bodyHtml }) {
  const overlay = document.createElement('div');
  overlay.className = 'fixed inset-0 z-[55] bg-inverse-surface/60 flex items-end sm:items-center justify-center sm:p-space-md';
  overlay.innerHTML = `
    <div role="dialog" aria-modal="true" aria-label="${escapeHtml(title)}" class="hrk-modal-pop bg-surface-container-lowest w-full sm:max-w-lg max-h-[92vh] overflow-y-auto rounded-t-2xl sm:rounded-2xl shadow-2xl p-space-lg">
      <div class="flex items-start justify-between gap-space-md mb-space-md">
        <h2 class="font-headline-md text-headline-md text-on-surface">${escapeHtml(title)}</h2>
        <button type="button" data-close aria-label="Close" class="min-w-[44px] min-h-[44px] -mt-2 -mr-2 inline-flex items-center justify-center rounded-full text-on-surface-variant hover:bg-surface-container"><span class="material-symbols-outlined">close</span></button>
      </div>
      <div data-body>${bodyHtml}</div>
    </div>`;

  function close() {
    document.removeEventListener('keydown', onKey);
    overlay.remove();
  }
  function onKey(e) { if (e.key === 'Escape') close(); }

  overlay.addEventListener('click', (e) => {
    if (e.target === overlay || e.target.closest('[data-close]')) close();
  });
  document.addEventListener('keydown', onKey);
  document.body.appendChild(overlay);
  return { el: overlay, close };
}
