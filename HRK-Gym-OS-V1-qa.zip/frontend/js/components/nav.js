import { getUser, getGym, getRole } from '../state/store.js';
import { escapeHtml } from '../utils/dom.js';

const ADMIN_LINKS = [
  { route: 'dashboard', label: 'Dashboard', icon: 'dashboard', bottom: 'Home' },
  { route: 'members', label: 'Members', icon: 'group', bottom: 'Members' },
  { route: 'checkin', label: 'Check-in', icon: 'qr_code_scanner', bottom: 'Check-in' },
  { route: 'payments', label: 'Payments', icon: 'payments', bottom: 'Payments' },
  { route: 'attendance', label: 'Attendance', icon: 'event_available', more: true },
  { route: 'plans', label: 'Plans', icon: 'sell', more: true },
  { route: 'gym', label: 'Gym', icon: 'storefront', more: true }
];

const MEMBER_LINKS = [
  { route: 'portal', label: 'My Membership', icon: 'badge', bottom: 'Membership' },
  { route: 'portal/attendance', label: 'Attendance', icon: 'event_available', bottom: 'Attendance' },
  { route: 'portal/payments', label: 'Payments', icon: 'payments', bottom: 'Payments' }
];

export const adminLinks = () => ADMIN_LINKS;
export const homeRouteFor = (role) => (role === 'member' ? 'portal' : 'dashboard');

const linksFor = (role) => (role === 'member' ? MEMBER_LINKS : ADMIN_LINKS);

function initials(name) {
  if (!name) return 'HG';
  const parts = name.trim().split(/\s+/);
  return ((parts[0]?.[0] || '') + (parts.length > 1 ? parts[parts.length - 1][0] : '')).toUpperCase() || 'HG';
}

export function renderHeader(activeRoute) {
  const role = getRole();
  const user = getUser();
  const gym = getGym();
  const links = linksFor(role).map((l) => {
    const active = activeRoute === l.route;
    return `<a href="#/${l.route}" class="px-space-md py-space-xs rounded-lg font-label-md text-label-md transition-colors ${active ? 'bg-primary-container text-on-primary-container' : 'text-on-surface-variant hover:text-on-surface'}" ${active ? 'aria-current="page"' : ''}>${escapeHtml(l.label)}</a>`;
  }).join('');
  const subtitle = role === 'member' ? 'Member' : (gym && gym.name) || 'Admin';

  return `
    <div class="h-16 max-w-7xl mx-auto px-margin-mobile md:px-margin flex items-center justify-between gap-space-md">
      <a href="#/${homeRouteFor(role)}" class="flex items-center gap-space-sm min-w-0 min-h-[44px]">
        <div class="w-8 h-8 shrink-0 rounded-lg bg-primary flex items-center justify-center text-on-primary">
          <span class="material-symbols-outlined text-lg" style="font-variation-settings: 'FILL' 1;">fitness_center</span>
        </div>
        <span class="font-title-sm text-title-sm tracking-tight text-on-surface truncate">HRK Gym OS</span>
      </a>
      <nav class="hidden md:flex items-center gap-space-xs bg-surface-container-low p-1 rounded-xl" aria-label="Main">${links}</nav>
      <div class="flex items-center gap-space-sm min-w-0">
        <div class="hidden sm:flex flex-col text-right min-w-0">
          <span class="font-label-md text-label-md text-on-surface truncate">${escapeHtml(user?.name || '')}</span>
          <span class="font-label-sm text-label-sm text-primary truncate">${escapeHtml(subtitle)}</span>
        </div>
        <span class="inline-flex items-center justify-center w-9 h-9 rounded-full bg-primary-container text-on-primary-container font-label-sm text-label-sm shrink-0">${escapeHtml(initials(user?.name))}</span>
        <button type="button" id="logoutBtn" class="inline-flex items-center justify-center gap-1 px-2 md:px-3 min-w-[44px] min-h-[44px] rounded-lg text-on-surface-variant hover:bg-surface-container font-label-md text-label-md" aria-label="Log out">
          <span class="material-symbols-outlined text-[20px]">logout</span><span class="hidden md:inline">Log out</span>
        </button>
      </div>
    </div>`;
}

export function renderBottomNav(activeRoute) {
  const role = getRole();
  let items;
  if (role === 'member') {
    items = MEMBER_LINKS.map((l) => ({ ...l, label: l.bottom }));
  } else {
    items = ADMIN_LINKS.filter((l) => l.bottom).map((l) => ({ ...l, label: l.bottom }));
    items.push({ route: 'more', label: 'More', icon: 'menu' });
  }
  const moreActive = role !== 'member' && ['more', 'attendance', 'plans', 'gym'].includes(activeRoute);
  const html = items.map((l) => {
    const active = l.route === 'more' ? moreActive : activeRoute === l.route;
    return `
      <a href="#/${l.route}" class="flex-1 min-w-0 flex flex-col items-center justify-center min-h-[52px] py-1.5 px-0.5 rounded-xl transition-colors ${active ? 'bg-primary text-on-primary' : 'text-on-surface-variant'}" ${active ? 'aria-current="page"' : ''}>
        <span class="material-symbols-outlined text-[22px]">${l.icon}</span>
        <span class="font-label-sm text-label-sm mt-0.5 whitespace-nowrap text-[11px] sm:text-[12px]">${escapeHtml(l.label)}</span>
      </a>`;
  }).join('');
  return `<nav class="pointer-events-auto max-w-md mx-auto bg-surface-container-lowest/95 backdrop-blur-xl shadow-[0_4px_20px_rgba(0,0,0,0.12)] rounded-2xl p-1 flex items-stretch gap-1" aria-label="Main">${html}</nav>`;
}
