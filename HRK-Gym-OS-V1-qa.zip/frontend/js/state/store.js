// Minimal app state: the authenticated user (+ their gym) and the JWT,
// persisted to localStorage so a refresh doesn't log the person out.
// Only the login session lives here — all business data comes from the API.

const TOKEN_KEY = 'hrk_token';
const USER_KEY = 'hrk_user';
const GYM_KEY = 'hrk_gym';

let listeners = [];

const readJson = (key) => {
  const raw = localStorage.getItem(key);
  if (!raw) return null;
  try { return JSON.parse(raw); } catch (e) { return null; }
};

export const getToken = () => localStorage.getItem(TOKEN_KEY);
export const getUser = () => readJson(USER_KEY);
export const getGym = () => readJson(GYM_KEY);
export const getRole = () => (getUser() || {}).role || null;
export const isAuthenticated = () => Boolean(getToken());

export function setAuth(token, user, gym) {
  localStorage.setItem(TOKEN_KEY, token);
  localStorage.setItem(USER_KEY, JSON.stringify(user));
  if (gym) localStorage.setItem(GYM_KEY, JSON.stringify(gym));
  else localStorage.removeItem(GYM_KEY);
  notify();
}

export function setSessionDetails(user, gym) {
  if (user) localStorage.setItem(USER_KEY, JSON.stringify(user));
  if (gym) localStorage.setItem(GYM_KEY, JSON.stringify(gym));
  notify();
}

export function clearAuth() {
  localStorage.removeItem(TOKEN_KEY);
  localStorage.removeItem(USER_KEY);
  localStorage.removeItem(GYM_KEY);
  notify();
}

/** Subscribe to auth state changes (e.g. header re-rendering). */
export function onAuthChange(callback) {
  listeners.push(callback);
  return () => { listeners = listeners.filter((l) => l !== callback); };
}

function notify() {
  listeners.forEach((callback) => callback());
}
