// HRK Gym OS frontend runtime config.
// Set apiBaseUrl to wherever the backend API runs (no trailing slash).
window.HRK_CONFIG = {
  apiBaseUrl: 'http://localhost:5000'
};
