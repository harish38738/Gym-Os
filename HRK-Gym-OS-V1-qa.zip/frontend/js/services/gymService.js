import { apiRequest } from './apiClient.js';
export const getGym = async () => (await apiRequest('/api/gym')).data.gym;
export const updateGym = async (body) => (await apiRequest('/api/gym', { method: 'PUT', body })).data.gym;
