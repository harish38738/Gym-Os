import { apiRequest, toQuery } from './apiClient.js';
export const getOverview = async () => (await apiRequest('/api/me')).data;
export const getMyAttendance = async (params) => (await apiRequest(`/api/me/attendance${toQuery(params)}`)).data;
export const getMyPayments = async (params) => (await apiRequest(`/api/me/payments${toQuery(params)}`)).data;
