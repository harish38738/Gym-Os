import { apiRequest, toQuery } from './apiClient.js';
export const listAttendance = async (params) => (await apiRequest(`/api/attendance${toQuery(params)}`)).data;
// Resolves with { result: 'checked_in' | 'duplicate', ... }. A refused check-in
// (expired, inactive, unknown QR) rejects with an ApiError; error.data.data holds details.
export const checkIn = async (qrToken) => (await apiRequest('/api/attendance/check-in', { method: 'POST', body: { qrToken } })).data;
