// Centralized fetch wrapper for the HRK Gym OS API.
// Every service module calls through this — no page or component calls
// fetch() directly, so auth headers and error handling live in one place.

import { getToken, clearAuth } from '../state/store.js';

export class ApiError extends Error {
  constructor(message, status, data) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.data = data;
  }
}

function apiBaseUrl() {
  return (window.HRK_CONFIG && window.HRK_CONFIG.apiBaseUrl) || 'http://localhost:5000';
}

/** Builds "?a=1&b=2" from an object, skipping empty values. */
export function toQuery(params = {}) {
  const usp = new URLSearchParams();
  Object.entries(params).forEach(([k, val]) => {
    if (val !== undefined && val !== null && val !== '') usp.set(k, val);
  });
  const s = usp.toString();
  return s ? `?${s}` : '';
}

/**
 * @param {string} path - e.g. '/api/auth/login'
 * @param {{method?: string, body?: any, auth?: boolean}} options
 */
export async function apiRequest(path, options = {}) {
  const { method = 'GET', body, auth = true } = options;

  const headers = { 'Content-Type': 'application/json' };
  if (auth) {
    const token = getToken();
    if (token) headers.Authorization = `Bearer ${token}`;
  }

  let response;
  try {
    response = await fetch(`${apiBaseUrl()}${path}`, {
      method,
      headers,
      body: body !== undefined ? JSON.stringify(body) : undefined
    });
  } catch (networkError) {
    throw new ApiError('Could not reach the server. Check your connection, and that the API URL in js/config.js is correct.', 0, null);
  }

  let data = null;
  const text = await response.text();
  if (text) {
    try { data = JSON.parse(text); } catch (parseError) { data = null; }
  }

  if (!response.ok) {
    // Expired/invalid token on a protected call: drop the session so the
    // next navigation goes to login instead of looping on 401s.
    // (A failed login attempt is also a 401, but has no session to clear.)
    if (response.status === 401 && auth) clearAuth();
    const message = (data && data.message) || `Request failed (${response.status})`;
    throw new ApiError(message, response.status, data);
  }

  return data;
}
