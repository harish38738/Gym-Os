import { apiRequest, toQuery } from './apiClient.js';
export const listPayments = async (params) => (await apiRequest(`/api/payments${toQuery(params)}`)).data;
export const recordPayment = async (body) => (await apiRequest('/api/payments', { method: 'POST', body })).data.payment;
export const deletePayment = async (id) => apiRequest(`/api/payments/${id}`, { method: 'DELETE' });
