import { apiRequest, toQuery } from './apiClient.js';
export const listPlans = async (params) => (await apiRequest(`/api/plans${toQuery(params)}`)).data.plans;
export const createPlan = async (body) => (await apiRequest('/api/plans', { method: 'POST', body })).data.plan;
export const updatePlan = async (id, body) => (await apiRequest(`/api/plans/${id}`, { method: 'PUT', body })).data.plan;
export const deletePlan = async (id) => apiRequest(`/api/plans/${id}`, { method: 'DELETE' });
