import { apiRequest } from './apiClient.js';
export const getDashboard = async () => (await apiRequest('/api/dashboard')).data;
