import { apiRequest, toQuery } from './apiClient.js';
export const listMembers = async (params) => (await apiRequest(`/api/members${toQuery(params)}`)).data;
export const getMember = async (id) => (await apiRequest(`/api/members/${id}`)).data;
export const createMember = async (body) => (await apiRequest('/api/members', { method: 'POST', body })).data.member;
export const updateMember = async (id, body) => (await apiRequest(`/api/members/${id}`, { method: 'PUT', body })).data.member;
export const deleteMember = async (id) => apiRequest(`/api/members/${id}`, { method: 'DELETE' });
export const regenerateQr = async (id) => (await apiRequest(`/api/members/${id}/regenerate-qr`, { method: 'POST' })).data;
// Assign a plan (first membership, or a specific period).
export const assignMembership = async (body) => (await apiRequest('/api/memberships', { method: 'POST', body })).data;
// Renew: adds a new period after the current one; history is kept.
export const renewMember = async (id, body) => (await apiRequest(`/api/members/${id}/renew`, { method: 'POST', body })).data;
// CSV import: the server validates every row. dryRun=true returns a preview only.
export const importMembers = async (rows, dryRun) => (await apiRequest('/api/members/import', { method: 'POST', body: { rows, dryRun } })).data;
