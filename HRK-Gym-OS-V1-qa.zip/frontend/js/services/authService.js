import { apiRequest } from './apiClient.js';
import { setAuth, clearAuth, getUser, setSessionDetails } from '../state/store.js';

/** Gym owner sign-up: creates the gym and its admin account. */
export async function registerGym({ gymName, name, email, password }) {
  const res = await apiRequest('/api/auth/register', { method: 'POST', body: { gymName, name, email, password }, auth: false });
  setAuth(res.data.token, res.data.user, res.data.gym);
  return res.data.user;
}

/** Used by both admins and members; the returned role decides which app they see. */
export async function login(email, password) {
  const res = await apiRequest('/api/auth/login', { method: 'POST', body: { email, password }, auth: false });
  setAuth(res.data.token, res.data.user, null);
  return res.data.user;
}

/** Reloads user + gym from the server (e.g. to show the gym name in the header). */
export async function refreshProfile() {
  const res = await apiRequest('/api/auth/profile');
  setSessionDetails(res.data.user, res.data.gym);
  return res.data;
}

export function logout() { clearAuth(); }
export function currentUser() { return getUser(); }
