import { registerGym } from '../services/authService.js';
import { field, errorAlert, showFormError, clearFormError, setBusy, BTN_PRIMARY } from '../components/ui.js';
import { friendlyErrorMessage } from '../utils/format.js';

export function render(container) {
  container.innerHTML = `
    <div class="w-full min-h-screen py-10 px-gutter-mobile md:px-margin flex items-center justify-center">
      <div class="w-full max-w-md">
        <div class="flex flex-col items-center mb-6 text-center">
          <div class="w-12 h-12 rounded-xl bg-primary flex items-center justify-center text-on-primary mb-3">
            <span class="material-symbols-outlined" style="font-variation-settings: 'FILL' 1;">fitness_center</span>
          </div>
          <div class="font-headline-md text-headline-md text-on-surface">HRK Gym OS</div>
        </div>

        <div class="bg-surface-container-lowest rounded-2xl p-6 sm:p-8 shadow-lg">
          <h1 class="font-headline-md text-headline-md text-on-surface">Register your gym</h1>
          <p class="font-body-md text-body-md text-on-surface-variant mt-1 mb-5">Create the owner account. You can add members and plans right after.</p>
          <form id="registerForm" class="flex flex-col gap-5" novalidate>
            ${errorAlert()}
            ${field({ id: 'gymName', label: 'Gym name', placeholder: 'e.g. Iron Works Fitness', attrs: 'required maxlength="120"' })}
            ${field({ id: 'name', label: 'Your name', placeholder: 'Owner name', attrs: 'required maxlength="120" autocomplete="name"' })}
            ${field({ id: 'email', label: 'Email', type: 'email', placeholder: 'you@example.com', attrs: 'required autocomplete="email" inputmode="email"' })}
            ${field({ id: 'password', label: 'Password', type: 'password', placeholder: 'At least 8 characters', attrs: 'required minlength="8" autocomplete="new-password"' })}
            <button id="submitBtn" type="submit" class="${BTN_PRIMARY} w-full">Create gym account</button>
          </form>
          <div class="mt-6 pt-5 border-t border-surface-container text-center font-body-sm text-body-sm text-on-surface-variant">
            Already registered?
            <a class="font-title-sm text-title-sm text-primary hover:underline ml-1 inline-block py-3 -my-3" href="#/login">Log in</a>
          </div>
        </div>
      </div>
    </div>`;

  const form = container.querySelector('#registerForm');
  const btn = container.querySelector('#submitBtn');

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    clearFormError(container);
    const gymName = form.elements.gymName.value.trim();
    const name = form.elements.name.value.trim();
    const email = form.elements.email.value.trim();
    const password = form.elements.password.value;

    if (!gymName || !name || !email || !password) return showFormError(container, 'Please fill in every field.');
    if (password.length < 8) return showFormError(container, 'Password must be at least 8 characters long.');

    setBusy(btn, true, 'Creating…');
    try {
      await registerGym({ gymName, name, email, password });
      window.location.hash = '#/dashboard';
    } catch (error) {
      setBusy(btn, false);
      showFormError(container, friendlyErrorMessage(error));
    }
  });
}
