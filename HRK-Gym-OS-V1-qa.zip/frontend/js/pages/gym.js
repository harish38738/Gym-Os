import { getGym, updateGym } from '../services/gymService.js';
import { setSessionDetails, getUser } from '../state/store.js';
import { renderLoading, renderErrorBanner } from '../components/states.js';
import { pageShell, field, errorAlert, showFormError, clearFormError, setBusy, CARD, BTN_PRIMARY } from '../components/ui.js';
import { showToast } from '../components/toast.js';
import { friendlyErrorMessage } from '../utils/format.js';

export async function render(container) {
  container.innerHTML = pageShell({ title: 'Gym profile', body: renderLoading('Loading…') });

  let gym;
  try {
    gym = await getGym();
  } catch (error) {
    container.innerHTML = pageShell({ title: 'Gym profile', body: renderErrorBanner({ message: friendlyErrorMessage(error), retryId: 'retryBtn' }) });
    container.querySelector('#retryBtn')?.addEventListener('click', () => render(container));
    return;
  }
  const user = getUser() || {};

  container.innerHTML = pageShell({
    title: 'Gym profile',
    subtitle: `Signed in as ${user.name || ''} (${user.email || ''})`,
    body: `
      <form id="gymForm" class="${CARD} p-space-lg max-w-2xl flex flex-col gap-5" novalidate>
        ${errorAlert()}
        ${field({ id: 'name', label: 'Gym name *', value: gym.name || '', attrs: 'required maxlength="120"' })}
        <div class="grid gap-5 sm:grid-cols-2">
          ${field({ id: 'phone', label: 'Phone', type: 'tel', value: gym.phone || '', attrs: 'inputmode="tel"' })}
          ${field({ id: 'city', label: 'City', value: gym.city || '', attrs: 'maxlength="80"' })}
        </div>
        ${field({ id: 'address', label: 'Address', value: gym.address || '', attrs: 'maxlength="300"' })}
        <div class="flex sm:justify-end"><button id="saveBtn" type="submit" class="${BTN_PRIMARY} w-full sm:w-auto">Save changes</button></div>
      </form>`
  });

  const form = container.querySelector('#gymForm');
  const btn = container.querySelector('#saveBtn');
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    clearFormError(container);
    const body = { name: form.elements.name.value.trim(), phone: form.elements.phone.value.trim(), city: form.elements.city.value.trim(), address: form.elements.address.value.trim() };
    if (!body.name) return showFormError(container, 'Your gym needs a name.');
    setBusy(btn, true, 'Saving…');
    try {
      const saved = await updateGym(body);
      setSessionDetails(null, saved); // header shows the new name
      showToast('Gym profile saved', 'success');
    } catch (error) {
      showFormError(container, friendlyErrorMessage(error));
    } finally {
      setBusy(btn, false);
    }
  });
}
