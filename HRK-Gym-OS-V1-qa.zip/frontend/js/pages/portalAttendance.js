import { getMyAttendance } from '../services/portalService.js';
import { renderLoading, renderErrorBanner, renderEmptyState } from '../components/states.js';
import { pageShell, pager, CARD } from '../components/ui.js';
import { formatDateTime, friendlyErrorMessage } from '../utils/format.js';

export async function render(container) {
  const state = { page: 1 };
  container.innerHTML = pageShell({ title: 'My attendance', body: '<div id="list"></div>' });
  const list = container.querySelector('#list');

  async function load() {
    list.innerHTML = renderLoading('Loading attendance…');
    let data;
    try {
      data = await getMyAttendance({ page: state.page, limit: 20 });
    } catch (error) {
      list.innerHTML = renderErrorBanner({ message: friendlyErrorMessage(error), retryId: 'retryBtn' });
      list.querySelector('#retryBtn')?.addEventListener('click', load);
      return;
    }
    if (!data.attendance.length) {
      list.innerHTML = renderEmptyState({ icon: 'event_available', title: 'No check-ins yet.', message: 'Your visits will appear here after you scan your QR code at the front desk.' });
      return;
    }
    list.innerHTML = `
      <div class="max-w-xl mx-auto">
        <p class="font-label-md text-label-md text-on-surface-variant mb-space-sm">${data.pagination.total} visit${data.pagination.total === 1 ? '' : 's'}</p>
        <div class="${CARD} px-space-md"><ul class="divide-y divide-surface-container">
          ${data.attendance.map((a) => `<li class="py-3 font-body-md text-body-md text-on-surface">${formatDateTime(a.checkedInAt)}</li>`).join('')}
        </ul></div>${pager(data.pagination)}
      </div>`;
    list.querySelectorAll('[data-page]').forEach((b) => b.addEventListener('click', () => { state.page = Number(b.dataset.page); load(); window.scrollTo(0, 0); }));
  }
  load();
}
