import { getMyPayments } from '../services/portalService.js';
import { renderLoading, renderErrorBanner, renderEmptyState } from '../components/states.js';
import { pageShell, pager, CARD } from '../components/ui.js';
import { escapeHtml } from '../utils/dom.js';
import { methodLabel } from '../utils/constants.js';
import { formatDate, formatINR, friendlyErrorMessage } from '../utils/format.js';

export async function render(container) {
  const state = { page: 1 };
  container.innerHTML = pageShell({ title: 'My payments', body: '<div id="list"></div>' });
  const list = container.querySelector('#list');

  async function load() {
    list.innerHTML = renderLoading('Loading payments…');
    let data;
    try {
      data = await getMyPayments({ page: state.page, limit: 20 });
    } catch (error) {
      list.innerHTML = renderErrorBanner({ message: friendlyErrorMessage(error), retryId: 'retryBtn' });
      list.querySelector('#retryBtn')?.addEventListener('click', load);
      return;
    }
    if (!data.payments.length) {
      list.innerHTML = renderEmptyState({ icon: 'payments', title: 'No payments recorded yet.', message: 'Payments recorded by your gym will appear here.' });
      return;
    }
    list.innerHTML = `
      <div class="max-w-xl mx-auto flex flex-col gap-space-sm">
        ${data.payments.map((p) => `
          <div class="${CARD} p-space-md flex items-center justify-between gap-space-md">
            <div class="min-w-0">
              <div class="font-title-sm text-title-sm text-on-surface">${formatINR(p.amount)}</div>
              <div class="font-body-sm text-body-sm text-on-surface-variant">${formatDate(p.paidOn)} · ${escapeHtml(methodLabel(p.method))}${p.note ? ' · ' + escapeHtml(p.note) : ''}</div>
            </div>
          </div>`).join('')}
        ${pager(data.pagination)}
      </div>`;
    list.querySelectorAll('[data-page]').forEach((b) => b.addEventListener('click', () => { state.page = Number(b.dataset.page); load(); window.scrollTo(0, 0); }));
  }
  load();
}
