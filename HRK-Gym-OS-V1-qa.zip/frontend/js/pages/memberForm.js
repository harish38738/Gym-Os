import { getMember, createMember, updateMember } from '../services/memberService.js';
import { renderLoading, renderErrorBanner } from '../components/states.js';
import { pageShell, field, selectField, errorAlert, showFormError, clearFormError, setBusy, BTN_PRIMARY, BTN_SECONDARY, CARD } from '../components/ui.js';
import { showToast } from '../components/toast.js';
import { GENDERS } from '../utils/constants.js';
import { todayStr, friendlyErrorMessage } from '../utils/format.js';

// One form for both "Add member" (no id) and "Edit member" (:id).
export async function render(container, params) {
  const id = params && params.id;
  let member = null;

  if (id) {
    container.innerHTML = pageShell({ title: 'Edit member', body: renderLoading('Loading member…') });
    try {
      member = (await getMember(id)).member;
    } catch (error) {
      container.innerHTML = pageShell({ title: 'Edit member', body: renderErrorBanner({ message: friendlyErrorMessage(error) }) });
      return;
    }
  }
  const m = member || {};

  container.innerHTML = pageShell({
    title: id ? 'Edit member' : 'Add member',
    subtitle: id ? `${m.memberCode} · ${m.name}` : 'Name and a phone number or email are enough to start.',
    body: `
      <form id="memberForm" class="${CARD} p-space-lg max-w-2xl flex flex-col gap-5" novalidate>
        ${errorAlert()}
        ${field({ id: 'name', label: 'Full name *', value: m.name || '', attrs: 'required maxlength="120" autocomplete="off"' })}
        <div class="grid gap-5 sm:grid-cols-2">
          ${field({ id: 'phone', label: 'Phone', type: 'tel', value: m.phone || '', placeholder: '9876543210', attrs: 'inputmode="tel" autocomplete="off"' })}
          ${field({ id: 'email', label: 'Email', type: 'email', value: m.email || '', attrs: 'autocomplete="off" inputmode="email"' })}
        </div>
        <div class="grid gap-5 sm:grid-cols-2">
          ${selectField({ id: 'gender', label: 'Gender', options: GENDERS, value: m.gender || '' })}
          ${field({ id: 'dateOfBirth', label: 'Date of birth', type: 'date', value: m.dateOfBirth || '', attrs: `max="${todayStr()}"` })}
        </div>
        <div class="grid gap-5 sm:grid-cols-2">
          ${field({ id: 'joinedDate', label: 'Joined on *', type: 'date', value: m.joinedDate || todayStr(), attrs: 'required' })}
          ${id ? selectField({ id: 'status', label: 'Account status', options: [{ value: 'active', label: 'Active' }, { value: 'inactive', label: 'Inactive (cannot check in)' }], value: m.status || 'active' }) : ''}
        </div>

        <div class="border-t border-surface-container pt-5">
          <h2 class="font-title-sm text-title-sm text-on-surface">Member portal login (optional)</h2>
          <p class="font-body-sm text-body-sm text-on-surface-variant mt-1 mb-4">Lets the member see their QR code, membership, attendance and payments. Needs an email.</p>
          ${field({ id: 'password', label: id && m.hasPortalLogin ? 'Reset portal password' : 'Portal password', type: 'password', placeholder: id && m.hasPortalLogin ? 'Leave blank to keep the current password' : 'At least 8 characters', attrs: 'autocomplete="new-password" minlength="8"' })}
          ${id && m.hasPortalLogin ? '<p class="font-body-sm text-body-sm text-primary mt-2">This member already has a portal login.</p>' : ''}
        </div>

        <div class="flex flex-col-reverse sm:flex-row gap-space-sm sm:justify-end pt-2">
          <a href="#/${id ? 'members/' + id : 'members'}" class="${BTN_SECONDARY}">Cancel</a>
          <button id="saveBtn" type="submit" class="${BTN_PRIMARY}">${id ? 'Save changes' : 'Add member'}</button>
        </div>
      </form>`
  });

  const form = container.querySelector('#memberForm');
  const btn = container.querySelector('#saveBtn');

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    clearFormError(container);

    const body = {
      name: form.elements.name.value.trim(),
      phone: form.elements.phone.value.trim(),
      email: form.elements.email.value.trim(),
      gender: form.elements.gender.value,
      dateOfBirth: form.elements.dateOfBirth.value,
      joinedDate: form.elements.joinedDate.value
    };
    if (id) body.status = form.elements.status.value;
    const password = form.elements.password.value;
    if (password) body.password = password;

    if (!body.name) return showFormError(container, 'Please enter the member’s name.');
    if (!body.phone && !body.email) return showFormError(container, 'Please enter a phone number or an email.');
    if (password && !body.email) return showFormError(container, 'An email is needed to give the member portal access.');
    if (password && password.length < 8) return showFormError(container, 'Portal password must be at least 8 characters.');

    setBusy(btn, true, 'Saving…');
    try {
      if (id) {
        await updateMember(id, body);
        showToast('Member updated', 'success');
        window.location.hash = `#/members/${id}`;
      } else {
        const created = await createMember(body);
        showToast('Member added', 'success');
        window.location.hash = `#/members/${created._id}`;
      }
    } catch (error) {
      setBusy(btn, false);
      showFormError(container, friendlyErrorMessage(error));
    }
  });
}
