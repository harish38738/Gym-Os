import { login } from '../services/authService.js';
import { field, errorAlert, showFormError, clearFormError, setBusy, BTN_PRIMARY } from '../components/ui.js';
import { friendlyErrorMessage } from '../utils/format.js';

export function render(container) {
  container.innerHTML = `
    <div class="w-full min-h-screen py-10 px-gutter-mobile md:px-margin flex items-center justify-center">
      <div class="w-full max-w-md">
        <div class="flex flex-col items-center mb-6 text-center">
          <div class="w-12 h-12 rounded-xl bg-primary flex items-center justify-center text-on-primary mb-3">
            <span class="material-symbols-outlined" style="font-variation-settings: 'FILL' 1;">fitness_center</span>
          </div>
          <div class="font-headline-md text-headline-md text-on-surface">HRK Gym OS</div>
          <p class="font-body-sm text-body-sm text-on-surface-variant mt-1">Simple gym management for independent gyms</p>
        </div>

        <div class="bg-surface-container-lowest rounded-2xl p-6 sm:p-8 shadow-lg">
          <h1 class="font-headline-md text-headline-md text-on-surface">Log in</h1>
          <p class="font-body-md text-body-md text-on-surface-variant mt-1 mb-5">Gym owners and members log in here.</p>
          <form id="loginForm" class="flex flex-col gap-5" novalidate>
            ${errorAlert()}
            ${field({ id: 'email', label: 'Email', type: 'email', placeholder: 'you@example.com', attrs: 'required autocomplete="email" inputmode="email"' })}
            ${field({ id: 'password', label: 'Password', type: 'password', placeholder: 'Your password', attrs: 'required autocomplete="current-password"' })}
            <button id="submitBtn" type="submit" class="${BTN_PRIMARY} w-full">Log in</button>
          </form>
          <div class="mt-6 pt-5 border-t border-surface-container text-center font-body-sm text-body-sm text-on-surface-variant">
            Running a gym?
            <a class="font-title-sm text-title-sm text-primary hover:underline ml-1 inline-block py-3 -my-3" href="#/register">Register your gym</a>
          </div>
        </div>
      </div>
    </div>`;

  const form = container.querySelector('#loginForm');
  const btn = container.querySelector('#submitBtn');

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    clearFormError(container);
    const email = form.elements.email.value.trim();
    const password = form.elements.password.value;
    if (!email || !password) return showFormError(container, 'Please enter both email and password.');

    setBusy(btn, true, 'Logging in…');
    try {
      const user = await login(email, password);
      window.location.hash = user.role === 'member' ? '#/portal' : '#/dashboard';
    } catch (error) {
      setBusy(btn, false);
      showFormError(container, friendlyErrorMessage(error));
    }
  });
}
