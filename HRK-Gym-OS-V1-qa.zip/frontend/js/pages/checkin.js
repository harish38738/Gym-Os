import { checkIn, listAttendance } from '../services/attendanceService.js';
import { pageShell, INPUT_CLS, CARD, BTN_PRIMARY, BTN_SECONDARY, icon } from '../components/ui.js';
import { escapeHtml, loadScript } from '../utils/dom.js';
import { formatDate, formatTime, todayStr, friendlyErrorMessage, pluralDays } from '../utils/format.js';

// Served from this app (frontend/vendor) so check-in doesn't depend on a CDN being reachable at the gym.
const JSQR_SRC = 'vendor/jsQR-1.4.0.js';
const SCAN_INTERVAL_MS = 120; // ~8 scans/second is plenty and saves phone battery

let stream = null;
let scanning = false;
let rafId = 0;
let onVisibility = null;
// Bumped by every cleanup(). Async steps (permission prompt, loading the scanner) compare it to the value
// they started with, so a camera that was granted AFTER the person left the page is switched off again
// instead of staying on in the background.
let session = 0;

/** Called by the router when leaving this page (and before every render): always release the camera. */
export function cleanup() {
  session += 1;
  scanning = false;
  if (rafId) { cancelAnimationFrame(rafId); rafId = 0; }
  if (stream) { stream.getTracks().forEach((t) => t.stop()); stream = null; }
  if (onVisibility) { document.removeEventListener('visibilitychange', onVisibility); onVisibility = null; }
}

function resultCard(kind, title, lines) {
  const styles = {
    ok: ['bg-primary-fixed text-on-primary-fixed', 'check_circle'],
    warn: ['bg-[#ffe9b8] text-[#5c4300]', 'info'],
    deny: ['bg-error-container text-on-error-container', 'cancel']
  }[kind];
  return `
    <div class="rounded-2xl p-space-md ${styles[0]}" role="status" aria-live="polite">
      <div class="flex items-center gap-3">
        <span class="material-symbols-outlined text-[36px]" style="font-variation-settings: 'FILL' 1;">${styles[1]}</span>
        <div class="min-w-0">
          <div class="font-headline-md text-headline-md">${escapeHtml(title)}</div>
          ${lines.map((l) => `<div class="font-body-md text-body-md">${escapeHtml(l)}</div>`).join('')}
        </div>
      </div>
    </div>`;
}

function describeMembership(m) {
  if (!m) return [];
  const bits = [];
  if (m.planName) bits.push(m.planName);
  if (m.endDate) bits.push(`valid until ${formatDate(m.endDate)}`);
  const line = bits.join(' · ');
  const left = m.daysLeft !== null && m.daysLeft !== undefined && m.status === 'expiring' ? `Expiring: ${m.daysLeft === 0 ? 'last day today' : pluralDays(m.daysLeft) + ' left'}` : '';
  return [line, left].filter(Boolean);
}

export async function render(container) {
  cleanup();

  container.innerHTML = pageShell({
    title: 'Check-in',
    subtitle: 'Scan a member’s QR code to record attendance.',
    body: `
      <div class="grid gap-space-md lg:grid-cols-2">
        <section class="${CARD} p-space-md flex flex-col gap-space-md">
          <div id="camBox" class="relative w-full aspect-square max-h-[34vh] sm:max-h-none max-w-md mx-auto rounded-xl bg-inverse-surface overflow-hidden flex items-center justify-center">
            <video id="video" class="absolute inset-0 w-full h-full object-cover hidden" playsinline muted></video>
            <canvas id="canvas" class="hidden"></canvas>
            <div id="camPlaceholder" class="text-center p-6 text-inverse-on-surface">
              <span class="material-symbols-outlined text-[56px] opacity-80">qr_code_scanner</span>
              <p class="font-body-md text-body-md mt-2 opacity-90">Camera is off</p>
            </div>
            <div id="camFrame" class="hidden absolute inset-[18%] border-4 border-white/80 rounded-2xl pointer-events-none"></div>
          </div>
          <div id="result" class="min-h-[96px]" aria-live="polite"></div>
          <div class="flex gap-space-sm justify-center">
            <button id="camToggle" class="${BTN_PRIMARY} flex-1 sm:flex-none">${icon('photo_camera', 'text-[20px]')} Start camera</button>
          </div>
          <p id="camMsg" class="font-body-sm text-body-sm text-on-surface-variant text-center"></p>

          <form id="manualForm" class="border-t border-surface-container pt-space-md flex flex-col gap-2">
            <label for="manualCode" class="font-label-md text-label-md text-on-surface">Scanner or code entry</label>
            <div class="flex gap-space-sm">
              <input id="manualCode" class="${INPUT_CLS}" placeholder="Scan or type the code" autocomplete="off" autocapitalize="off" spellcheck="false"/>
              <button type="submit" class="${BTN_SECONDARY} whitespace-nowrap shrink-0">Check in</button>
            </div>
          </form>
        </section>

        <section class="flex flex-col gap-space-md">
          <div class="${CARD} p-space-md">
            <div class="flex items-center justify-between mb-1">
              <h2 class="font-title-sm text-title-sm text-on-surface">Today’s check-ins</h2>
              <a href="#/attendance" class="inline-flex items-center min-h-[44px] px-1 font-label-md text-label-md text-primary hover:underline">View all</a>
            </div>
            <div id="recent"></div>
          </div>
        </section>
      </div>`
  });

  const $ = (sel) => container.querySelector(sel);
  const video = $('#video');
  const canvas = $('#canvas');
  const resultEl = $('#result');
  const camMsg = $('#camMsg');
  const toggle = $('#camToggle');
  let busy = false;
  let lastText = '';
  let lastAt = 0;
  let lastSeen = 0; // last time this same code was visible in the camera view

  async function loadRecent() {
    const el = $('#recent');
    try {
      const data = await listAttendance({ date: todayStr(), limit: 8 });
      el.innerHTML = data.attendance.length
        ? `<ul class="divide-y divide-surface-container">${data.attendance.map((a) => `
            <li class="py-2.5 flex items-center justify-between gap-3">
              <span class="font-label-md text-label-md text-on-surface truncate">${a.member ? escapeHtml(a.member.name) : 'Deleted member'}</span>
              <span class="font-body-sm text-body-sm text-on-surface-variant shrink-0">${formatTime(a.checkedInAt)}</span>
            </li>`).join('')}</ul>`
        : '<p class="font-body-md text-body-md text-on-surface-variant py-3">No check-ins yet.</p>';
    } catch (error) {
      el.innerHTML = `<p class="font-body-sm text-body-sm text-error py-3">${escapeHtml(friendlyErrorMessage(error))}</p>`;
    }
  }

  // Sends the scanned text to the server. The server makes every decision
  // (valid? this gym? membership status? duplicate?) — the browser only displays it.
  async function submit(text) {
    if (busy) return;
    busy = true;
    resultEl.innerHTML = '<p class="font-body-md text-body-md text-on-surface-variant p-4">Checking…</p>';
    try {
      const res = await checkIn(text);
      const who = `${res.member.name} (${res.member.memberCode})`;
      if (res.result === 'duplicate') {
        resultEl.innerHTML = resultCard('warn', 'Already checked in', [who, `Checked in at ${formatTime(res.attendance.checkedInAt)}`]);
      } else {
        resultEl.innerHTML = resultCard(res.membership.status === 'expiring' ? 'warn' : 'ok', 'Checked in', [who, ...describeMembership(res.membership)]);
      }
      loadRecent();
    } catch (error) {
      const d = error.data && error.data.data;
      if (d && d.result === 'denied') {
        resultEl.innerHTML = resultCard('deny', 'Not allowed', [d.member ? `${d.member.name} (${d.member.memberCode})` : '', error.message].filter(Boolean));
      } else if (error.status === 404 || error.status === 400) {
        resultEl.innerHTML = resultCard('deny', 'QR not recognised', [error.message]);
      } else {
        resultEl.innerHTML = resultCard('deny', 'Could not check in', [friendlyErrorMessage(error)]);
      }
    } finally {
      busy = false;
    }
  }

  $('#manualForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const input = $('#manualCode');
    const text = input.value.trim();
    if (!text) return;
    await submit(text);
    input.value = '';
    input.focus();
  });

  // ---------- Camera scanning ----------
  let starting = false;

  async function makeDetector() {
    if ('BarcodeDetector' in window) {
      try {
        const formats = await window.BarcodeDetector.getSupportedFormats();
        if (formats.includes('qr_code')) {
          const bd = new window.BarcodeDetector({ formats: ['qr_code'] });
          return async () => { const found = await bd.detect(video); return found.length ? found[0].rawValue : null; };
        }
      } catch (e) { /* fall through to jsQR */ }
    }
    await loadScript(JSQR_SRC);
    return async () => {
      const w = video.videoWidth; const h = video.videoHeight;
      if (!w || !h) return null;
      canvas.width = w; canvas.height = h;
      const ctx = canvas.getContext('2d', { willReadFrequently: true }); // only when a camera frame is actually scanned
      ctx.drawImage(video, 0, 0, w, h);
      const code = window.jsQR(ctx.getImageData(0, 0, w, h).data, w, h, { inversionAttempts: 'dontInvert' });
      return code ? code.data : null;
    };
  }

  function cameraErrorMessage(error) {
    switch (error && error.name) {
      case 'NotAllowedError':
      case 'SecurityError':
        return 'Camera permission was denied. Allow camera access for this site in your browser settings, then tap Start camera again. You can still use a handheld scanner or type the code below.';
      case 'NotFoundError':
      case 'OverconstrainedError':
        return 'No camera was found on this device. Use a handheld scanner or type the code below.';
      case 'NotReadableError':
      case 'AbortError':
        return 'The camera is being used by another app. Close it and try again.';
      default:
        return 'Could not open the camera. You can still use a handheld scanner or type the code below.';
    }
  }

  function showCameraOff(message = '') {
    video.classList.add('hidden');
    $('#camPlaceholder').classList.remove('hidden');
    $('#camFrame').classList.add('hidden');
    toggle.innerHTML = `${icon('photo_camera', 'text-[20px]')} Start camera`;
    camMsg.textContent = message;
  }

  async function startCamera() {
    if (starting || stream) return;
    camMsg.textContent = '';
    if (!window.isSecureContext || !navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      camMsg.textContent = 'Camera access needs a secure (https) connection and a supported browser. You can still use a handheld scanner or type the code below.';
      return;
    }

    const mine = session;
    starting = true;
    toggle.disabled = true;
    let media;
    try {
      media = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: 'environment' } }, audio: false });
    } catch (error) {
      starting = false; toggle.disabled = false;
      if (mine === session) showCameraOff(cameraErrorMessage(error));
      return;
    }
    // The person left this page while the permission prompt was open: release the camera immediately.
    if (mine !== session) { media.getTracks().forEach((t) => t.stop()); return; }
    stream = media;

    // Phones pause the camera when the tab is hidden; release it properly and make the state clear.
    onVisibility = () => { if (document.hidden && stream) { starting = false; toggle.disabled = false; cleanup(); showCameraOff('Camera paused because the page was hidden. Tap Start camera to resume.'); } };
    document.addEventListener('visibilitychange', onVisibility);

    video.srcObject = stream;
    const played = video.play();
    if (played && played.catch) await played.catch(() => {});
    // The camera may have been released while play() was pending (tab hidden, page left): don't repaint it as "on".
    if (mine !== session) { starting = false; toggle.disabled = false; return; }
    video.classList.remove('hidden');
    $('#camPlaceholder').classList.add('hidden');
    $('#camFrame').classList.remove('hidden');
    toggle.innerHTML = `${icon('videocam_off', 'text-[20px]')} Stop camera`;
    camMsg.textContent = 'Hold the member’s QR code inside the frame.';

    let detect;
    try { detect = await makeDetector(); }
    catch (error) {
      starting = false; toggle.disabled = false;
      if (mine === session) { cleanup(); showCameraOff('Could not load the QR scanner. Reload the page and try again, or use a handheld scanner.'); }
      return;
    }
    starting = false; toggle.disabled = false;
    if (mine !== session) return; // left the page while the scanner loaded (cleanup already ran)

    scanning = true;
    let lastTick = 0;
    const tick = async (now) => {
      if (!scanning || mine !== session) return;
      if (!busy && video.readyState >= 2 && now - lastTick >= SCAN_INTERVAL_MS) {
        lastTick = now;
        try {
          const text = await detect();
          const at = Date.now();
          if (text) {
            // A code that STAYS in view is submitted once (the result card must not flip from "Checked in" to
            // "Already checked in" while the member is still holding the phone up). It is submitted again only
            // after it left the view for 1.5 s, or after 30 s. The server's 5-minute rule still applies either way.
            const stillInView = text === lastText && at - lastSeen < 1500 && at - lastAt < 30000;
            lastSeen = at;
            if (!stillInView) { lastText = text; lastAt = at; await submit(text); lastSeen = Date.now(); }
          }
        } catch (e) { /* a missed frame is fine */ }
      }
      if (scanning && mine === session) rafId = requestAnimationFrame(tick);
    };
    rafId = requestAnimationFrame(tick);
  }

  function stopCamera() {
    cleanup();
    showCameraOff();
  }

  toggle.addEventListener('click', () => (stream ? stopCamera() : startCamera()));

  loadRecent();
}
