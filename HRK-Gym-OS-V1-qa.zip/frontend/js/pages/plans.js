import { listPlans, createPlan, updatePlan, deletePlan } from '../services/planService.js';
import { renderLoading, renderErrorBanner, renderEmptyState } from '../components/states.js';
import { pageShell, field, selectField, errorAlert, showFormError, clearFormError, setBusy, CARD, BTN_PRIMARY, BTN_SECONDARY, icon } from '../components/ui.js';
import { openModal } from '../components/modal.js';
import { confirmDialog } from '../components/confirmModal.js';
import { showToast } from '../components/toast.js';
import { escapeHtml } from '../utils/dom.js';
import { formatINR, friendlyErrorMessage } from '../utils/format.js';

// Quick-fill suggestions only — every value stays editable and gyms can define any plan.
const PRESETS = [
  { name: 'Monthly', durationValue: 1, durationUnit: 'months' },
  { name: 'Quarterly', durationValue: 3, durationUnit: 'months' },
  { name: 'Half-yearly', durationValue: 6, durationUnit: 'months' },
  { name: 'Yearly', durationValue: 12, durationUnit: 'months' }
];

const duration = (p) => `${p.durationValue} ${p.durationUnit === 'days' ? (p.durationValue === 1 ? 'day' : 'days') : (p.durationValue === 1 ? 'month' : 'months')}`;

function openPlanModal(plan, onDone) {
  const p = plan || {};
  const modal = openModal({
    title: plan ? 'Edit plan' : 'New plan',
    bodyHtml: `
      <form id="planForm" class="flex flex-col gap-4" novalidate>
        ${errorAlert()}
        ${plan ? '' : `<div class="flex flex-wrap gap-2" aria-label="Quick fill">${PRESETS.map((x, i) => `<button type="button" data-preset="${i}" class="min-h-[44px] px-4 rounded-full bg-surface-container font-label-md text-label-md hover:bg-surface-container-high">${x.name}</button>`).join('')}</div>`}
        ${field({ id: 'name', label: 'Plan name *', value: p.name || '', attrs: 'required maxlength="80"' })}
        <div class="grid gap-4 grid-cols-2">
          ${field({ id: 'durationValue', label: 'Duration *', type: 'number', value: p.durationValue || '', attrs: 'min="1" step="1" required inputmode="numeric"' })}
          ${selectField({ id: 'durationUnit', label: 'Unit', options: [{ value: 'months', label: 'Months' }, { value: 'days', label: 'Days' }], value: p.durationUnit || 'months' })}
        </div>
        ${field({ id: 'price', label: 'Price (₹) *', type: 'number', value: p.price ?? '', attrs: 'min="0" step="0.01" required inputmode="decimal"' })}
        <label class="flex items-center gap-3 min-h-[44px] cursor-pointer">
          <input id="isActive" type="checkbox" ${p.isActive === false ? '' : 'checked'} class="w-5 h-5 accent-[#006948]"/>
          <span class="font-label-md text-label-md text-on-surface">Active (can be sold to members)</span>
        </label>
        <div class="flex flex-col-reverse sm:flex-row gap-space-sm sm:justify-end pt-1">
          <button type="button" data-close class="${BTN_SECONDARY}">Cancel</button>
          <button id="planSubmit" type="submit" class="${BTN_PRIMARY}">${plan ? 'Save plan' : 'Create plan'}</button>
        </div>
      </form>`
  });
  const form = modal.el.querySelector('#planForm');

  form.querySelectorAll('[data-preset]').forEach((b) => b.addEventListener('click', () => {
    const preset = PRESETS[Number(b.dataset.preset)];
    form.elements.name.value = preset.name;
    form.elements.durationValue.value = preset.durationValue;
    form.elements.durationUnit.value = preset.durationUnit;
  }));

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    clearFormError(modal.el);
    const body = {
      name: form.elements.name.value.trim(),
      durationValue: Number(form.elements.durationValue.value),
      durationUnit: form.elements.durationUnit.value,
      price: form.elements.price.value === '' ? NaN : Number(form.elements.price.value),
      isActive: form.elements.isActive.checked
    };
    if (!body.name) return showFormError(modal.el, 'Give the plan a name.');
    if (!Number.isInteger(body.durationValue) || body.durationValue < 1) return showFormError(modal.el, 'Duration must be a whole number, 1 or more.');
    if (!(body.price >= 0)) return showFormError(modal.el, 'Enter a price (0 or more).');

    const btn = modal.el.querySelector('#planSubmit');
    setBusy(btn, true, 'Saving…');
    try {
      if (plan) await updatePlan(plan._id, body); else await createPlan(body);
      modal.close();
      showToast(plan ? 'Plan updated' : 'Plan created', 'success');
      onDone();
    } catch (error) {
      setBusy(btn, false);
      showFormError(modal.el, friendlyErrorMessage(error));
    }
  });
}

export async function render(container) {
  container.innerHTML = pageShell({ title: 'Membership plans', body: renderLoading('Loading plans…') });

  let plans;
  try {
    plans = await listPlans();
  } catch (error) {
    container.innerHTML = pageShell({ title: 'Membership plans', body: renderErrorBanner({ message: friendlyErrorMessage(error), retryId: 'retryBtn' }) });
    container.querySelector('#retryBtn')?.addEventListener('click', () => render(container));
    return;
  }
  const reload = () => render(container);

  const cards = plans.map((p, i) => `
    <div class="${CARD} p-space-md flex items-center justify-between gap-space-md ${p.isActive ? '' : 'opacity-70'}">
      <div class="min-w-0">
        <div class="flex items-center gap-2 flex-wrap">
          <span class="font-title-sm text-title-sm text-on-surface">${escapeHtml(p.name)}</span>
          ${p.isActive ? '' : '<span class="px-2 py-0.5 rounded-full bg-surface-container-high text-on-surface-variant font-label-sm text-label-sm">Inactive</span>'}
        </div>
        <div class="font-body-md text-body-md text-on-surface-variant">${duration(p)} · ${formatINR(p.price)}</div>
      </div>
      <div class="flex items-center gap-1 shrink-0">
        <button data-edit="${i}" class="min-w-[44px] min-h-[44px] inline-flex items-center justify-center rounded-full hover:bg-surface-container" aria-label="Edit ${escapeHtml(p.name)}">${icon('edit', 'text-[20px]')}</button>
        <button data-del="${i}" class="min-w-[44px] min-h-[44px] inline-flex items-center justify-center rounded-full hover:bg-error-container hover:text-error" aria-label="Delete ${escapeHtml(p.name)}">${icon('delete', 'text-[20px]')}</button>
      </div>
    </div>`).join('');

  container.innerHTML = pageShell({
    title: 'Membership plans',
    subtitle: 'Define what you sell. Changing a plan never changes memberships already sold.',
    actions: `<button id="addPlan" class="${BTN_PRIMARY}">${icon('add', 'text-[20px]')} New plan</button>`,
    body: plans.length
      ? `<div class="grid gap-space-sm md:grid-cols-2">${cards}</div>`
      : renderEmptyState({ icon: 'sell', title: 'No membership plans yet.', message: 'Create a plan such as Monthly or Quarterly, then assign it to members.' })
  });

  container.querySelector('#addPlan').addEventListener('click', () => openPlanModal(null, reload));
  container.querySelectorAll('[data-edit]').forEach((b) => b.addEventListener('click', () => openPlanModal(plans[Number(b.dataset.edit)], reload)));
  container.querySelectorAll('[data-del]').forEach((b) => b.addEventListener('click', async () => {
    const plan = plans[Number(b.dataset.del)];
    const ok = await confirmDialog({ title: `Delete “${plan.name}”?`, message: 'Memberships already sold on this plan are kept. To stop selling it without deleting, mark it inactive instead.', confirmLabel: 'Delete plan' });
    if (!ok) return;
    try { await deletePlan(plan._id); showToast('Plan deleted', 'success'); reload(); }
    catch (error) { showToast(friendlyErrorMessage(error), 'error'); }
  }));
}
