import { getMember, deleteMember, regenerateQr } from '../services/memberService.js';
import { deletePayment } from '../services/paymentService.js';
import { renderLoading, renderErrorBanner } from '../components/states.js';
import { pageShell, statusChip, CARD, BTN_PRIMARY, BTN_SECONDARY, BTN_DANGER, icon } from '../components/ui.js';
import { confirmDialog } from '../components/confirmModal.js';
import { showToast } from '../components/toast.js';
import { renderQr } from '../components/qrCode.js';
import { openMembershipModal } from '../components/membershipModal.js';
import { openPaymentModal } from '../components/paymentModal.js';
import { escapeHtml } from '../utils/dom.js';
import { methodLabel } from '../utils/constants.js';
import { formatDate, formatDateTime, formatINR, friendlyErrorMessage, pluralDays } from '../utils/format.js';

const PERIOD_LABEL = { current: ['active', 'Current'], upcoming: ['upcoming', 'Upcoming'], ended: ['none', 'Ended'] };

function statusLine(ms) {
  if (ms.status === 'active') return `${escapeHtml(ms.planName || 'Membership')} runs until <strong>${formatDate(ms.coverageEnd)}</strong> (${pluralDays(ms.daysLeft)} left).`;
  if (ms.status === 'expiring') return `${escapeHtml(ms.planName || 'Membership')} ends <strong>${formatDate(ms.coverageEnd)}</strong> — ${ms.daysLeft === 0 ? 'last day today' : pluralDays(ms.daysLeft) + ' left'}. Renew to keep access.`;
  if (ms.status === 'expired') return `Membership ended on <strong>${formatDate(ms.lastEndDate)}</strong>. Renew to restore access.`;
  if (ms.status === 'upcoming') return `Next membership starts on <strong>${formatDate(ms.nextStartDate)}</strong>.`;
  return 'No membership assigned yet.';
}

export async function render(container, params) {
  const id = params.id;
  container.innerHTML = pageShell({ title: 'Member', body: renderLoading('Loading member…') });

  let data;
  try {
    data = await getMember(id);
  } catch (error) {
    container.innerHTML = pageShell({
      title: 'Member',
      body: renderErrorBanner({ title: error.status === 404 ? 'Member not found' : 'Something went wrong', message: friendlyErrorMessage(error), retryId: 'retryBtn' })
        + '<p class="mt-space-md"><a class="text-primary font-label-md" href="#/members">← Back to members</a></p>'
    });
    container.querySelector('#retryBtn')?.addEventListener('click', () => render(container, params));
    return;
  }

  const { member, membership, memberships, payments, attendance } = data;
  const hasHistory = memberships.length > 0;
  const reload = () => render(container, params);

  const historyRows = hasHistory
    ? memberships.map((m) => {
        const [st, label] = PERIOD_LABEL[m.period];
        const paid = m.amountPaid >= m.price ? 'Paid' : m.amountPaid > 0 ? `Part-paid (${formatINR(m.amountPaid)})` : 'Payment not recorded';
        return `
          <li class="py-3 flex items-start justify-between gap-space-md">
            <div class="min-w-0">
              <div class="font-label-md text-label-md text-on-surface">${escapeHtml(m.planName)}</div>
              <div class="font-body-sm text-body-sm text-on-surface-variant">${formatDate(m.startDate)} → ${formatDate(m.endDate)}</div>
              <div class="font-body-sm text-body-sm ${m.amountPaid >= m.price ? 'text-on-surface-variant' : 'text-[#8a6100]'}">${formatINR(m.price)} · ${paid}</div>
            </div>
            ${statusChip(st, label)}
          </li>`;
      }).join('')
    : '<p class="font-body-md text-body-md text-on-surface-variant py-3">No membership periods yet.</p>';

  const paymentRows = payments.length
    ? payments.map((p) => `
        <li class="py-3 flex items-center justify-between gap-space-md">
          <div class="min-w-0">
            <div class="font-label-md text-label-md text-on-surface">${formatINR(p.amount)} <span class="text-on-surface-variant font-body-sm">· ${escapeHtml(methodLabel(p.method))}</span></div>
            <div class="font-body-sm text-body-sm text-on-surface-variant">${formatDate(p.paidOn)}${p.note ? ' · ' + escapeHtml(p.note) : ''}</div>
          </div>
          <button type="button" data-del-payment="${p._id}" class="min-w-[44px] min-h-[44px] inline-flex items-center justify-center rounded-full text-on-surface-variant hover:bg-error-container hover:text-error" aria-label="Delete this payment">${icon('delete', 'text-[20px]')}</button>
        </li>`).join('')
    : '<p class="font-body-md text-body-md text-on-surface-variant py-3">No payments recorded yet.</p>';

  const attendanceRows = attendance.length
    ? attendance.map((a) => `<li class="py-2.5 font-body-md text-body-md text-on-surface">${formatDateTime(a.checkedInAt)}</li>`).join('')
    : '<p class="font-body-md text-body-md text-on-surface-variant py-3">No check-ins yet.</p>';

  container.innerHTML = pageShell({
    title: member.name,
    subtitle: `${member.memberCode}${member.phone ? ' · ' + member.phone : ''}${member.email ? ' · ' + member.email : ''}`,
    actions: `
      <button id="msBtn" class="${BTN_PRIMARY}">${icon('autorenew', 'text-[20px]')} ${hasHistory ? 'Renew' : 'Assign plan'}</button>
      <button id="payBtn" class="${BTN_SECONDARY}">${icon('payments', 'text-[20px]')} Record payment</button>
      <a href="#/members/${member._id}/edit" class="${BTN_SECONDARY}">${icon('edit', 'text-[20px]')} Edit</a>`,
    body: `
      <div class="grid gap-space-md lg:grid-cols-3">
        <div class="lg:col-span-2 min-w-0 flex flex-col gap-space-md">
          <section class="${CARD} p-space-md">
            <div class="flex items-center justify-between gap-space-md mb-2">
              <h2 class="font-title-sm text-title-sm text-on-surface">Membership</h2>
              <div class="flex items-center gap-2">${member.status === 'inactive' ? statusChip('none', 'Inactive account') : ''}${statusChip(membership.status)}</div>
            </div>
            <p class="font-body-md text-body-md text-on-surface-variant">${statusLine(membership)}</p>
            ${member.status === 'inactive' ? '<p class="font-body-sm text-body-sm text-error mt-2">This account is inactive, so check-in is blocked until it is set back to active.</p>' : ''}
          </section>

          <section class="${CARD} p-space-md">
            <h2 class="font-title-sm text-title-sm text-on-surface mb-1">Membership history</h2>
            <ul class="divide-y divide-surface-container">${historyRows}</ul>
          </section>

          <section class="${CARD} p-space-md">
            <h2 class="font-title-sm text-title-sm text-on-surface mb-1">Payment history</h2>
            <ul class="divide-y divide-surface-container">${paymentRows}</ul>
          </section>

          <section class="${CARD} p-space-md">
            <h2 class="font-title-sm text-title-sm text-on-surface mb-1">Recent check-ins</h2>
            <ul class="divide-y divide-surface-container">${attendanceRows}</ul>
          </section>
        </div>

        <aside class="min-w-0 flex flex-col gap-space-md">
          <section class="${CARD} p-space-md text-center">
            <h2 class="font-title-sm text-title-sm text-on-surface mb-3">Check-in QR</h2>
            <div id="qr" class="mx-auto w-full max-w-[240px] bg-white rounded-xl p-2 border border-surface-container min-h-[200px]"></div>
            <p class="font-body-sm text-body-sm text-on-surface-variant mt-3">Scan this at the front desk. It contains only a random code, nothing personal.</p>
            <button id="regenBtn" class="mt-2 min-h-[44px] px-3 font-label-md text-label-md text-primary hover:underline">Replace QR code</button>
          </section>
          <section class="${CARD} p-space-md">
            <h2 class="font-title-sm text-title-sm text-on-surface mb-2">Details</h2>
            <dl class="font-body-sm text-body-sm grid grid-cols-[auto_1fr] gap-x-4 gap-y-1.5">
              <dt class="text-on-surface-variant">Joined</dt><dd class="text-on-surface text-right">${formatDate(member.joinedDate)}</dd>
              <dt class="text-on-surface-variant">Gender</dt><dd class="text-on-surface text-right capitalize">${escapeHtml(member.gender || '—')}</dd>
              <dt class="text-on-surface-variant">Date of birth</dt><dd class="text-on-surface text-right">${formatDate(member.dateOfBirth)}</dd>
              <dt class="text-on-surface-variant">Portal login</dt><dd class="text-on-surface text-right">${member.hasPortalLogin ? 'Yes' : 'No'}</dd>
            </dl>
          </section>
          <button id="deleteBtn" class="${BTN_DANGER}">${icon('delete', 'text-[20px]')} Delete member</button>
        </aside>
      </div>
      <p class="mt-space-lg"><a class="text-primary font-label-md" href="#/members">← All members</a></p>`
  });

  renderQr(container.querySelector('#qr'), data.qrPayload);

  container.querySelector('#msBtn').addEventListener('click', () => openMembershipModal({ member, hasHistory, onDone: reload }));
  container.querySelector('#payBtn').addEventListener('click', () => {
    const unpaid = memberships.find((m) => m.amountPaid < m.price);
    openPaymentModal({
      member,
      memberships,
      defaultMembershipId: unpaid ? unpaid._id : '',
      defaultAmount: unpaid ? Math.max(unpaid.price - unpaid.amountPaid, 0) || '' : '',
      onDone: reload
    });
  });

  container.querySelector('#regenBtn').addEventListener('click', async () => {
    const ok = await confirmDialog({ title: 'Replace this QR code?', message: 'The current QR will stop working immediately. Use this if the member lost their phone or shared a screenshot.', confirmLabel: 'Replace QR' });
    if (!ok) return;
    try {
      const res = await regenerateQr(member._id);
      renderQr(container.querySelector('#qr'), res.qrPayload);
      showToast('New QR code generated', 'success');
    } catch (error) { showToast(friendlyErrorMessage(error), 'error'); }
  });

  container.querySelectorAll('[data-del-payment]').forEach((btn) => btn.addEventListener('click', async () => {
    const ok = await confirmDialog({ title: 'Delete this payment?', message: 'Use this only for a payment entered by mistake. It will no longer count in revenue.', confirmLabel: 'Delete payment' });
    if (!ok) return;
    try { await deletePayment(btn.dataset.delPayment); showToast('Payment deleted', 'success'); reload(); }
    catch (error) { showToast(friendlyErrorMessage(error), 'error'); }
  }));

  container.querySelector('#deleteBtn').addEventListener('click', async () => {
    const ok = await confirmDialog({
      title: `Delete ${member.name}?`,
      message: 'This removes the member, their membership history, attendance and portal login. Their payments stay in your payment records. This cannot be undone.',
      confirmLabel: 'Delete member'
    });
    if (!ok) return;
    try { await deleteMember(member._id); showToast('Member deleted', 'success'); window.location.hash = '#/members'; }
    catch (error) { showToast(friendlyErrorMessage(error), 'error'); }
  });
}
