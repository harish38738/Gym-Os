import { getDashboard } from '../services/dashboardService.js';
import { renderLoading, renderErrorBanner, renderEmptyState } from '../components/states.js';
import { pageShell, CARD, BTN_PRIMARY, icon } from '../components/ui.js';
import { escapeHtml } from '../utils/dom.js';
import { formatDate, formatINR, formatNumber, friendlyErrorMessage, pluralDays } from '../utils/format.js';

function metric({ label, value, sub = '', iconName, href, tone = 'text-primary' }) {
  return `
    <a href="${href}" class="${CARD} p-3 sm:p-space-md min-w-0 flex flex-col gap-1 hover:shadow-md transition-shadow">
      <div class="flex items-center justify-between">
        <span class="font-label-md text-label-md text-on-surface-variant">${escapeHtml(label)}</span>
        ${icon(iconName, `text-[20px] ${tone}`)}
      </div>
      <div class="font-metric-val text-[1.25rem] leading-7 sm:text-metric-val sm:leading-8 text-on-surface break-words min-w-0">${value}</div>
      <div class="font-body-sm text-body-sm text-on-surface-variant min-h-[1.25rem]">${sub}</div>
    </a>`;
}

function attentionCard({ title, count, iconName, tone, rows, emptyText, moreHref }) {
  const body = rows.length
    ? `<ul class="divide-y divide-surface-container">${rows.join('')}</ul>`
    : `<p class="font-body-md text-body-md text-on-surface-variant py-space-md">${escapeHtml(emptyText)}</p>`;
  const more = moreHref && count > rows.length
    ? `<a href="${moreHref}" class="block pt-space-sm font-label-md text-label-md text-primary hover:underline">View all ${count}</a>`
    : '';
  return `
    <section class="${CARD} p-space-md">
      <div class="flex items-center gap-2 mb-1">
        ${icon(iconName, `text-[20px] ${tone}`)}
        <h2 class="font-title-sm text-title-sm text-on-surface">${escapeHtml(title)}</h2>
        ${count ? `<span class="ml-auto px-2 py-0.5 rounded-full bg-surface-container font-label-sm text-label-sm">${count}</span>` : ''}
      </div>
      ${body}${more}
    </section>`;
}

const memberRow = (entry, right) => `
  <li>
    <a href="#/members/${entry.memberId}" class="flex items-center justify-between gap-space-md py-3 hover:bg-surface-container-low -mx-2 px-2 rounded-lg">
      <div class="min-w-0">
        <div class="font-label-md text-label-md text-on-surface truncate">${escapeHtml(entry.name)}</div>
        <div class="font-body-sm text-body-sm text-on-surface-variant truncate">${escapeHtml(entry.memberCode)}${entry.phone ? ' · ' + escapeHtml(entry.phone) : ''}</div>
      </div>
      <div class="text-right shrink-0 font-body-sm text-body-sm">${right}</div>
    </a>
  </li>`;

export async function render(container) {
  container.innerHTML = pageShell({ title: 'Dashboard', body: renderLoading('Loading your gym…') });

  let data;
  try {
    data = await getDashboard();
  } catch (error) {
    container.innerHTML = pageShell({
      title: 'Dashboard',
      body: renderErrorBanner({ message: friendlyErrorMessage(error), retryId: 'retryBtn' })
    });
    container.querySelector('#retryBtn')?.addEventListener('click', () => render(container));
    return;
  }

  const t = data.totals;
  const a = data.attention;

  // Brand-new gym: guide the owner instead of showing a wall of zeros.
  if (t.totalMembers === 0) {
    container.innerHTML = pageShell({
      title: 'Dashboard',
      subtitle: formatDate(data.date),
      body: renderEmptyState({
        icon: 'group_add',
        title: 'Your gym has no members yet.',
        message: 'Add your first member, or set up your membership plans first. The dashboard fills in as you use it.',
        actionLabel: 'Add a member',
        actionHref: '#/members/new'
      }) + `<div class="text-center mt-space-md"><a href="#/plans" class="inline-flex items-center min-h-[44px] px-2 font-label-md text-label-md text-primary hover:underline">Set up membership plans</a></div>`
    });
    return;
  }

  const expiringRows = a.expiring.map((e) => memberRow(e, `<span class="font-label-md text-label-md text-[#5c4300]">${e.daysLeft === 0 ? 'Last day today' : pluralDays(e.daysLeft) + ' left'}</span><div class="text-on-surface-variant">ends ${formatDate(e.endDate)}</div>`));
  const expiredRows = a.expired.map((e) => memberRow(e, `<span class="font-label-md text-label-md text-error">Expired ${pluralDays(e.daysAgo)} ago</span><div class="text-on-surface-variant">${formatDate(e.endDate)}</div>`));
  const unpaidRows = a.unpaid.map((u) => memberRow({ ...u }, `<span class="font-label-md text-label-md text-on-surface">${escapeHtml(u.planName)}</span><div class="text-on-surface-variant">${formatINR(u.price)} · no payment recorded</div>`));

  container.innerHTML = pageShell({
    title: 'Dashboard',
    subtitle: `Today, ${formatDate(data.date)}`,
    actions: `<a href="#/checkin" class="${BTN_PRIMARY}">${icon('qr_code_scanner', 'text-[20px]')} Check-in</a>`,
    body: `
      <div class="grid grid-cols-2 lg:grid-cols-5 gap-space-md mb-space-lg">
        ${metric({ label: 'Total members', value: formatNumber(t.totalMembers), sub: t.inactiveMembers ? `${t.inactiveMembers} inactive` : '', iconName: 'group', href: '#/members' })}
        ${metric({ label: 'Active memberships', value: formatNumber(t.activeMemberships), sub: `${t.expiredMembers} expired`, iconName: 'verified', href: '#/members?status=active' })}
        ${metric({ label: 'Expiring soon', value: formatNumber(t.expiringMemberships), sub: `within ${data.expiringWithinDays} days`, iconName: 'schedule', href: '#/members?status=expiring', tone: 'text-[#8a6100]' })}
        ${metric({ label: "Today's check-ins", value: formatNumber(t.todayCheckIns), iconName: 'event_available', href: '#/attendance' })}
        ${metric({ label: "Today's revenue", value: formatINR(t.todayRevenue), iconName: 'payments', href: '#/payments' })}
      </div>

      <h2 class="font-headline-md text-headline-md text-on-surface mb-space-sm">Needs attention</h2>
      <div class="grid gap-space-md lg:grid-cols-3">
        ${attentionCard({ title: 'Expiring soon', count: a.expiringCount, iconName: 'schedule', tone: 'text-[#8a6100]', rows: expiringRows, emptyText: 'No memberships expiring in the next ' + data.expiringWithinDays + ' days.', moreHref: '#/members?status=expiring' })}
        ${attentionCard({ title: 'Expired', count: a.expiredCount, iconName: 'event_busy', tone: 'text-error', rows: expiredRows, emptyText: 'No expired memberships.', moreHref: '#/members?status=expired' })}
        ${attentionCard({ title: 'Payment not recorded', count: a.unpaidCount, iconName: 'receipt_long', tone: 'text-secondary', rows: unpaidRows, emptyText: 'Every running membership has a payment recorded.', moreHref: '' })}
      </div>`
  });
}
