import { logout } from '../services/authService.js';
import { pageShell, CARD, icon } from '../components/ui.js';

const ITEMS = [
  { href: '#/attendance', icon: 'event_available', label: 'Attendance', hint: 'Today and past check-ins' },
  { href: '#/plans', icon: 'sell', label: 'Membership plans', hint: 'Prices and durations' },
  { href: '#/members/import', icon: 'upload_file', label: 'Import members', hint: 'Bring members in from a CSV file' },
  { href: '#/gym', icon: 'storefront', label: 'Gym profile', hint: 'Name, phone and address' }
];

export function render(container) {
  container.innerHTML = pageShell({
    title: 'More',
    body: `
      <div class="grid gap-space-sm max-w-xl">
        ${ITEMS.map((i) => `
          <a href="${i.href}" class="${CARD} p-space-md flex items-center gap-space-md hover:shadow-md transition-shadow">
            <span class="w-11 h-11 rounded-xl bg-primary-container/10 text-primary flex items-center justify-center">${icon(i.icon)}</span>
            <span class="flex-1 min-w-0"><span class="block font-title-sm text-title-sm text-on-surface">${i.label}</span><span class="block font-body-sm text-body-sm text-on-surface-variant">${i.hint}</span></span>
            ${icon('chevron_right', 'text-outline')}
          </a>`).join('')}
        <button id="logout" class="${CARD} p-space-md flex items-center gap-space-md text-left hover:shadow-md transition-shadow">
          <span class="w-11 h-11 rounded-xl bg-error-container text-error flex items-center justify-center">${icon('logout')}</span>
          <span class="font-title-sm text-title-sm text-on-surface">Log out</span>
        </button>
      </div>`
  });
  container.querySelector('#logout').addEventListener('click', () => { logout(); window.location.hash = '#/login'; });
}
