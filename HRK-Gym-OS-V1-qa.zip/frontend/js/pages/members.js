import { listMembers } from '../services/memberService.js';
import { renderLoading, renderErrorBanner, renderEmptyState } from '../components/states.js';
import { pageShell, statusChip, pager, INPUT_CLS, CARD, BTN_PRIMARY, BTN_SECONDARY, icon } from '../components/ui.js';
import { escapeHtml, debounce, hashQuery } from '../utils/dom.js';
import { formatDate, friendlyErrorMessage, pluralDays } from '../utils/format.js';

const STATUS_FILTERS = [
  { value: '', label: 'All memberships' },
  { value: 'active', label: 'Active' },
  { value: 'expiring', label: 'Expiring' },
  { value: 'expired', label: 'Expired' },
  { value: 'upcoming', label: 'Starts soon' },
  { value: 'none', label: 'No membership' }
];

function validity(m) {
  const s = m.membership;
  if (s.status === 'active' || s.status === 'expiring') return `${s.planName ? escapeHtml(s.planName) + ' · ' : ''}until ${formatDate(s.coverageEnd)}${s.status === 'expiring' ? ` (${s.daysLeft === 0 ? 'last day' : pluralDays(s.daysLeft) + ' left'})` : ''}`;
  if (s.status === 'expired') return `Ended ${formatDate(s.lastEndDate)}`;
  if (s.status === 'upcoming') return `Starts ${formatDate(s.nextStartDate)}`;
  return '—';
}

export async function render(container) {
  const q = hashQuery();
  const state = { search: '', status: STATUS_FILTERS.some((f) => f.value === q.status) ? q.status || '' : '', accountStatus: '', page: 1 };

  container.innerHTML = pageShell({
    title: 'Members',
    actions: `
      <a href="#/members/import" class="${BTN_SECONDARY}">${icon('upload_file', 'text-[20px]')} Import CSV</a>
      <a href="#/members/new" class="${BTN_PRIMARY}">${icon('person_add', 'text-[20px]')} Add member</a>`,
    body: `
      <div class="grid gap-space-sm sm:grid-cols-[1fr_auto_auto] mb-space-md">
        <div class="relative">
          <span class="material-symbols-outlined absolute left-3.5 top-1/2 -translate-y-1/2 text-outline pointer-events-none">search</span>
          <input id="search" type="search" placeholder="Search name, phone or ID" class="${INPUT_CLS} pl-11" aria-label="Search members"/>
        </div>
        <select id="statusFilter" class="${INPUT_CLS}" aria-label="Filter by membership status">
          ${STATUS_FILTERS.map((f) => `<option value="${f.value}" ${f.value === state.status ? 'selected' : ''}>${f.label}</option>`).join('')}
        </select>
        <select id="accountFilter" class="${INPUT_CLS}" aria-label="Filter by account status">
          <option value="">Active & inactive</option>
          <option value="active">Active accounts</option>
          <option value="inactive">Inactive accounts</option>
        </select>
      </div>
      <div id="list"></div>`
  });

  const list = container.querySelector('#list');

  async function load() {
    list.innerHTML = renderLoading('Loading members…');
    let data;
    try {
      data = await listMembers({ search: state.search, status: state.status, accountStatus: state.accountStatus, page: state.page, limit: 20 });
    } catch (error) {
      list.innerHTML = renderErrorBanner({ message: friendlyErrorMessage(error), retryId: 'retryBtn' });
      list.querySelector('#retryBtn')?.addEventListener('click', load);
      return;
    }

    const filtered = state.search || state.status || state.accountStatus;
    if (!data.members.length) {
      list.innerHTML = filtered
        ? renderEmptyState({ icon: 'search_off', title: 'No members match your search.', message: 'Try a different name or clear the filters.' })
        : renderEmptyState({ icon: 'group_add', title: 'Your gym has no members yet.', message: 'Add your first member to get started.', actionLabel: 'Add a member', actionHref: '#/members/new' });
      return;
    }

    const rows = data.members.map((m) => `
      <a href="#/members/${m._id}" class="${CARD} p-space-md flex items-center justify-between gap-space-md hover:shadow-md transition-shadow">
        <div class="min-w-0">
          <div class="flex items-center gap-2 flex-wrap">
            <span class="font-title-sm text-title-sm text-on-surface truncate">${escapeHtml(m.name)}</span>
            ${m.status === 'inactive' ? '<span class="px-2 py-0.5 rounded-full bg-surface-container-high text-on-surface-variant font-label-sm text-label-sm">Inactive</span>' : ''}
          </div>
          <div class="font-body-sm text-body-sm text-on-surface-variant truncate">${escapeHtml(m.memberCode)}${m.phone ? ' · ' + escapeHtml(m.phone) : ''}${m.email ? ' · ' + escapeHtml(m.email) : ''}</div>
          <div class="font-body-sm text-body-sm text-on-surface-variant mt-0.5">${validity(m)}</div>
        </div>
        <div class="shrink-0">${statusChip(m.membership.status)}</div>
      </a>`).join('');

    list.innerHTML = `<div class="grid gap-space-sm md:grid-cols-2">${rows}</div>${pager(data.pagination)}`;
    list.querySelectorAll('[data-page]').forEach((b) => b.addEventListener('click', () => { state.page = Number(b.dataset.page); load(); window.scrollTo(0, 0); }));
  }

  container.querySelector('#search').addEventListener('input', debounce((e) => { state.search = e.target.value.trim(); state.page = 1; load(); }));
  container.querySelector('#statusFilter').addEventListener('change', (e) => { state.status = e.target.value; state.page = 1; load(); });
  container.querySelector('#accountFilter').addEventListener('change', (e) => { state.accountStatus = e.target.value; state.page = 1; load(); });

  load();
}
