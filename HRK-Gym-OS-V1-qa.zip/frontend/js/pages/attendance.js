import { listAttendance } from '../services/attendanceService.js';
import { renderLoading, renderErrorBanner, renderEmptyState } from '../components/states.js';
import { pageShell, pager, statusChip, INPUT_CLS, CARD, BTN_PRIMARY, icon } from '../components/ui.js';
import { escapeHtml, debounce } from '../utils/dom.js';
import { formatDate, formatTime, formatDateTime, todayStr, friendlyErrorMessage } from '../utils/format.js';

export async function render(container) {
  const state = { date: todayStr(), search: '', page: 1 };

  container.innerHTML = pageShell({
    title: 'Attendance',
    actions: `<a href="#/checkin" class="${BTN_PRIMARY}">${icon('qr_code_scanner', 'text-[20px]')} Check-in</a>`,
    body: `
      <div class="grid gap-space-sm sm:grid-cols-[1fr_auto_auto] mb-space-md">
        <div class="relative">
          <span class="material-symbols-outlined absolute left-3.5 top-1/2 -translate-y-1/2 text-outline pointer-events-none">search</span>
          <input id="search" type="search" placeholder="Search by member" class="${INPUT_CLS} pl-11" aria-label="Search attendance by member"/>
        </div>
        <input id="date" type="date" value="${state.date}" class="${INPUT_CLS}" aria-label="Date"/>
        <button id="allDates" type="button" class="h-12 px-4 rounded-xl bg-surface-container text-on-surface font-label-md text-label-md hover:bg-surface-container-high">All dates</button>
      </div>
      <div id="list"></div>`
  });
  const list = container.querySelector('#list');
  const dateInput = container.querySelector('#date');

  async function load() {
    list.innerHTML = renderLoading('Loading attendance…');
    let data;
    try {
      data = await listAttendance({ date: state.date, search: state.search, page: state.page, limit: 25 });
    } catch (error) {
      list.innerHTML = renderErrorBanner({ message: friendlyErrorMessage(error), retryId: 'retryBtn' });
      list.querySelector('#retryBtn')?.addEventListener('click', load);
      return;
    }

    const isToday = state.date === todayStr();
    if (!data.attendance.length) {
      list.innerHTML = renderEmptyState({
        icon: 'event_available',
        title: state.search ? 'No check-ins match your search.' : isToday ? 'No check-ins yet today.' : state.date ? `No check-ins on ${formatDate(state.date)}.` : 'No check-ins yet.',
        message: 'Check-ins appear here as members scan their QR code at the front desk.',
        actionLabel: isToday ? 'Open check-in' : '',
        actionHref: '#/checkin'
      });
      return;
    }

    const rows = data.attendance.map((a) => `
      <div class="${CARD} p-space-md flex items-center justify-between gap-space-md">
        <div class="min-w-0">
          <div class="font-title-sm text-title-sm text-on-surface truncate">
            ${a.member ? `<a class="hover:underline" href="#/members/${a.member._id}">${escapeHtml(a.member.name)}</a>` : '<span class="text-on-surface-variant">Deleted member</span>'}
          </div>
          <div class="font-body-sm text-body-sm text-on-surface-variant">${a.member ? escapeHtml(a.member.memberCode) + ' · ' : ''}${state.date ? formatTime(a.checkedInAt) : formatDateTime(a.checkedInAt)}</div>
        </div>
        ${a.membershipStatus === 'expiring' ? statusChip('expiring', 'Expiring') : ''}
      </div>`).join('');

    list.innerHTML = `
      <p class="font-label-md text-label-md text-on-surface-variant mb-space-sm">${data.pagination.total} check-in${data.pagination.total === 1 ? '' : 's'}${state.date ? ' on ' + (isToday ? 'today' : formatDate(state.date)) : ' in total'}</p>
      <div class="grid gap-space-sm md:grid-cols-2">${rows}</div>${pager(data.pagination)}`;
    list.querySelectorAll('[data-page]').forEach((b) => b.addEventListener('click', () => { state.page = Number(b.dataset.page); load(); window.scrollTo(0, 0); }));
  }

  container.querySelector('#search').addEventListener('input', debounce((e) => { state.search = e.target.value.trim(); state.page = 1; load(); }));
  dateInput.addEventListener('change', () => { state.date = dateInput.value; state.page = 1; load(); });
  container.querySelector('#allDates').addEventListener('click', () => { state.date = ''; dateInput.value = ''; state.page = 1; load(); });

  load();
}
