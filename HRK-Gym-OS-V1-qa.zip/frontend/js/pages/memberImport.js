import { importMembers } from '../services/memberService.js';
import { csvToMemberRows, SAMPLE_CSV } from '../utils/csv.js';
import { pageShell, errorAlert, showFormError, clearFormError, setBusy, CARD, BTN_PRIMARY, BTN_SECONDARY, icon } from '../components/ui.js';
import { showToast } from '../components/toast.js';
import { escapeHtml } from '../utils/dom.js';
import { friendlyErrorMessage } from '../utils/format.js';

const MAX_ROWS = 500;
const CHIP = {
  valid: 'bg-primary-fixed text-on-primary-fixed',
  imported: 'bg-primary-fixed text-on-primary-fixed',
  duplicate: 'bg-[#ffe9b8] text-[#5c4300]',
  error: 'bg-error-container text-on-error-container'
};
const LABEL = { valid: 'Ready', imported: 'Imported', duplicate: 'Duplicate – skipped', error: 'Error – skipped' };

export function render(container) {
  container.innerHTML = pageShell({
    title: 'Import members',
    subtitle: 'Upload a CSV, check the preview, then import. Nothing is saved until you confirm.',
    body: `
      <div class="${CARD} p-space-lg max-w-3xl flex flex-col gap-5">
        ${errorAlert()}
        <div>
          <p class="font-body-md text-body-md text-on-surface">Your file needs a header row. Columns: <strong>name</strong> (required), <strong>phone</strong> or <strong>email</strong> (one is required), and optionally gender, date of birth, joined date. Dates must be written <strong>YYYY-MM-DD</strong>.</p>
          <button id="sample" type="button" class="mt-1 min-h-[44px] inline-flex items-center font-label-md text-label-md text-primary hover:underline">Download a sample file</button>
        </div>
        <div>
          <label for="file" class="${BTN_SECONDARY} cursor-pointer">${icon('upload_file', 'text-[20px]')} Choose CSV file</label>
          <input id="file" type="file" accept=".csv,text/csv" class="sr-only"/>
          <span id="fileName" class="ml-3 font-body-sm text-body-sm text-on-surface-variant"></span>
        </div>
        <div id="preview"></div>
      </div>
      <p class="mt-space-md"><a class="text-primary font-label-md" href="#/members">← All members</a></p>`
  });

  const $ = (s) => container.querySelector(s);
  const preview = $('#preview');
  let rows = [];

  $('#sample').addEventListener('click', () => {
    const url = URL.createObjectURL(new Blob([SAMPLE_CSV], { type: 'text/csv' }));
    const a = document.createElement('a');
    a.href = url; a.download = 'members-sample.csv';
    document.body.appendChild(a); a.click(); a.remove();
    URL.revokeObjectURL(url);
  });

  function renderResults(data, done) {
    const s = data.summary;
    const head = done
      ? `<div class="p-3 rounded-lg bg-primary-fixed text-on-primary-fixed font-label-md text-label-md">${s.imported} member${s.imported === 1 ? '' : 's'} imported · ${s.duplicates} duplicate${s.duplicates === 1 ? '' : 's'} skipped · ${s.errors} with errors skipped</div>`
      : `<div class="font-label-md text-label-md text-on-surface">${s.valid} ready to import · ${s.duplicates} duplicate${s.duplicates === 1 ? '' : 's'} · ${s.errors} with errors <span class="text-on-surface-variant">(of ${s.total})</span></div>`;
    const list = data.results.map((r) => `
      <li class="py-2.5 flex items-start justify-between gap-3">
        <div class="min-w-0">
          <div class="font-label-md text-label-md text-on-surface truncate">Row ${r.line}${r.name ? ' · ' + escapeHtml(r.name) : ''}</div>
          ${r.message ? `<div class="font-body-sm text-body-sm text-on-surface-variant">${escapeHtml(r.message)}</div>` : ''}
        </div>
        <span class="shrink-0 px-2.5 py-1 rounded-full font-label-sm text-label-sm ${CHIP[r.status]}">${LABEL[r.status]}</span>
      </li>`).join('');
    return `${head}<ul class="divide-y divide-surface-container max-h-[50vh] overflow-y-auto mt-3">${list}</ul>`;
  }

  $('#file').addEventListener('change', async (e) => {
    clearFormError(container);
    preview.innerHTML = '';
    const file = e.target.files[0];
    $('#fileName').textContent = file ? file.name : '';
    if (!file) return;
    if (file.size > 2 * 1024 * 1024) return showFormError(container, 'That file is too large. Keep it under 2 MB.');

    const parsed = csvToMemberRows(await file.text());
    if (!parsed.rows.length) return showFormError(container, 'The file has no member rows. It needs a header row and at least one member.');
    if (parsed.missingName) return showFormError(container, 'No “name” column found. The first row must contain column names, including “name”.');
    if (parsed.rows.length > MAX_ROWS) return showFormError(container, `This file has ${parsed.rows.length} rows. Import at most ${MAX_ROWS} at a time — split the file.`);
    rows = parsed.rows;

    preview.innerHTML = '<p class="font-body-md text-body-md text-on-surface-variant">Checking rows…</p>';
    try {
      const data = await importMembers(rows, true);
      const canImport = data.summary.valid > 0;
      preview.innerHTML = `
        ${renderResults(data, false)}
        <div class="flex flex-col-reverse sm:flex-row gap-space-sm sm:justify-end mt-space-md">
          <button id="cancel" type="button" class="${BTN_SECONDARY}">Cancel</button>
          <button id="confirm" type="button" class="${BTN_PRIMARY}" ${canImport ? '' : 'disabled'}>Import ${data.summary.valid} member${data.summary.valid === 1 ? '' : 's'}</button>
        </div>`;
      $('#cancel').addEventListener('click', () => { preview.innerHTML = ''; $('#file').value = ''; $('#fileName').textContent = ''; });
      $('#confirm').addEventListener('click', async () => {
        const btn = $('#confirm');
        setBusy(btn, true, 'Importing…');
        try {
          const done = await importMembers(rows, false);
          preview.innerHTML = `${renderResults(done, true)}<div class="mt-space-md"><a href="#/members" class="${BTN_PRIMARY}">View members</a></div>`;
          showToast(`${done.summary.imported} members imported`, 'success');
        } catch (error) {
          setBusy(btn, false);
          showFormError(container, friendlyErrorMessage(error));
        }
      });
    } catch (error) {
      preview.innerHTML = '';
      showFormError(container, friendlyErrorMessage(error));
    }
  });
}
