import { getOverview } from '../services/portalService.js';
import { renderLoading, renderErrorBanner } from '../components/states.js';
import { pageShell, statusChip, CARD } from '../components/ui.js';
import { renderQr } from '../components/qrCode.js';
import { escapeHtml } from '../utils/dom.js';
import { formatDate, formatINR, friendlyErrorMessage, pluralDays } from '../utils/format.js';

const PERIOD = { current: ['active', 'Current'], upcoming: ['upcoming', 'Upcoming'], ended: ['none', 'Ended'] };

function statusText(ms) {
  if (ms.status === 'active') return `${escapeHtml(ms.planName || 'Membership')} · valid until ${formatDate(ms.coverageEnd)} (${pluralDays(ms.daysLeft)} left)`;
  if (ms.status === 'expiring') return `${escapeHtml(ms.planName || 'Membership')} · ends ${formatDate(ms.coverageEnd)} (${ms.daysLeft === 0 ? 'last day today' : pluralDays(ms.daysLeft) + ' left'}). Please renew at the front desk.`;
  if (ms.status === 'expired') return `Your membership ended on ${formatDate(ms.lastEndDate)}. Please renew at the front desk.`;
  if (ms.status === 'upcoming') return `Your membership starts on ${formatDate(ms.nextStartDate)}.`;
  return 'You don’t have a membership yet. Please speak to the front desk.';
}

export async function render(container) {
  container.innerHTML = pageShell({ title: 'My membership', body: renderLoading('Loading…') });

  let data;
  try {
    data = await getOverview();
  } catch (error) {
    container.innerHTML = pageShell({ title: 'My membership', body: renderErrorBanner({ message: friendlyErrorMessage(error), retryId: 'retryBtn' }) });
    container.querySelector('#retryBtn')?.addEventListener('click', () => render(container));
    return;
  }

  const { member, gym, membership, memberships } = data;
  const canEnter = membership.status === 'active' || membership.status === 'expiring';

  const history = memberships.length
    ? `<ul class="divide-y divide-surface-container">${memberships.map((m) => {
        const [st, label] = PERIOD[m.period];
        return `<li class="py-3 flex items-center justify-between gap-space-md">
          <div class="min-w-0"><div class="font-label-md text-label-md text-on-surface">${escapeHtml(m.planName)}</div>
          <div class="font-body-sm text-body-sm text-on-surface-variant">${formatDate(m.startDate)} → ${formatDate(m.endDate)} · ${formatINR(m.price)}</div></div>
          ${statusChip(st, label)}</li>`;
      }).join('')}</ul>`
    : '<p class="font-body-md text-body-md text-on-surface-variant py-2">No memberships yet.</p>';

  container.innerHTML = pageShell({
    title: `Hi, ${member.name.split(' ')[0]}`,
    subtitle: gym ? gym.name : '',
    body: `
      <div class="max-w-xl mx-auto flex flex-col gap-space-md">
        <section class="${CARD} p-space-md">
          <div class="flex items-center justify-between gap-space-md mb-2">
            <h2 class="font-title-sm text-title-sm text-on-surface">Membership</h2>
            ${statusChip(membership.status)}
          </div>
          <p class="font-body-md text-body-md text-on-surface-variant">${statusText(membership)}</p>
        </section>

        <section class="${CARD} p-space-md text-center">
          <h2 class="font-title-sm text-title-sm text-on-surface mb-1">Your check-in QR</h2>
          <p class="font-body-sm text-body-sm text-on-surface-variant mb-3">${canEnter ? 'Show this at the front desk when you arrive.' : 'Your membership is not active right now, so check-in will be declined until you renew.'}</p>
          <div id="qr" class="mx-auto w-full max-w-[280px] bg-white rounded-xl p-3 border border-surface-container min-h-[220px]"></div>
          <p class="font-label-md text-label-md text-on-surface-variant mt-3">${escapeHtml(member.memberCode)}</p>
        </section>

        <section class="${CARD} p-space-md">
          <h2 class="font-title-sm text-title-sm text-on-surface mb-1">Membership history</h2>
          ${history}
        </section>
        ${gym && (gym.phone || gym.address) ? `<p class="font-body-sm text-body-sm text-on-surface-variant text-center">${gym.phone ? 'Contact: ' + escapeHtml(gym.phone) : ''}${gym.phone && gym.address ? ' · ' : ''}${escapeHtml(gym.address || '')}</p>` : ''}
      </div>`
  });

  renderQr(container.querySelector('#qr'), data.qrPayload);
}
