import { listPayments, deletePayment } from '../services/paymentService.js';
import { renderLoading, renderErrorBanner, renderEmptyState } from '../components/states.js';
import { pageShell, pager, INPUT_CLS, CARD, BTN_PRIMARY, icon } from '../components/ui.js';
import { openMemberPicker } from '../components/memberPicker.js';
import { openPaymentModal } from '../components/paymentModal.js';
import { confirmDialog } from '../components/confirmModal.js';
import { showToast } from '../components/toast.js';
import { escapeHtml, debounce } from '../utils/dom.js';
import { PAYMENT_METHODS, methodLabel } from '../utils/constants.js';
import { formatDate, formatINR, friendlyErrorMessage } from '../utils/format.js';

export async function render(container) {
  const state = { search: '', method: '', from: '', to: '', page: 1 };

  container.innerHTML = pageShell({
    title: 'Payments',
    actions: `<button id="addPayment" class="${BTN_PRIMARY}">${icon('add', 'text-[20px]')} Record payment</button>`,
    body: `
      <div class="grid gap-space-sm sm:grid-cols-2 lg:grid-cols-[1fr_auto_auto_auto] mb-space-md">
        <div class="relative">
          <span class="material-symbols-outlined absolute left-3.5 top-1/2 -translate-y-1/2 text-outline pointer-events-none">search</span>
          <input id="search" type="search" placeholder="Search by member" class="${INPUT_CLS} pl-11" aria-label="Search payments by member"/>
        </div>
        <select id="method" class="${INPUT_CLS}" aria-label="Payment method">
          <option value="">All methods</option>
          ${PAYMENT_METHODS.map((m) => `<option value="${m.value}">${m.label}</option>`).join('')}
        </select>
        <label class="flex items-center gap-2 font-body-sm text-body-sm text-on-surface-variant">From <input id="from" type="date" class="${INPUT_CLS}"/></label>
        <label class="flex items-center gap-2 font-body-sm text-body-sm text-on-surface-variant">To <input id="to" type="date" class="${INPUT_CLS}"/></label>
      </div>
      <div id="list"></div>`
  });
  const list = container.querySelector('#list');

  async function load() {
    list.innerHTML = renderLoading('Loading payments…');
    let data;
    try {
      data = await listPayments({ ...state, limit: 20 });
    } catch (error) {
      list.innerHTML = renderErrorBanner({ message: friendlyErrorMessage(error), retryId: 'retryBtn' });
      list.querySelector('#retryBtn')?.addEventListener('click', load);
      return;
    }

    if (!data.payments.length) {
      const filtered = state.search || state.method || state.from || state.to;
      list.innerHTML = renderEmptyState({
        icon: 'payments',
        title: filtered ? 'No payments match these filters.' : 'No payments recorded yet.',
        message: filtered ? 'Try widening the dates or clearing the search.' : 'Record a payment when a member pays for a membership.'
      });
      return;
    }

    const rows = data.payments.map((p) => `
      <div class="${CARD} p-space-md flex items-center justify-between gap-space-md">
        <div class="min-w-0">
          <div class="font-title-sm text-title-sm text-on-surface">${formatINR(p.amount)}</div>
          <div class="font-body-md text-body-md text-on-surface truncate">
            ${p.member && p.member._id ? `<a class="text-primary hover:underline inline-block py-2.5 -my-2.5" href="#/members/${p.member._id}">${escapeHtml(p.member.name)}</a>` : `${escapeHtml(p.member.name)} <span class="text-on-surface-variant">(deleted member)</span>`}
          </div>
          <div class="font-body-sm text-body-sm text-on-surface-variant">${formatDate(p.paidOn)} · ${escapeHtml(methodLabel(p.method))}${p.note ? ' · ' + escapeHtml(p.note) : ''}</div>
        </div>
        <button data-del="${p._id}" class="min-w-[44px] min-h-[44px] inline-flex items-center justify-center rounded-full text-on-surface-variant hover:bg-error-container hover:text-error shrink-0" aria-label="Delete this payment">${icon('delete', 'text-[20px]')}</button>
      </div>`).join('');

    list.innerHTML = `
      <div class="${CARD} p-space-md mb-space-md flex flex-wrap items-center justify-between gap-2">
        <span class="font-label-md text-label-md text-on-surface-variant">Total of ${data.pagination.total} payment${data.pagination.total === 1 ? '' : 's'}${state.search || state.method || state.from || state.to ? ' (filtered)' : ''}</span>
        <span class="font-metric-val text-[1.375rem] sm:text-metric-val text-on-surface break-words">${formatINR(data.totalAmount)}</span>
      </div>
      <div class="grid gap-space-sm md:grid-cols-2">${rows}</div>${pager(data.pagination)}`;

    list.querySelectorAll('[data-page]').forEach((b) => b.addEventListener('click', () => { state.page = Number(b.dataset.page); load(); window.scrollTo(0, 0); }));
    list.querySelectorAll('[data-del]').forEach((b) => b.addEventListener('click', async () => {
      const ok = await confirmDialog({ title: 'Delete this payment?', message: 'Use this only for a payment entered by mistake. It will no longer count in revenue.', confirmLabel: 'Delete payment' });
      if (!ok) return;
      try { await deletePayment(b.dataset.del); showToast('Payment deleted', 'success'); load(); }
      catch (error) { showToast(friendlyErrorMessage(error), 'error'); }
    }));
  }

  const bind = (id, key, ev = 'change') => container.querySelector(id).addEventListener(ev, (e) => { state[key] = e.target.value; state.page = 1; load(); });
  container.querySelector('#search').addEventListener('input', debounce((e) => { state.search = e.target.value.trim(); state.page = 1; load(); }));
  bind('#method', 'method'); bind('#from', 'from'); bind('#to', 'to');

  container.querySelector('#addPayment').addEventListener('click', () => {
    openMemberPicker({ title: 'Record payment for…', onPick: (member) => openPaymentModal({ member, onDone: load }) });
  });

  load();
}
