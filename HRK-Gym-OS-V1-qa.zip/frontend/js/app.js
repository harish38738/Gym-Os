import { isAuthenticated, getRole, onAuthChange, getGym } from './state/store.js';
import { renderHeader, renderBottomNav, homeRouteFor } from './components/nav.js';
import { logout, refreshProfile } from './services/authService.js';

import * as loginPage from './pages/login.js';
import * as registerPage from './pages/register.js';
import * as dashboardPage from './pages/dashboard.js';
import * as membersPage from './pages/members.js';
import * as memberFormPage from './pages/memberForm.js';
import * as memberDetailPage from './pages/memberDetail.js';
import * as memberImportPage from './pages/memberImport.js';
import * as plansPage from './pages/plans.js';
import * as paymentsPage from './pages/payments.js';
import * as attendancePage from './pages/attendance.js';
import * as checkinPage from './pages/checkin.js';
import * as gymPage from './pages/gym.js';
import * as morePage from './pages/more.js';
import * as portalHomePage from './pages/portalHome.js';
import * as portalAttendancePage from './pages/portalAttendance.js';
import * as portalPaymentsPage from './pages/portalPayments.js';

// Each route: a path pattern (":id" = param), which nav item it highlights, the
// page module, the role allowed to see it (null = public) and whether the app
// shell (header + bottom nav) is shown. Specific patterns come before ":id" ones.
const ROUTES = [
  { pattern: 'login', navKey: null, page: loginPage, role: null, shell: false },
  { pattern: 'register', navKey: null, page: registerPage, role: null, shell: false },

  { pattern: 'dashboard', navKey: 'dashboard', page: dashboardPage, role: 'admin', shell: true },
  { pattern: 'members', navKey: 'members', page: membersPage, role: 'admin', shell: true },
  { pattern: 'members/new', navKey: 'members', page: memberFormPage, role: 'admin', shell: true },
  { pattern: 'members/import', navKey: 'members', page: memberImportPage, role: 'admin', shell: true },
  { pattern: 'members/:id/edit', navKey: 'members', page: memberFormPage, role: 'admin', shell: true },
  { pattern: 'members/:id', navKey: 'members', page: memberDetailPage, role: 'admin', shell: true },
  { pattern: 'checkin', navKey: 'checkin', page: checkinPage, role: 'admin', shell: true },
  { pattern: 'payments', navKey: 'payments', page: paymentsPage, role: 'admin', shell: true },
  { pattern: 'attendance', navKey: 'attendance', page: attendancePage, role: 'admin', shell: true },
  { pattern: 'plans', navKey: 'plans', page: plansPage, role: 'admin', shell: true },
  { pattern: 'gym', navKey: 'gym', page: gymPage, role: 'admin', shell: true },
  { pattern: 'more', navKey: 'more', page: morePage, role: 'admin', shell: true },

  { pattern: 'portal', navKey: 'portal', page: portalHomePage, role: 'member', shell: true },
  { pattern: 'portal/attendance', navKey: 'portal/attendance', page: portalAttendancePage, role: 'member', shell: true },
  { pattern: 'portal/payments', navKey: 'portal/payments', page: portalPaymentsPage, role: 'member', shell: true }
];

function parseHash() {
  return window.location.hash.replace(/^#\/?/, '').split('?')[0].replace(/\/$/, '');
}

function matchRoute(path) {
  const pathParts = path.split('/').filter(Boolean);
  for (const route of ROUTES) {
    const patternParts = route.pattern.split('/').filter(Boolean);
    if (patternParts.length !== pathParts.length) continue;
    const params = {};
    let matched = true;
    for (let i = 0; i < patternParts.length; i++) {
      if (patternParts[i].startsWith(':')) params[patternParts[i].slice(1)] = decodeURIComponent(pathParts[i]);
      else if (patternParts[i] !== pathParts[i]) { matched = false; break; }
    }
    if (matched) return { route, params };
  }
  return null;
}

let headerEl; let bottomNavEl; let footerEl; let mainEl;
let currentPage = null; // lets a page release resources (e.g. the camera) when we navigate away

function renderShell(navKey) {
  headerEl.innerHTML = renderHeader(navKey);
  bottomNavEl.innerHTML = renderBottomNav(navKey);
}

const go = (hash) => { if (window.location.hash !== hash) window.location.hash = hash; else handleRouteChange(); };

async function handleRouteChange() {
  const authed = isAuthenticated();
  const role = getRole();
  const home = `#/${homeRouteFor(role)}`;
  const path = parseHash();

  if (!path) return go(authed ? home : '#/login');

  const match = matchRoute(path);
  if (!match) return go(authed ? home : '#/login');
  const { route, params } = match;

  if (route.role && !authed) return go('#/login');
  if (!route.role && authed) return go(home);               // logged-in users skip login/register
  if (route.role && route.role !== role) return go(home);   // members can't open admin pages and vice versa

  if (currentPage && typeof currentPage.cleanup === 'function') currentPage.cleanup();
  currentPage = route.page;

  document.body.classList.toggle('has-shell', route.shell);
  headerEl.classList.toggle('hidden', !route.shell);
  bottomNavEl.parentElement.classList.toggle('hidden', !route.shell);
  footerEl.classList.toggle('hidden', !route.shell);
  mainEl.classList.toggle('pt-16', route.shell);
  mainEl.classList.toggle('pb-28', route.shell);
  mainEl.classList.toggle('md:pb-12', route.shell);

  if (route.shell) {
    renderShell(route.navKey);
    // Make sure the header can show the gym name (login only returns the user).
    if (!getGym()) refreshProfile().catch(() => {});
  }

  // Every navigation renders into its OWN fresh container. A slow request from the previous page
  // (e.g. the dashboard still loading when the user taps "Members") can then only write into a view
  // that is no longer on screen, instead of overwriting the page the user is actually looking at.
  const view = document.createElement('div');
  view.className = 'hrk-fade-in';
  mainEl.replaceChildren(view);
  window.scrollTo(0, 0);

  try {
    await route.page.render(view, params);
  } catch (error) {
    // Safety net for an unexpected bug in a page: never leave a blank screen.
    console.error('Unhandled page render error:', error);
    if (view.isConnected) {
      view.innerHTML = `
        <div class="max-w-2xl mx-auto px-margin-mobile md:px-margin py-space-xl">
          <div class="p-space-lg rounded-2xl bg-error-container text-on-error-container">
            <h2 class="font-title-sm text-title-sm">Something went wrong loading this page.</h2>
            <p class="font-body-sm text-body-sm mt-1">Try going back to the <a href="${home}" class="underline font-semibold">home screen</a>.</p>
          </div>
        </div>`;
    }
  }
}

function bootstrap() {
  headerEl = document.getElementById('app-header');
  bottomNavEl = document.getElementById('app-bottomnav');
  footerEl = document.getElementById('app-footer');
  mainEl = document.getElementById('app-main');

  headerEl.addEventListener('click', (e) => {
    if (e.target.closest('#logoutBtn')) { logout(); window.location.hash = '#/login'; }
  });

  window.addEventListener('hashchange', handleRouteChange);
  onAuthChange(() => {
    // A session that was cleared (expired token) sends the person to login;
    // otherwise just refresh the header (e.g. once the gym name arrives).
    if (!isAuthenticated()) {
      if (parseHash() !== 'login' && parseHash() !== 'register') window.location.hash = '#/login';
      return;
    }
    const match = matchRoute(parseHash());
    if (match && match.route.shell) renderShell(match.route.navKey);
  });

  handleRouteChange();
}

document.addEventListener('DOMContentLoaded', bootstrap);
